"""FIBNA grouped-input KernelSHAP WLS attribution and FP32 LM-head noise (Qwen adaptation)."""
from __future__ import annotations
import math
import numpy as np
from xsum_common import autocast as amp_context
def shapley_kernel_weight(features, subset_size):
    if subset_size in (0,features):return 1000.0
    return (features-1)/(math.comb(features,subset_size)*subset_size*(features-subset_size))


def coalition_matrix(F, M, rng):
    """Always include empty, full, singleton and leave-one-out masks."""
    if F<2:raise ValueError('Need >=2 attribution features')
    if M<2*F+2:
        raise ValueError(f'Need at least {2*F+2} coalition samples for F={F}')
    max_m = 2**F
    M = min(M,max_m)
    masks={tuple([0]*F),tuple([1]*F)}
    for j in range(F):
        a=[0]*F;a[j]=1;masks.add(tuple(a))
        b=[1]*F;b[j]=0;masks.add(tuple(b))
    sizes=np.arange(1,F)
    weights=np.array([(F-1)/(math.comb(F,int(j))*j*(F-j)) for j in sizes],dtype=np.float64)
    weights/=weights.sum()
    while len(masks)<M:
        s=int(rng.choice(sizes,p=weights))
        chosen=rng.choice(F,size=s,replace=False)
        arr=[0]*F
        for j in chosen:arr[int(j)]=1
        masks.add(tuple(arr))
    return np.asarray(sorted(masks),dtype=np.float64)


def kernelshap_wls(masks, values, ridge=1e-7):
    """Weighted Shapley-kernel least-squares; returns F x V signed attributions.

    Accepts numpy matrices so the mathematical self-test runs on CPU and the
    full-vocabulary scorer can use the same deterministic implementation.
    """
    masks=np.asarray(masks,dtype=np.float64)
    values=np.asarray(values,dtype=np.float64)
    if masks.ndim!=2 or values.ndim!=2 or len(masks)!=len(values):
        raise ValueError('Invalid KernelSHAP matrix shapes')
    N,F=masks.shape
    X=np.concatenate([np.ones((N,1)),masks],axis=1)
    w=np.array([shapley_kernel_weight(F,int(row.sum())) for row in masks])
    gram=X.T@(w[:,None]*X)
    gram+=ridge*np.eye(F+1)
    gram[0,0]-=ridge
    rhs=X.T@(w[:,None]*values)
    beta=np.linalg.solve(gram,rhs)
    return beta[1:,:]


def get_article_groups(codec, prompt_len, count):
    beg=len(codec.pre)
    end=prompt_len-len(codec.tail)
    if end<=beg:
        raise RuntimeError('No article tokens to attribute')
    raw=np.array_split(np.arange(beg,end,dtype=np.int64),min(count,end-beg))
    return [t.tolist() for t in raw if len(t)]


def compute_shap_psi(model, batch, codec, torch, dtype, device, features, samples, seed,
                     forward_batch=1, max_prompt_tokens=0):
    """Full-vocabulary KernelSHAP from final-position logits of masked prompts.

    The fixed classification instruction and category suffix remain visible;
    contiguous article groups are toggled by replacing absent token IDs with
    EOS while keeping attention at 1 (position preserving masking convention).
    """
    labels=batch['labels'][0]
    valid=(labels!=-100).nonzero(as_tuple=False).reshape(-1)
    if valid.numel()==0:raise RuntimeError('No completion labels to locate prompt')
    prompt_len=int(valid[0].item())
    prompt=batch['input_ids'][0,:prompt_len].detach().clone().to(device)
    if max_prompt_tokens and prompt_len>max_prompt_tokens:
        # Keep suffix and the newest article tokens for feature evaluation.
        keep_pre=min(len(codec.pre), max_prompt_tokens//3)
        keep_tail=min(max_prompt_tokens-keep_pre, prompt_len-keep_pre)
        prompt=torch.cat([prompt[:keep_pre],prompt[-keep_tail:]],dim=0)
        # codec groups then need adjusted prefix/suffix sizes.
        raise RuntimeError('For publication, set --shap-max-prompt 0 to explain the full fixed prompt')
    groups=get_article_groups(codec,prompt_len,features)
    F=len(groups)
    if F<2:raise RuntimeError('Too few article tokens for KernelSHAP')
    masks=coalition_matrix(F,samples,np.random.default_rng(seed))
    baseline=int(codec.tok.eos_token_id)
    model.eval()
    predictions=[]
    with torch.inference_mode():
        for st in range(0,len(masks),forward_batch):
            ids=[]
            for mask in masks[st:st+forward_batch]:
                x=prompt.clone()
                for j,positions in enumerate(groups):
                    if mask[j]==0:x[positions]=baseline
                ids.append(x)
            inp=torch.stack(ids,dim=0)
            attn=torch.ones_like(inp)
            with amp_context(torch,dtype):
                logits=model(input_ids=inp,attention_mask=attn,use_cache=False).logits[:,-1,:]
            predictions.append(logits.detach().float().cpu().numpy())
    pred=np.concatenate(predictions,axis=0)
    phi=kernelshap_wls(masks,pred)
    psi=np.abs(phi).sum(axis=0).astype(np.float32)
    if not np.isfinite(psi).all() or np.any(psi<0):
        raise FloatingPointError('Invalid KernelSHAP attribution')
    return torch.from_numpy(psi).to(device=device),{
        'coalitions':int(len(masks)),'feature_groups':int(F),
        'psi_mean':float(psi.mean()),'psi_max':float(psi.max()),
        'psi_nonzero':int(np.count_nonzero(psi)),
        'explanation_prompt_tokens':int(prompt_len)}


def add_fibna_noise(head_weight, psi, coefficient, generator, chunk_rows=1024):
    """Apply feature-dependent Gaussian noise in FP32 row chunks to head only.

    Can be exercised on CPU for mathematical tests. The base input embedding
    matrix is *not* modified; output weight tying is broken deliberately.
    """
    import torch
    if head_weight.dtype!=torch.float32:
        raise TypeError('FP32 head required to preserve small FIBNA perturbations')
    V,H=head_weight.shape
    if psi.shape!=(V,):raise ValueError(f'Expected vocabulary SHAP vector {(V,)}, got {tuple(psi.shape)}')
    if not bool(torch.isfinite(psi).all().item()):raise ValueError('Non-finite SHAP vector')
    total_sigma2=0.0
    total_noise2=0.0
    with torch.no_grad():
        for st in range(0,V,chunk_rows):
            w=head_weight[st:st+chunk_rows]
            # row-wise normalized pretrained+perturbed LM-head weights
            norms=torch.linalg.vector_norm(w,ord=2,dim=1,keepdim=True).clamp_min(1e-5)
            sigma=(coefficient*psi[st:st+chunk_rows,None])*(w.abs()/norms)
            rnd=torch.randn(w.shape,device=w.device,dtype=torch.float32,generator=generator)
            noise=rnd*sigma
            total_sigma2+=float(sigma.square().sum().item())
            total_noise2+=float(noise.square().sum().item())
            w.add_(noise)
    return {'sigma_rms':math.sqrt(total_sigma2/(V*H)),
            'noise_rms':math.sqrt(total_noise2/(V*H)),
            'head_elements':V*H}

