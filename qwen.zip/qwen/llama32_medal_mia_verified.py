#!/usr/bin/env python3
"""Llama-3.2-1B MeDAL membership-inference audit for LoRA, DP-LoRA and FIBNA.

Native attacks implemented in this file:
  PPL/loss, Min-K%, Min-K%++, Neighborhood (T5 infilling variant),
  EZ-MIA (base-reference version), reference log-likelihood ratio,
  zlib-normalized log-likelihood, and entropy/confidence attack.

SPV-MIA, DF-MIA and LiRA are NOT implemented by the above substitutes.
Their published methods require reference-model training or shadow-model
statistics. Add scores obtained with faithful independent implementations
using --external-scores; those rows are then evaluated identically.

The output is an *empirical fine-tuning membership audit*, not a DP proof.
"""
from __future__ import annotations

import argparse
import csv
import gc
import hashlib
import json
import math
import os
import shutil
import subprocess
import re
import sys
import warnings
import zlib
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

BASE_NAME = "meta-llama/Llama-3.2-1B"
METHODS = ("LoRA", "DP-LoRA", "FIBNA")
CORE_ATTACKS = [
    "PPL", "Min-K%", "Min-K%++", "Neighborhood", "EZ-MIA",
    "Reference-ratio", "ZLIB", "Entropy",
]
EXTERNAL_ATTACKS = ["SPV-MIA", "DF-MIA", "LiRA"]
ALL_ATTACKS = CORE_ATTACKS + EXTERNAL_ATTACKS
SCORE_MAP = {
    "PPL": "score_ppl", "Min-K%": "score_mink", "Min-K%++": "score_minkpp",
    "Neighborhood": "score_neighbor", "EZ-MIA": "score_ez",
    "Reference-ratio": "score_reference", "ZLIB": "score_zlib",
    "Entropy": "score_entropy",
}
SCORE_FIELDS = [
    "sample_id", "label", "split", "n_tokens", "score_ppl", "score_mink",
    "score_minkpp", "score_neighbor", "score_ez", "score_reference",
    "score_zlib", "score_entropy", "n_neighbors",
]
REF_FIELDS = ["sample_id", "ref_mean_logp", "ref_token_logps_json"]
NEIGH_FIELDS = ["sample_id", "neighbor_idx", "neighbor_text"]


def get_args():
    ap = argparse.ArgumentParser(
        description="Llama-3.2-1B / MeDAL: strictly verified LoRA, DP-LoRA and FIBNA MIA benchmark (local CSV splits)")
    ap.add_argument("--model-id", default=BASE_NAME, help="Exact base model used to train ALL checkpoints (default: meta-llama/Llama-3.2-1B)")
    ap.add_argument("--hf-loader", choices=["local-csv"], default="local-csv", help="Use original MeDAL train.csv/test.csv/valid.csv; no deprecated HF remote dataset script")
    ap.add_argument("--local-data-dir", default="./medal_original_splits", help="Path to extracted MeDAL CSVs (use ../../medal_original_splits if needed)")
    ap.add_argument("--train-size", type=int, default=53000, help="First N MeDAL train examples AFTER shuffle(seed=42); MUST match EACH fine-tuning run")
    ap.add_argument("--test-size", type=int, default=1000, help="First N original test records after shuffle(seed=42)")
    ap.add_argument("--extra-validation-nonmembers", type=int, default=15000, help="Additional validation candidates excluded from all three fine-tunings and model selection")
    ap.add_argument("--train-shuffle-seed", type=int, default=42)
    ap.add_argument("--test-shuffle-seed", type=int, default=42)
    ap.add_argument("--lora", default="./lora_medal_llama32")
    ap.add_argument("--dp-lora", default="lora_dp_medal_llama328.pth")
    ap.add_argument("--fibna", default="fi_lora_dp_high_medal_llama328.pth")
    ap.add_argument("--dp-alpha", type=int, default=32, help="Must equal original DP-LoRA training alpha; not recoverable from raw .pth tensors")
    ap.add_argument("--fibna-alpha", type=int, default=32, help="Must equal original FIBNA training alpha; not recoverable from raw .pth tensors")
    ap.add_argument("--dp-dropout", type=float, default=0.1)
    ap.add_argument("--fibna-dropout", type=float, default=0.1)
    ap.add_argument("--target-modules", default="auto", help="Infer target modules from saved adapter weights; comma-separated override validated against checkpoint")
    ap.add_argument("--dtype", choices=["float32", "float16", "bfloat16"], default="float32", help="float32 for exact checkpoint comparison; other dtypes compared after casting")
    ap.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda"])
    ap.add_argument("--output", default="mia_llama32_medal_10000_verified")
    ap.add_argument("--population", choices=["balanced", "all"], default="balanced")
    ap.add_argument("--max-per-class", type=int, default=10000, help="Maximum examples selected per class")
    ap.add_argument("--require-per-class", type=int, default=10000, help="Abort unless exactly N samples of EACH class are available and selected; 0 disables")
    ap.add_argument("--min-tokens", type=int, default=32)
    ap.add_argument("--max-tokens", type=int, default=128)
    ap.add_argument("--min-cal-neg", type=int, default=100)
    ap.add_argument("--calibration-fraction", type=float, default=0.40)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--k-percent", type=float, default=20.0)
    ap.add_argument("--neighbors", type=int, default=5, help="T5-small neighborhoods per example; 0 skips Neighborhood attack")
    ap.add_argument("--mask-model", default="t5-small")
    ap.add_argument("--mask-span-words", type=int, default=2)
    ap.add_argument("--save-every", type=int, default=25)
    ap.add_argument("--bootstrap", type=int, default=500)
    ap.add_argument("--quality-check-samples", type=int, default=4,
                    help="Smoke-test N member + N nonmember examples with all models before costly inference; 0 disables")
    ap.add_argument("--quality-warning-drop", type=float, default=30.0,
                    help="Warn if target median mean token log-likelihood is this many nats worse than pretrained")
    ap.add_argument("--external-scores", default=None)
    ap.add_argument("--inspect-only", action="store_true", help="Display model adapter configs and .pth key/shape metadata only")
    ap.add_argument("--verify-only", action="store_true", help="Check checkpoint architecture and exact forward-pass parameter restoration; no scoring")
    ap.add_argument("--verify-method", choices=["all", "LoRA", "DP-LoRA", "FIBNA"], default="all", help="For debugging, verify one method independently")
    ap.add_argument("--prepare-only", action="store_true", help="Audit and cache dataset selections without model inference")
    ap.add_argument("--report-only", action="store_true", help="Regenerate reports from verified score CSVs; no GPU inference")
    ap.add_argument("--no-plot", action="store_true")
    ap.add_argument("--no-auto-report", action="store_true")
    ap.add_argument("--overlap-policy", choices=["exclude-nonmembers", "error"], default="exclude-nonmembers")
    ap.add_argument("--trust-membership", action="store_true", help="I verified these are EXACT training-member candidates for ALL 3 checkpoint files and that test/validation were unseen")
    return ap.parse_args()


def sha256_file(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def source_fingerprint(path):
    p = Path(path)
    if p.is_file():
        return {"path": str(p.resolve()), "sha256": sha256_file(p)}
    relevant = sorted(q for q in p.rglob("*") if q.is_file() and
                      (q.name.endswith((".safetensors", ".bin", ".json"))))
    if not relevant:
        raise RuntimeError(f"No model/adapter files inside {p}")
    h = hashlib.sha256()
    for q in relevant:
        h.update(str(q.relative_to(p)).encode()); h.update(sha256_file(q).encode())
    return {"path": str(p.resolve()), "sha256": h.hexdigest(), "files": len(relevant)}


def verify_run_config(args, out):
    # Prevent accidental cross-run cache reuse; checkpoints additionally SHA256 verified.
    fields = (
        "model_id", "hf_loader", "local_data_dir", "train_size", "test_size",
        "extra_validation_nonmembers", "train_shuffle_seed", "test_shuffle_seed",
        "lora", "dp_lora", "fibna", "dp_alpha", "fibna_alpha",
        "dp_dropout", "fibna_dropout", "target_modules", "dtype",
        "population", "max_per_class", "require_per_class", "min_tokens", "max_tokens",
        "calibration_fraction", "seed", "k_percent", "neighbors", "mask_model", "mask_span_words",
        "quality_check_samples", "quality_warning_drop")
    path = out / "run_config.json"
    if path.exists():
        old = json.loads(path.read_text(encoding="utf-8"))
        diffs = {k: [old.get(k), getattr(args, k)] for k in fields if old.get(k) != getattr(args, k)}
        if diffs:
            raise RuntimeError(f"Incompatible existing run; use a NEW --output directory: {diffs}")
    else:
        path.write_text(json.dumps(vars(args), indent=2), encoding="utf-8")


def sha_text(s):
    normalized = re.sub(r"\s+", " ", s).strip().casefold()
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()


def write_metadata(args, out):
    conf = dict(vars(args))
    (out / "run_config.json").write_text(json.dumps(conf, indent=2), encoding="utf-8")


def read_medal_rows(args, out):
    """Cache exact training-era shuffle selections, not the full train split.

    The cache is replayed on resume, so new HF dataset library versions or
    dataset revisions cannot silently change membership candidates.
    """
    cache = out / "hf_selected_records.csv"
    if cache.exists():
        df = pd.read_csv(cache, dtype={"text": str}, keep_default_na=False)
        needed = {"source_split", "shuffled_position", "text"}
        if not needed.issubset(df):
            raise RuntimeError(f"{cache} missing columns {needed-set(df.columns)}")
        members = df.loc[df.source_split == "train", "text"].tolist()
        nonmembers = df.loc[df.source_split.isin(["test", "validation"]), "text"].tolist()
        if len(members)!=args.train_size or sum(df.source_split.eq("test"))!=args.test_size or sum(df.source_split.eq("validation"))!=args.extra_validation_nonmembers:
            raise RuntimeError("Cached source counts do not match --train-size/--test-size/--extra-validation-nonmembers")
        print(f"Reusing saved HF selection: {cache} ({len(members)} members, {len(nonmembers)} nonmembers)")
        return members, nonmembers

    try:
        from datasets import load_dataset
    except ImportError as e:
        raise RuntimeError("Install datasets and pyarrow: pip install datasets pyarrow") from e

    def get_split(name):
        if args.hf_loader != "local-csv":
            raise RuntimeError("Only --hf-loader local-csv is supported")
        root = Path(args.local_data_dir).expanduser()
        filenames = {
            "train": ("train.csv",),
            "test": ("test.csv",),
            "validation": ("valid.csv", "val.csv", "validation.csv"),
        }[name]
        source = next((root / f for f in filenames if (root / f).is_file()), None)
        if source is None:
            raise FileNotFoundError(f"MeDAL {name} CSV not found in {root}. Tried {filenames}")
        print(f"Loading original MeDAL CSV: {source}")
        return load_dataset("csv", data_files={name: str(source.resolve())}, split=name)

    selections = [("train", args.train_size, args.train_shuffle_seed),
                  ("test", args.test_size, args.test_shuffle_seed)]
    if args.extra_validation_nonmembers:
        selections.append(("validation", args.extra_validation_nonmembers, args.test_shuffle_seed))
    records=[]
    for split,n,seed in selections:
        print(f"Loading MeDAL {split}; using shuffle(seed={seed}).select(range({n}))")
        ds = get_split(split)
        # The original MeDAL CSVs use uppercase headers:
        # ABSTRACT_ID,TEXT,LOCATION,LABEL.  The published medal.py loader
        # maps CSV column 1 (TEXT) directly to its lowercase feature 'text'.
        # Preserve each original text verbatim and the source row ordering.
        if "text" not in ds.column_names:
            text_columns = [c for c in ds.column_names
                            if isinstance(c, str) and c.strip().casefold() == "text"]
            if len(text_columns) != 1:
                raise ValueError(
                    f"MeDAL split {split}: cannot uniquely locate TEXT/text "
                    f"column in {ds.column_names}. Expected original MeDAL "
                    "pretrain_subset.zip CSV files with ABSTRACT_ID,TEXT,LOCATION,LABEL."
                )
            original_col = text_columns[0]
            ds = ds.rename_column(original_col, "text")
            print(f"  Normalized original MeDAL column {original_col!r} -> 'text' "
                  "(same text mapping as medal.py; no text transformation)")
        # Only text is used for MIA; exclude irrelevant metadata without
        # changing the dataset order or the deterministic shuffle.
        ds = ds.select_columns(["text"])
        if n > len(ds):
            raise ValueError(f"Requested {n} rows from {split}, only {len(ds)} available")
        selected = ds.shuffle(seed=seed).select(range(n))
        texts = selected["text"]
        records.extend({"source_split": split, "shuffled_position": i,
                        "text": (value if isinstance(value,str) else "")}
                       for i,value in enumerate(texts))
        del selected,ds
    # Atomic replace prevents a partial CSV from being reused after interruption.
    temp = cache.with_suffix(".partial.csv")
    pd.DataFrame(records,columns=["source_split","shuffled_position","text"]).to_csv(temp,index=False)
    os.replace(temp,cache)
    members=[r["text"] for r in records if r["source_split"]=="train"]
    nonmembers=[r["text"] for r in records if r["source_split"]!="train"]
    print(f"Cached exact selections to {cache}.")
    return members,nonmembers



def choose_data(args, out, tokenizer):
    """Create a reproducible, leakage-audited source manifest.

    Non-member candidates that duplicate any training member are *excluded*,
    never re-labelled. Duplicates within each source are also removed.
    Truncated-token duplicates are excluded because attacks score the same
    first `max_tokens` tokens and should not see identical inputs with opposite
    membership labels. Audit files contain hashes/row numbers, not raw text.
    """
    members, nonmembers = read_medal_rows(args, out)
    audit = []
    stats = {"member_source_rows": len(members),
             "nonmember_source_rows": len(nonmembers)}

    def distinct(collection, label):
        unique = {}
        for row_no, original in enumerate(collection):
            sig = sha_text(original)
            if sig in unique:
                audit.append({"source": "member" if label == 1 else "nonmember",
                              "source_nonempty_row": row_no, "hash": sig,
                              "reason": "duplicate_within_source"})
                continue
            unique[sig] = (row_no, original)
        return unique

    member_unique = distinct(members, 1)
    nonmember_unique = distinct(nonmembers, 0)
    overlaps = set(member_unique) & set(nonmember_unique)
    stats.update({"unique_member_texts": len(member_unique),
                  "unique_nonmember_texts": len(nonmember_unique),
                  "cross_split_normalized_overlap": len(overlaps)})

    for sig in sorted(overlaps):
        row_no, _ = nonmember_unique[sig]
        audit.append({"source": "nonmember", "source_nonempty_row": row_no,
                      "hash": sig, "reason": "also_present_in_member_source"})

    if overlaps and args.overlap_policy == "error":
        pd.DataFrame(audit, columns=["source", "source_nonempty_row", "hash", "reason"]).to_csv(
            out / "candidate_exclusion_audit.csv", index=False)
        raise ValueError(
            f"{len(overlaps)} normalized train/test text overlaps detected. "
            f"See {out / 'candidate_exclusion_audit.csv'}; rerun with "
            "--overlap-policy exclude-nonmembers to exclude ambiguous nonmembers."
        )

    # Eligibility is based on the precise truncated token sequence scored by
    # each attack. Cross-split prefix collisions must also be excluded.
    all_rows = []
    member_token_hashes = set()
    for sig, (row_no, item) in member_unique.items():
        toks = tokenizer.encode(item, add_special_tokens=False, truncation=True,
                                max_length=args.max_tokens)
        if len(toks) < args.min_tokens:
            audit.append({"source": "member", "source_nonempty_row": row_no,
                          "hash": sig, "reason": "fewer_than_min_tokens"})
            continue
        token_sig = hashlib.sha256(json.dumps(toks, separators=(",", ":")).encode()).hexdigest()
        if token_sig in member_token_hashes:
            audit.append({"source": "member", "source_nonempty_row": row_no,
                          "hash": sig, "reason": "duplicate_scored_tokens_within_source"})
            continue
        member_token_hashes.add(token_sig)
        all_rows.append({"sample_id": sig[:24], "hash": sig, "label": 1,
                         "text": item, "token_ids": toks})

    excluded_token_prefixes = 0
    nonmember_token_hashes = set()
    for sig, (row_no, item) in nonmember_unique.items():
        if sig in overlaps:
            continue
        toks = tokenizer.encode(item, add_special_tokens=False, truncation=True,
                                max_length=args.max_tokens)
        if len(toks) < args.min_tokens:
            audit.append({"source": "nonmember", "source_nonempty_row": row_no,
                          "hash": sig, "reason": "fewer_than_min_tokens"})
            continue
        token_sig = hashlib.sha256(json.dumps(toks, separators=(",", ":")).encode()).hexdigest()
        if token_sig in member_token_hashes:
            audit.append({"source": "nonmember", "source_nonempty_row": row_no,
                          "hash": sig, "reason": "identical_scored_tokens_to_member"})
            excluded_token_prefixes += 1
            continue
        if token_sig in nonmember_token_hashes:
            audit.append({"source": "nonmember", "source_nonempty_row": row_no,
                          "hash": sig, "reason": "duplicate_scored_tokens_within_source"})
            continue
        nonmember_token_hashes.add(token_sig)
        all_rows.append({"sample_id": sig[:24], "hash": sig, "label": 0,
                         "text": item, "token_ids": toks})

    # A 96-bit prefix is ample for hashes at this scale, but check rather than
    # silently treating any accidental collision as the same candidate.
    ids = [r["sample_id"] for r in all_rows]
    if len(set(ids)) != len(ids):
        raise RuntimeError("Truncated sample_id hash collision; increase sample_id hash length.")

    audit_path = out / "candidate_exclusion_audit.csv"
    pd.DataFrame(audit, columns=["source", "source_nonempty_row", "hash", "reason"]).to_csv(
        audit_path, index=False)
    stats["cross_split_token_prefix_collisions"] = excluded_token_prefixes
    stats["eligible_members"] = sum(r["label"] == 1 for r in all_rows)
    stats["eligible_nonmembers"] = sum(r["label"] == 0 for r in all_rows)
    (out / "candidate_selection_summary.json").write_text(json.dumps(stats, indent=2), encoding="utf-8")
    print("\nMembership candidate audit:")
    for name, value in stats.items():
        print(f"  {name}: {value}")
    print("Saved candidate exclusion audit:", audit_path)
    if overlaps or excluded_token_prefixes:
        warnings.warn(
            f"Excluded {len(overlaps)} normalized text matches and "
            f"{excluded_token_prefixes} additional matching token prefixes from nonmembers. "
            "Do not relabel them as members without verifying actual training membership. "
            "Inspect the audit and verify that the remaining test set was never used in fine-tuning."
        )

    by = {k: [v for v in all_rows if v["label"] == k] for k in (0, 1)}
    if args.require_per_class > 0:
        shortage = {"members": len(by[1]), "nonmembers": len(by[0])}
        if any(count < args.require_per_class for count in shortage.values()):
            raise ValueError(
                f"Requested exactly {args.require_per_class:,} examples PER class but "
                f"only {shortage['members']:,} eligible member examples and "
                f"{shortage['nonmembers']:,} eligible nonmember examples remain after "
                "deduplication and overlap filtering. Increase the verified held-out "
                "nonmember candidate pool if necessary, and rerun with a new --output "
                "directory; never relabel training records as nonmembers. "
                "NO model inference has started."
            )
    if args.population == "balanced":
        n_common = min(len(by[0]), len(by[1]))
        print(f"Balanced candidate population: {n_common:,} members and {n_common:,} nonmembers.")
    else:
        n_common = None
        warnings.warn("Using imbalanced population; F1 strongly depends on membership prevalence. "
                      "The manuscript should report the all-member F1 baseline.")
    rng = np.random.default_rng(args.seed)
    picked = []
    for label in (0, 1):
        arr = by[label]
        rng.shuffle(arr)
        if args.population == "balanced":
            arr = arr[:n_common]
        if args.max_per_class > 0:
            arr = arr[:args.max_per_class]
        if len(arr) < 50:
            raise ValueError(f"Only {len(arr)} eligible label={label} samples after cleaning. Need more.")
        cutoff = max(1, min(len(arr)-1, round(len(arr)*args.calibration_fraction)))
        for idx, rec in enumerate(arr):
            rec["split"] = "cal" if idx < cutoff else "test"
            picked.append(rec)
    rng.shuffle(picked)
    selected_counts = {label: sum(r["label"] == label for r in picked) for label in (0, 1)}
    if args.require_per_class > 0 and any(
        count != args.require_per_class for count in selected_counts.values()
    ):
        raise ValueError(
            f"Selected {selected_counts[1]:,} members and {selected_counts[0]:,} "
            f"nonmembers, but --require-per-class={args.require_per_class:,}. "
            "Use --max-per-class equal to --require-per-class and the default "
            "--population balanced; choose a fresh --output folder. "
            "NO model inference has started."
        )
    new_manifest = pd.DataFrame([{
        "sample_id": r["sample_id"], "hash": r["hash"], "label": r["label"],
        "split": r["split"], "n_tokens": len(r["token_ids"])
    } for r in picked]).sort_values("sample_id").reset_index(drop=True)
    dest = out / "sample_manifest.csv"
    if dest.exists():
        old = pd.read_csv(dest, dtype={"sample_id":str,"hash":str}).sort_values("sample_id").reset_index(drop=True)
        if not old.equals(new_manifest):
            raise RuntimeError(
                "Existing sample_manifest.csv differs from current dataset/config. "
                "Keep previous inputs unchanged to resume, or use a NEW --output directory."
            )
    else:
        new_manifest.to_csv(dest, index=False)
    print("Membership candidates:", dict(new_manifest.label.value_counts()))
    print("Calibration/test:", new_manifest.groupby(["split","label"]).size().to_dict())
    n_cal_neg = ((new_manifest.split == "cal") & (new_manifest.label == 0)).sum()
    if n_cal_neg < args.min_cal_neg:
        raise ValueError(f"Only {n_cal_neg} calibration nonmembers, need >= {args.min_cal_neg} to attempt low-FPR estimates.")
    if n_cal_neg < 1000:
        warnings.warn(
            f"Only {n_cal_neg} calibration negatives. TPR@1%FPR is discretized; "
            "prefer >= 1000-5000 for a strong low-FPR evaluation."
        )
    return picked




def append_file(path, header, existing=None):
    if not path.exists():
        with path.open("w", encoding="utf-8", newline="") as f:
            csv.writer(f).writerow(header)
    if existing is None:
        return set()
    frame = pd.read_csv(path)
    if frame.empty:
        return set()
    for col in existing:
        if col not in frame:
            raise RuntimeError(f"{path} is missing expected identifier {col}")
    if frame.duplicated(existing).any():
        raise RuntimeError(f"{path} contains repeated primary keys {existing}; resolve before continuing.")
    return set(tuple(row) for row in frame[existing].itertuples(index=False, name=None))


def atomic_append(path, rows, header):
    if not rows:
        return
    with path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=header)
        writer.writerows(rows)
        f.flush()
        os.fsync(f.fileno())


def load_transformers():
    import torch
    from transformers import AutoTokenizer, AutoModelForCausalLM
    from peft import PeftModel, LoraConfig, TaskType, get_peft_model
    return torch, AutoTokenizer, AutoModelForCausalLM, PeftModel, LoraConfig, TaskType, get_peft_model


def torch_device(torch, args):
    if args.device == "auto":
        return torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if args.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA selected but not available")
    return torch.device("cuda:0" if args.device == "cuda" else "cpu")


def canonical_key(key):
    """Treat PEFT's saved adapter names (.lora_A.weight) as equivalent to active .default keys."""
    key = key.removeprefix("module.")
    key = key.replace(".base_layer.", ".")
    for name in ("lora_A", "lora_B", "lora_embedding_A", "lora_embedding_B", "modules_to_save"):
        key = key.replace(f".{name}.default.", f".{name}.")
    return key


def read_pt_state(path, torch):
    try:
        ckpt = torch.load(str(path), map_location="cpu", weights_only=True, mmap=True)
    except (TypeError, RuntimeError, ValueError):
        ckpt = torch.load(str(path), map_location="cpu", weights_only=True)
    state = ckpt.get("model_state_dict", ckpt.get("state_dict", ckpt))
    if not isinstance(state, dict) or not all(hasattr(v, "shape") for v in state.values()):
        raise RuntimeError(f"Checkpoint {path} is not a tensor state dictionary; inspect its training-time format")
    return ckpt, {k.removeprefix("module."): v for k, v in state.items()}


def infer_lora_layout(state):
    a_names = [k for k in state if ".lora_A" in k and k.endswith("weight")]
    b_names = [k for k in state if ".lora_B" in k and k.endswith("weight")]
    if not a_names or len(a_names) != len(b_names):
        raise RuntimeError("Missing or unpaired LoRA A/B matrices; cannot reconstruct adapter architecture")
    ranks = {int(state[k].shape[0]) for k in a_names}
    if len(ranks) != 1:
        raise RuntimeError(f"Nonuniform LoRA ranks {ranks}; use original adapter configuration")
    targets = sorted({k.split(".lora_A")[0].split(".")[-1] for k in a_names})
    to_save = sorted({k.split(".modules_to_save")[0].split(".")[-1] for k in state if ".modules_to_save." in k})
    return ranks.pop(), targets, to_save


def compare_saved_to_loaded(model, state, method):
    import torch
    current = model.state_dict()
    # Matching by canonical state key supports the .default adapter-name insertion by PEFT.
    canon = {}
    for key, tensor in current.items():
        ck = canonical_key(key)
        if ck in canon and not torch.equal(canon[ck][1], tensor):
            raise RuntimeError(f"{method}: duplicate active mapping for {ck}")
        canon[ck] = (key, tensor)
    unexpected = [key for key in state if canonical_key(key) not in canon]
    if unexpected:
        raise RuntimeError(f"{method}: unexpected checkpoint keys not loaded: {unexpected[:10]}")
    errors = []
    for key, saved in state.items():
        active_key, loaded = canon[canonical_key(key)]
        if saved.shape != loaded.shape:
            errors.append(f"{key}: shape {list(saved.shape)} versus {list(loaded.shape)}")
            continue
        # Cast to the model's chosen dtype before comparing: this checks the exact value that can be represented.
        comparison = saved.to(dtype=loaded.dtype)
        if not torch.equal(loaded.detach().cpu(), comparison):
            errors.append(f"{key}: parameter values differ after load")
        if len(errors) >= 8:
            break
    if errors:
        raise RuntimeError(f"{method} load check FAILED: {errors}")
    return {"verified_tensor_count": len(state), "verified_adapter_tensors": sum("lora_" in k for k in state),
            "verified_embedding_or_head_tensors": sum(("lm_head" in k or "embed_tokens" in k) and k.endswith("weight") for k in state)}


def inspect_sources(args, deps=None):
    import torch
    for method, path in zip(METHODS, [args.lora, args.dp_lora, args.fibna]):
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(p)
        print(f"\n=== {method}: {p} ===")
        if p.is_dir():
            config = p / "adapter_config.json"
            if config.is_file():
                cfg = json.loads(config.read_text(encoding="utf-8"))
                print("PEFT adapter configuration:", json.dumps({k: cfg.get(k) for k in ("base_model_name_or_path", "r", "lora_alpha", "target_modules", "modules_to_save")}, indent=2))
            else:
                print("Full Hugging Face model folder (requires config.json and weights)")
            continue
        ckpt, state = read_pt_state(p, torch)
        print("Epoch:", ckpt.get("epoch", "not provided"))
        print("Tensor count:", len(state))
        keys = [k for k in state if "lora_A" in k or "lora_B" in k]
        if keys:
            print("Inferred rank, targets, modules_to_save:", infer_lora_layout(state))
        print("Output head:", [(k, list(v.shape)) for k, v in state.items() if "lm_head" in k and k.endswith("weight")][:8])
        print("Input embeddings:", [(k, list(v.shape)) for k, v in state.items() if "embed_tokens" in k and k.endswith("weight")][:8])


def preflight_model_architectures(args):
    """Reject checkpoints from a different Llama model BEFORE expensive GPU loads.

    Raw PEFT state_dicts may contain duplicated base-layer keys with version-dependent
    names. Those cannot explain genuine differences in embedding width or layer index.
    """
    import torch
    from transformers import AutoConfig

    cfg = AutoConfig.from_pretrained(args.model_id)
    if getattr(cfg, "model_type", None) != "llama":
        raise RuntimeError(f"Expected a Llama architecture, got {cfg.model_type!r}")
    vocab, hidden, layers = int(cfg.vocab_size), int(cfg.hidden_size), int(cfg.num_hidden_layers)
    print(f"\nARCHITECTURE PREFLIGHT: {args.model_id}: vocab={vocab}, hidden={hidden}, layers={layers}")
    incompatible = []
    for method, file in zip(METHODS, (args.lora, args.dp_lora, args.fibna)):
        if args.verify_only and args.verify_method != "all" and method != args.verify_method:
            continue
        path = Path(file)
        if not path.exists():
            incompatible.append(f"{method}: checkpoint not found: {path}")
            continue
        if path.is_dir():
            config_file = path / "adapter_config.json"
            if config_file.exists():
                data = json.loads(config_file.read_text(encoding="utf-8"))
                declared = data.get("base_model_name_or_path")
                if declared and declared not in (args.model_id, str(Path(args.model_id).resolve())):
                    incompatible.append(f"{method}: adapter declares base {declared!r} rather than {args.model_id!r}")
                else:
                    print(f"  {method}: folder declares compatible base model ({declared or 'not specified'})")
            else:
                print(f"  {method}: full model directory; detailed check will follow")
            continue
        try:
            ckpt, state = read_pt_state(path, torch)
        except Exception as exc:
            incompatible.append(f"{method}: cannot inspect checkpoint: {exc}")
            continue
        layer_indices = [int(m.group(1)) for k in state if (m := re.search(r'(?:^|\.)layers\.(\d+)\.', k))]
        max_layer = max(layer_indices) if layer_indices else None
        head_shapes = [(k, tuple(x.shape)) for k, x in state.items() if k.endswith("lm_head.weight")]
        embed_shapes = [(k, tuple(x.shape)) for k, x in state.items() if k.endswith("embed_tokens.weight")]
        notes = []
        expected_shape = (vocab, hidden)
        for key, shape in head_shapes + embed_shapes:
            if shape != expected_shape:
                notes.append(f"{key} shape={shape}, expected={expected_shape}")
        if max_layer is not None and max_layer >= layers:
            notes.append(f"checkpoint contains transformer layer {max_layer}, but {args.model_id} only has layers 0..{layers - 1}")
        print(f"  {method}: head={[x[1] for x in head_shapes]}, embeds={[x[1] for x in embed_shapes]}, "
              f"highest_layer={max_layer}, state_tensors={len(state)}")
        if notes:
            incompatible.append(f"{method}: " + "; ".join(notes))
        del state, ckpt
    if incompatible:
        raise RuntimeError(
            "ARCHITECTURE PREFLIGHT FAILED: the three checkpoints cannot be compared as the "
            f"same {args.model_id} model.\n  - " + "\n  - ".join(incompatible) +
            "\nFind the fine-tuned checkpoint produced using the exact common base architecture. "
            "Changing LoRA rank, renaming base_layer keys or loading with strict=False "
            "cannot correct a hidden-size or transformer-layer mismatch. "
            "No MIA inference was performed."
        )
    print("ARCHITECTURE PREFLIGHT: PASS (final tensor-restoration checks still required).\n")


def read_folder_adapter_weights(path, torch):
    p = Path(path)
    sf = p / "adapter_model.safetensors"
    binfile = p / "adapter_model.bin"
    if sf.is_file():
        from safetensors.torch import load_file
        return load_file(str(sf), device="cpu")
    if binfile.is_file():
        return torch.load(str(binfile), map_location="cpu", weights_only=True)
    raise RuntimeError(f"Could not find adapter_model.safetensors or adapter_model.bin in {p}")


def verify_folder_adapter(model, path, torch, method):
    source = read_folder_adapter_weights(path, torch)
    active = {canonical_key(k): v for k, v in model.state_dict().items()}
    missing = []
    mismatch = []
    n_adapters = 0
    for key, tensor in source.items():
        k = canonical_key(key)
        if k not in active:
            missing.append(key); continue
        if tensor.shape != active[k].shape or not torch.equal(active[k].detach().cpu(), tensor.to(dtype=active[k].dtype)):
            mismatch.append(key)
        if "lora_" in key:
            n_adapters += 1
    if missing or mismatch or n_adapters == 0:
        raise RuntimeError(f"{method} adapter-folder load failed: missing={missing[:6]} differing={mismatch[:6]} n_adapter={n_adapters}")
    return {"verified_tensor_count": len(source), "verified_adapter_tensors": n_adapters,
            "verified_embedding_or_head_tensors": sum("lm_head" in k or "embed_tokens" in k for k in source)}


def model_dtype(torch, args):
    return {"float32": torch.float32, "float16": torch.float16, "bfloat16": torch.bfloat16}[args.dtype]


def load_target(path, method, args, device, deps, out=None):
    torch, _, AutoModel, PeftModel, LoraConfig, TaskType, get_peft_model = deps
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(path)
    dtype = model_dtype(torch, args)
    print(f"\n{method}: loading pretrained {args.model_id} (dtype={args.dtype})")
    base = AutoModel.from_pretrained(args.model_id, torch_dtype=dtype, low_cpu_mem_usage=True)
    if base.config.model_type != "llama":
        raise RuntimeError(f"Expected Llama model; got {base.config.model_type}. Verify --model-id")
    base_model_id = args.model_id
    pretrained_head = (base.get_output_embeddings().weight.detach().cpu().clone()
                       if method == "FIBNA" and path.is_file() else None)  # snapshot BEFORE loading
    ckpt_info = None
    if path.is_dir() and (path / "adapter_config.json").exists():
        cfg = json.loads((path / "adapter_config.json").read_text(encoding="utf-8"))
        declared_base = cfg.get("base_model_name_or_path")
        if declared_base and declared_base not in (args.model_id, str(Path(args.model_id).resolve())):
            raise RuntimeError(f"{method} adapter was trained on {declared_base!r}, not {args.model_id!r}; supply the correct --model-id")
        model = PeftModel.from_pretrained(base, str(path), is_trainable=False)
        verified = verify_folder_adapter(model, path, torch, method)
        print(f"{method}: verified PEFT adapter folder")
    elif path.is_dir():
        if not (path / "config.json").is_file():
            raise RuntimeError(f"{method}: full model folder missing config.json")
        model, loading = AutoModel.from_pretrained(str(path), torch_dtype=dtype, output_loading_info=True)
        if loading.get("missing_keys") or loading.get("unexpected_keys") or loading.get("mismatched_keys"):
            raise RuntimeError(f"{method} full Hugging Face model folder load incomplete: {loading}")
        verified = {"verified_tensor_count": "from_pretrained full folder", "verified_adapter_tensors": 0,
                    "verified_embedding_or_head_tensors": "loaded as full model"}
        print(f"{method}: verified full Hugging Face model load")
    else:
        ckpt, state = read_pt_state(path, torch)
        adapter = [k for k in state if ".lora_A" in k or ".lora_B" in k]
        if adapter:
            rank, detected_targets, modules_to_save = infer_lora_layout(state)
            if args.target_modules == "auto":
                targets = detected_targets
            else:
                targets = [x.strip() for x in args.target_modules.split(",") if x.strip()]
                if set(targets) != set(detected_targets):
                    raise RuntimeError(f"{method}: supplied targets {targets} differ from saved adapter keys {detected_targets}")
            alpha = args.fibna_alpha if method == "FIBNA" else args.dp_alpha
            dropout = args.fibna_dropout if method == "FIBNA" else args.dp_dropout
            lc = LoraConfig(r=rank, lora_alpha=alpha, lora_dropout=dropout,
                            target_modules=targets, bias="none", task_type=TaskType.CAUSAL_LM,
                            modules_to_save=modules_to_save or None)
            model = get_peft_model(base, lc)
            # PEFT prior versions saved A.weight, later versions save A.default.weight.
            expected = {canonical_key(k): k for k in model.state_dict()}
            normalized = {}
            for key, value in state.items():
                k = canonical_key(key)
                if k not in expected:
                    raise RuntimeError(f"{method}: checkpoint key {key} is unsupported by reconstructed architecture")
                actual = expected[k]
                if actual in normalized:
                    raise RuntimeError(f"{method}: two checkpoint tensors map to {actual}")
                normalized[actual] = value
            expected_lora = {k for k in model.state_dict() if "lora_" in k}
            if not expected_lora.issubset(normalized):
                raise RuntimeError(f"{method}: {len(expected_lora - set(normalized))} LoRA tensors missing from .pth")
            result = model.load_state_dict(normalized, strict=False)
            if result.unexpected_keys or any("lora_" in k for k in result.missing_keys):
                raise RuntimeError(f"{method}: incompatible adapter restore: {result}")
            print(f"{method}: detected rank={rank}, targets={targets}, modules_to_save={modules_to_save}, alpha={alpha} (must match training)")
        else:
            if not all(k in base.state_dict() for k in state):
                raise RuntimeError(f"{method}: .pth lacks LoRA matrices and is not a supported complete model checkpoint")
            result = base.load_state_dict(state, strict=True)
            model = base
        verified = compare_saved_to_loaded(model, state, method)
        if method == "FIBNA":
            head_keys = [k for k in state if ("lm_head" in k and k.endswith("weight"))]
            embed_keys = [k for k in state if ("embed_tokens" in k and k.endswith("weight"))]
            if not head_keys:
                raise RuntimeError("FIBNA .pth has NO lm_head weights: cannot verify restoration of direct head perturbation")
            active_heads = [k for k in head_keys if ".modules_to_save." in k] or [k for k in head_keys if ".original_module." not in k]
            if len(active_heads) != 1:
                raise RuntimeError(f"Ambiguous FIBNA active output heads {active_heads}; inspect the checkpoint architecture")
            saved_head = state[active_heads[0]]
            if saved_head.shape != pretrained_head.shape:
                raise RuntimeError("FIBNA saved lm_head dimension differs from base checkpoint")
            # Confirm the head used for forward passes, not merely a dormant state_dict tensor.
            output_module = model.get_output_embeddings()
            if hasattr(output_module, "modules_to_save"):
                active_name = getattr(model, "active_adapter", "default")
                if isinstance(active_name, (tuple, list)):
                    active_name = active_name[0] if len(active_name) == 1 else None
                if active_name not in output_module.modules_to_save:
                    raise RuntimeError(f"Active FIBNA LM-head adapter {active_name!r} is missing from modules_to_save")
                actual_output_head = output_module.modules_to_save[active_name].weight
            else:
                actual_output_head = output_module.weight
            if not torch.equal(actual_output_head.detach().cpu(), saved_head.to(dtype=actual_output_head.dtype)):
                raise RuntimeError("FIBNA active forward-pass LM head differs from the saved checkpoint")
            if not torch.isfinite(saved_head).all():
                raise RuntimeError("FIBNA saved LM-head contains NaN/Inf values")
            # Chunked comparison avoids allocating two additional full-vocabulary heads in RAM.
            sum_sq, max_abs = 0.0, 0.0
            for offset in range(0, saved_head.shape[0], 128):
                piece = saved_head[offset:offset+128].float() - pretrained_head[offset:offset+128].float()
                sum_sq += float(torch.sum(piece.double().square()).item())
                max_abs = max(max_abs, float(piece.abs().max().item()))
            verified["perturbed_lm_head_l2_norm"] = math.sqrt(sum_sq)
            verified["perturbed_lm_head_max_abs"] = max_abs
            verified["active_forward_head_verified"] = True
            verified["head_keys"] = head_keys
            verified["embedding_keys"] = embed_keys
            if not math.isfinite(verified["perturbed_lm_head_l2_norm"]) or verified["perturbed_lm_head_l2_norm"] == 0:
                raise RuntimeError("FIBNA LM-head is unchanged/nonfinite relative to pretrained weights. No valid head perturbation can be established.")
            print(f"FIBNA ACTIVE LM head verified as MODIFIED from pretrained: L2={verified['perturbed_lm_head_l2_norm']:.6g}, max_abs={verified['perturbed_lm_head_max_abs']:.6g}")
            # If checkpoint explicitly saved both equal weights, their loaded values are checked above.
            print(f"FIBNA LM-head verified as MODIFIED from pretrained: L2={verified['perturbed_lm_head_l2_norm']:.6g}, max_abs={verified['perturbed_lm_head_max_abs']:.6g}")
        ckpt_info = {"epoch": ckpt.get("epoch"), "state_keys": len(state)}
    model.to(device).eval()
    payload = {"method": method, "base_model": base_model_id, "checkpoint": source_fingerprint(path),
               "dtype": args.dtype, "verified": verified, "checkpoint_metadata": ckpt_info,
               "VERDICT": "PASS"}
    if out is not None:
        (out / f"checkpoint_verification_{method.replace('-', '_')}.json").write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
    print(f"{method} CHECKPOINT VERDICT: PASS ({verified})")
    del pretrained_head
    return model


def score_forward(torch, model, token_ids, device, k_pct, include_features=True):
    import torch.nn.functional as F
    ids = torch.tensor([token_ids], dtype=torch.long, device=device)
    with torch.inference_mode():
        logits = model(input_ids=ids, attention_mask=torch.ones_like(ids)).logits[:, :-1, :][0].float()
        targets = ids[:, 1:][0]
        lp = F.log_softmax(logits, dim=-1)
        token_lp = lp.gather(-1, targets.unsqueeze(-1)).squeeze(-1)
        mean_lp = float(token_lp.mean().item())
        if not include_features:
            return {"mean_logp":mean_lp}
        k = max(1, math.ceil(len(token_lp) * (k_pct / 100)))
        score_mink = float(torch.topk(token_lp, k, largest=False).values.mean().item())
        probs = lp.exp()
        mean_dist_lp = (probs * lp).sum(-1)
        var_dist_lp = ((probs * (lp - mean_dist_lp.unsqueeze(-1)).square()).sum(-1)).clamp_min(1e-12)
        standardized = (token_lp - mean_dist_lp) / torch.sqrt(var_dist_lp)
        score_minkpp = float(torch.topk(standardized, k, largest=False).values.mean().item())
        entropy = -mean_dist_lp.mean().item()
        top1 = torch.argmax(logits, dim=-1)
        mismatches = (top1 != targets).detach().cpu().numpy().astype(bool)
        return {
            "mean_logp":mean_lp,
            "token_logps":token_lp.detach().cpu().numpy().astype(float).tolist(),
            "wrong_mask":mismatches,
            "score_mink":score_mink,
            "score_minkpp":score_minkpp,
            "score_entropy":-float(entropy),
        }


def precompute_base_reference(rows, args, out, tokenizer, deps, device):
    torch, _, AutoModel, *_ = deps
    dest = out / "reference_logprobs.csv"
    completed = append_file(dest, REF_FIELDS, ["sample_id"])
    tasks = [r for r in rows if (r["sample_id"],) not in completed]
    if tasks:
        print(f"Precomputing pretrained reference: {len(tasks)} remaining")
        model = AutoModel.from_pretrained(args.model_id, torch_dtype=model_dtype(torch, args), low_cpu_mem_usage=True).to(device).eval()
        pending = []
        for j,r in enumerate(tasks, 1):
            a = score_forward(torch, model, r["token_ids"], device, args.k_percent)
            pending.append({"sample_id":r["sample_id"],
                            "ref_mean_logp":a["mean_logp"],
                            "ref_token_logps_json":json.dumps(a["token_logps"],separators=(",", ":"))})
            if len(pending)>=args.save_every:
                atomic_append(dest, pending, REF_FIELDS); pending=[]
                print(f"  base reference {j}/{len(tasks)}")
        atomic_append(dest,pending,REF_FIELDS)
        del model; gc.collect()
        if torch.cuda.is_available(): torch.cuda.empty_cache()
    df = pd.read_csv(dest, dtype={"sample_id":str})
    if df.sample_id.duplicated().any(): raise RuntimeError("Duplicate reference sample IDs")
    result = {r["sample_id"]:{"mean_logp":float(r["ref_mean_logp"]),
                               "token_logps":np.array(json.loads(r["ref_token_logps_json"]),dtype=float)}
              for _,r in df.iterrows()}
    if not all(r["sample_id"] in result for r in rows):
        raise RuntimeError("Incomplete base reference cache")
    return result


def generate_t5_neighbors(rows, args, out, deps, device, tokenizer):
    """A reproducible single-span T5-infilling neighborhood-attack VARIANT.
    Not guaranteed identical to Mattern et al.'s T5-3B settings.
    """
    dest = out / "neighbors.csv"
    append_file(dest, NEIGH_FIELDS, ["sample_id","neighbor_idx"])
    if args.neighbors == 0:
        return {}
    ndf = pd.read_csv(dest, dtype={"sample_id":str})
    done = set(zip(ndf.sample_id,ndf.neighbor_idx)) if len(ndf) else set()
    needed = [(r,j) for r in rows for j in range(args.neighbors) if (r["sample_id"],j) not in done]
    if needed:
        print(f"Generating T5-infilling neighbors: {len(needed)} remaining")
        torch, AutoTokenizer, _, *_ = deps
        from transformers import AutoModelForSeq2SeqLM
        mask_tok = AutoTokenizer.from_pretrained(args.mask_model)
        mask_model = AutoModelForSeq2SeqLM.from_pretrained(args.mask_model).to(device).eval()
        pending=[]
        for i,(r,j) in enumerate(needed,1):
            # Only perturb the exact truncated input on which likelihoods are measured.
            short = tokenizer.decode(r["token_ids"],skip_special_tokens=True)
            words = short.split()
            if len(words)<8: continue
            span = min(args.mask_span_words, max(1,len(words)//5))
            seed = int(hashlib.sha256(f'{r["sample_id"]}|{j}|{args.seed}'.encode()).hexdigest()[:12],16)
            local_rng = np.random.default_rng(seed)
            start = int(local_rng.integers(1,max(2,len(words)-span)))
            masked = " ".join(words[:start]+["<extra_id_0>"]+words[start+span:])
            inp = mask_tok(masked,return_tensors="pt",truncation=True,max_length=512).to(device)
            with torch.inference_mode():
                out_ids = mask_model.generate(**inp, max_new_tokens=32, num_beams=1,do_sample=False)
            infilled = mask_tok.decode(out_ids[0],skip_special_tokens=False)
            match = re.search(r"<extra_id_0>\s*(.*?)\s*(?:<extra_id_1>|</s>|$)",infilled)
            replacement = match.group(1).strip() if match else ""
            replacement = replacement.replace("<pad>", "").replace("</s>", "").strip()
            if not replacement:
                # Omit invalid perturbations; NEVER treat original as an independent neighbor.
                continue
            neighbor = " ".join(words[:start]+[replacement]+words[start+span:])
            if neighbor == short or not neighbor.strip(): continue
            pending.append({"sample_id":r["sample_id"],"neighbor_idx":j,"neighbor_text":neighbor})
            if len(pending)>=args.save_every:
                atomic_append(dest,pending,NEIGH_FIELDS);pending=[]
                print(f"  T5 neighbors {i}/{len(needed)}")
        atomic_append(dest,pending,NEIGH_FIELDS)
        del mask_model; gc.collect()
        if torch.cuda.is_available(): torch.cuda.empty_cache()
    ndf = pd.read_csv(dest, dtype={"sample_id":str})
    neighbors = defaultdict(list)
    for _,r in ndf.iterrows():
        neighbors[r["sample_id"]].append(str(r["neighbor_text"]))
    print("Neighbor coverage:", sum(bool(neighbors[x["sample_id"]]) for x in rows),"/",len(rows))
    return neighbors


def ez_mia_score(target_logps, ref_logps, wrong_mask):
    # Matches the error-zone P/N implementation's central statistic.
    # Need >=2 error-zone tokens; zero if no negative denominator.
    # Match original EZ-MIA implementation: ignore first shifted-token position.
    wrong_mask = np.array(wrong_mask, dtype=bool).copy()
    if len(wrong_mask): wrong_mask[0] = False
    wrong = np.flatnonzero(wrong_mask)
    if len(wrong)<2: return 0.0
    if len(target_logps)!=len(ref_logps):
        raise RuntimeError("Reference and target tokenizer/alignment mismatch")
    d = np.asarray(target_logps,dtype=float)[wrong] - np.asarray(ref_logps,dtype=float)[wrong]
    positive = d[d>0].sum()
    negative = -d[d<0].sum()
    if negative<=0: return 0.0
    val = float(positive/(negative+1e-12))
    return val if np.isfinite(val) and val>=0 else 0.0


def evaluate_model(rows, args, out, deps, device, tokenizer, ref, neighbors, method, path):
    torch = deps[0]
    dest = out / f"scores_{method}.csv"
    provenance_path = out / f"score_provenance_{method.replace('-', '_')}.json"
    # Always verify checkpoint BEFORE consulting cached scores. Never equate old cached results to verified inference.
    model = load_target(path, method, args, device, deps, out)
    verification_report = json.loads((out / f"checkpoint_verification_{method.replace('-', '_')}.json").read_text(encoding="utf-8"))
    signature = {"checkpoint_sha256": verification_report["checkpoint"]["sha256"],
                 "manifest_sha256": sha256_file(out / "sample_manifest.csv"),
                 "model_id": args.model_id, "dtype": args.dtype,
                 "max_tokens": args.max_tokens, "k_percent": args.k_percent, "neighbors": args.neighbors}
    if dest.exists() and dest.stat().st_size > len(",".join(SCORE_FIELDS)) + 3:
        if not provenance_path.is_file():
            raise RuntimeError(f"{method}: existing {dest} lacks verified provenance. Use a NEW --output folder to rescore rather than treating old results as verified.")
        previous = json.loads(provenance_path.read_text(encoding="utf-8"))
        if signature != previous:
            raise RuntimeError(f"{method}: checkpoint, manifest or scoring parameters changed since saved scores; use a NEW output directory")
    else:
        provenance_path.write_text(json.dumps(signature, indent=2), encoding="utf-8")
    completed = append_file(dest, SCORE_FIELDS, ["sample_id"])
    pending_tasks = [r for r in rows if (r["sample_id"],) not in completed]
    print(f"{method}: {len(pending_tasks)} remaining / {len(rows)} total")
    if not pending_tasks:
        del model; gc.collect()
        if torch.cuda.is_available(): torch.cuda.empty_cache()
        return
    pending = []
    for idx,r in enumerate(pending_tasks,1):
        primary = score_forward(torch,model,r["token_ids"],device,args.k_percent)
        lp = np.asarray(primary["token_logps"],dtype=float)
        ref_rec = ref[r["sample_id"]]
        neigh_scores = []
        for ntext in neighbors.get(r["sample_id"], []):
            ntok = tokenizer.encode(ntext, add_special_tokens=False, truncation=True, max_length=args.max_tokens)
            if len(ntok) >= 2:
                neigh_scores.append(score_forward(torch,model,ntok,device,args.k_percent,include_features=False)["mean_logp"])
        neigh_score = (primary["mean_logp"]-float(np.mean(neigh_scores))) if neigh_scores else float("nan")
        txt = tokenizer.decode(r["token_ids"],skip_special_tokens=True)
        zlib_bytes = max(1,len(zlib.compress(txt.encode("utf-8"))))
        row = {"sample_id":r["sample_id"],"label":r["label"],"split":r["split"],
               "n_tokens":len(r["token_ids"]), "score_ppl":primary["mean_logp"],
               "score_mink":primary["score_mink"], "score_minkpp":primary["score_minkpp"],
               "score_neighbor":neigh_score,
               "score_ez":ez_mia_score(lp,ref_rec["token_logps"],primary["wrong_mask"]),
               "score_reference":primary["mean_logp"]-ref_rec["mean_logp"],
               "score_zlib":primary["mean_logp"]*len(lp)/zlib_bytes,
               "score_entropy":primary["score_entropy"], "n_neighbors":len(neigh_scores)}
        pending.append(row)
        if len(pending)>=args.save_every:
            atomic_append(dest,pending,SCORE_FIELDS); pending=[]
            print(f"  {method} {idx}/{len(pending_tasks)} completed, saved")
    atomic_append(dest,pending,SCORE_FIELDS)
    del model;gc.collect()
    if torch.cuda.is_available():torch.cuda.empty_cache()


def run_quality_smoke_check(rows, args, out, deps, device):
    """Check that loaded checkpoints still function as language models before expensive scoring."""
    if args.quality_check_samples <= 0:
        return
    torch, _, AutoModel, *_ = deps
    sample = sorted([r for r in rows if r["label"] == 1], key=lambda r: r["sample_id"])[:args.quality_check_samples]
    sample += sorted([r for r in rows if r["label"] == 0], key=lambda r: r["sample_id"])[:args.quality_check_samples]
    if not sample:
        raise RuntimeError("No samples for model quality check")
    values = []
    print("\n=== MODEL LIKELIHOOD SMOKE CHECK ===")
    base = AutoModel.from_pretrained(args.model_id, torch_dtype=model_dtype(torch, args), low_cpu_mem_usage=True).to(device).eval()
    baseline = {}
    for r in sample:
        baseline[r["sample_id"]] = score_forward(torch, base, r["token_ids"], device, args.k_percent, include_features=False)["mean_logp"]
    del base; gc.collect()
    if torch.cuda.is_available():torch.cuda.empty_cache()
    for method, path in zip(METHODS, [args.lora, args.dp_lora, args.fibna]):
        model = load_target(path, method, args, device, deps, out)
        differences = []
        for r in sample:
            mean_lp = score_forward(torch, model, r["token_ids"], device, args.k_percent, include_features=False)["mean_logp"]
            delta = mean_lp - baseline[r["sample_id"]]
            differences.append(delta)
            values.append({"model": method, "sample_id": r["sample_id"], "label": r["label"],
                           "target_mean_token_logp": mean_lp, "pretrained_mean_token_logp": baseline[r["sample_id"]],
                           "difference_target_minus_base": delta})
        med_delta = float(np.median(differences))
        print(f"  {method}: median difference from pretrained mean token logp = {med_delta:+.4f} nats")
        if med_delta < -args.quality_warning_drop:
            warnings.warn(f"{method}: severe likelihood degradation ({med_delta:.2f} nats). "
                          "Investigate trained lm_head, tied embeddings, LoRA alpha, and model quality "
                          "before interpreting weak MIA attacks as successful privacy defense.")
        del model; gc.collect()
        if torch.cuda.is_available():torch.cuda.empty_cache()
    pd.DataFrame(values).to_csv(out / "model_quality_smoke_check.csv", index=False)
    print("Saved:", out / "model_quality_smoke_check.csv")


def external_scores(args,manifest):
    if not args.external_scores:
        return pd.DataFrame(columns=["sample_id","model","attack","score"])
    df=pd.read_csv(args.external_scores,dtype={"sample_id":str})
    required={"sample_id","model","attack","score"}
    if not required.issubset(df):raise ValueError(f"--external-scores must have {sorted(required)}")
    if df.duplicated(["sample_id","model","attack"]).any():raise ValueError("Duplicate external per-example attack scores")
    known=set(manifest.sample_id)
    if not set(df.sample_id).issubset(known):raise ValueError("External scores contain unknown IDs")
    if not set(df.model).issubset(METHODS):raise ValueError("Unknown model in external scores")
    if not set(df.attack).issubset(EXTERNAL_ATTACKS):raise ValueError("Only SPV-MIA, DF-MIA, LiRA supported as external attack labels")
    if not np.isfinite(pd.to_numeric(df.score,errors="coerce")).all():raise ValueError("Nonfinite external attack scores")
    return df


def choose_threshold_f1(scores,labels):
    from sklearn.metrics import precision_recall_curve
    precision,recall,thresholds=precision_recall_curve(labels,scores)
    if len(thresholds)==0:return float("inf")
    f1=2*precision[:-1]*recall[:-1]/(precision[:-1]+recall[:-1]+1e-12)
    return float(thresholds[int(np.argmax(f1))])


def low_fpr_threshold(negatives,alpha):
    # Larger scores imply member. Empirical upper tail threshold from calibration
    # nonmembers only. Use a conservative strict > operation for tied scores.
    try:return float(np.quantile(negatives,1-alpha,method="higher"))
    except TypeError:return float(np.quantile(negatives,1-alpha,interpolation="higher"))


def ci_bootstrap(labels, scores, f1_threshold, fpr1_thresh, fpr10_thresh, nboot, seed):
    from sklearn.metrics import roc_auc_score, f1_score
    rng=np.random.default_rng(seed)
    ids1=np.flatnonzero(labels==1);ids0=np.flatnonzero(labels==0)
    metrics=np.zeros((nboot,4),dtype=float)
    for b in range(nboot):
        ii=np.r_[rng.choice(ids1,size=len(ids1),replace=True),rng.choice(ids0,size=len(ids0),replace=True)]
        y=labels[ii]; s=scores[ii]
        metrics[b]=[
            roc_auc_score(y,s),
            f1_score(y,s>=f1_threshold,zero_division=0),
            np.mean(s[y==1]>fpr1_thresh),
            np.mean(s[y==1]>fpr10_thresh),
        ]
    lows=np.percentile(metrics,2.5,axis=0); highs=np.percentile(metrics,97.5,axis=0)
    return dict(zip(["auc","f1","tpr1","tpr10"],zip(lows,highs)))


def assess_one(df, method, attack, args):
    from sklearn.metrics import roc_auc_score,precision_score,recall_score,f1_score,confusion_matrix
    df=df.dropna(subset=["score"]).copy()
    cal=df[df.split=="cal"]
    test=df[df.split=="test"]
    ncal0=(cal.label==0).sum();ncal1=(cal.label==1).sum()
    ntest0=(test.label==0).sum();ntest1=(test.label==1).sum()
    if min(ncal0,ncal1,ntest0,ntest1)<10:
        return None
    sc=cal.score.to_numpy(dtype=float)
    yc=cal.label.to_numpy(dtype=int)
    # Direction chosen ONLY with calibration labels, not final-test labels.
    cal_raw_auc=roc_auc_score(yc,sc)
    direction=1 if cal_raw_auc>=0.5 else -1
    cal_sc=direction*sc
    test_sc=direction*test.score.to_numpy(dtype=float)
    yt=test.label.to_numpy(dtype=int)
    # Precision/recall threshold fitted ONLY on calibration members/nonmembers.
    tf1=choose_threshold_f1(cal_sc,yc)
    # sklearn's curve counts >= threshold; choose thresholds with this convention.
    negcal=cal_sc[yc==0]
    t1=low_fpr_threshold(negcal,0.01)
    t10=low_fpr_threshold(negcal,0.10)
    pred=(test_sc>=tf1).astype(int)
    tn,fp,fn,tp=confusion_matrix(yt,pred,labels=[0,1]).ravel()
    auc=roc_auc_score(yt,test_sc)
    member=test_sc[yt==1]; nonmember=test_sc[yt==0]
    result={
        "model":method,"attack":attack,"n_cal_members":int(ncal1),"n_cal_nonmembers":int(ncal0),
        "n_test_members":int(ntest1),"n_test_nonmembers":int(ntest0),
        "direction_from_calibration":direction,"calibration_raw_auc":float(cal_raw_auc),
        "f1":float(f1_score(yt,pred,zero_division=0)),
        "precision":float(precision_score(yt,pred,zero_division=0)),
        "recall":float(recall_score(yt,pred,zero_division=0)),
        "roc_auc_calibrated":float(auc),
        "tpr_at_1pct_fpr":float(np.mean(member>t1)),
        "test_fpr_at_1pct_target":float(np.mean(nonmember>t1)),
        "tpr_at_10pct_fpr":float(np.mean(member>t10)),
        "test_fpr_at_10pct_target":float(np.mean(nonmember>t10)),
        "f1_threshold_calibrated":tf1,"threshold_1pct_calibrated":t1,
        "threshold_10pct_calibrated":t10,
        "tp":int(tp),"tn":int(tn),"fp":int(fp),"fn":int(fn),
        "status":"computed"
    }
    if args.bootstrap>0:
        c=ci_bootstrap(yt,test_sc,tf1,t1,t10,args.bootstrap,args.seed)
        for short,long_name in [("auc","auc"),("f1","f1"),("tpr1","tpr_at_1pct_fpr"),("tpr10","tpr_at_10pct_fpr")]:
            result[long_name+"_ci95_low"]=float(c[short][0]);result[long_name+"_ci95_high"]=float(c[short][1])
    return result


PLOT_METRICS = {
    "f1": "F1-score", "tpr_at_1pct_fpr": "TPR at 1% target FPR",
    "tpr_at_10pct_fpr": "TPR at 10% target FPR",
    "roc_auc_calibrated": "Calibrated ROC-AUC",
    "precision": "Precision", "recall": "Recall",
    "test_fpr_at_1pct_target": "Observed test FPR (1% target)",
    "test_fpr_at_10pct_target": "Observed test FPR (10% target)",
}


def draw_grouped_metrics(summary, out, bootstrap):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.ticker import PercentFormatter
    palette={"LoRA":"#2166A4", "DP-LoRA":"#DB842B", "FIBNA":"#17957D"}
    figure_dir=out/"comparison_graphs"
    figure_dir.mkdir(parents=True,exist_ok=True)
    attacks=[a for a in ALL_ATTACKS if a in set(summary.attack)]
    x=np.arange(len(attacks)); width=.26
    for metric,label in PLOT_METRICS.items():
        fig,ax=plt.subplots(figsize=(max(12,1.25*len(attacks)),5.6))
        for i,method in enumerate(METHODS):
            sub=summary.loc[summary.model.eq(method)].set_index("attack").reindex(attacks)
            vals=pd.to_numeric(sub[metric],errors="coerce").to_numpy(dtype=float)
            ci_lo=metric+"_ci95_low";ci_hi=metric+"_ci95_high"
            yerr=None
            if bootstrap and ci_lo in sub and ci_hi in sub:
                lo=pd.to_numeric(sub[ci_lo],errors="coerce").to_numpy(dtype=float)
                hi=pd.to_numeric(sub[ci_hi],errors="coerce").to_numpy(dtype=float)
                if np.all(np.isfinite(lo)) and np.all(np.isfinite(hi)):
                    yerr=np.vstack((np.maximum(vals-lo,0),np.maximum(hi-vals,0)))
            ax.bar(x+(i-1)*width,vals,width,color=palette[method],label=method,
                   edgecolor="white",linewidth=.7,yerr=yerr,capsize=2 if yerr is not None else 0,zorder=3)
        if metric=="roc_auc_calibrated":
            ax.axhline(.5,color="gray",ls="--",lw=1,label="Chance AUC = 0.50")
        if metric=="f1" and "all_member_f1_baseline" in summary:
            ax.axhline(float(summary.all_member_f1_baseline.median()),color="gray",ls="--",lw=1,
                       label="Predict-all-members baseline")
        if metric=="test_fpr_at_1pct_target":ax.axhline(.01,color="gray",ls="--",lw=1)
        if metric=="test_fpr_at_10pct_target":ax.axhline(.10,color="gray",ls="--",lw=1)
        ax.set_xticks(x);ax.set_xticklabels(attacks,rotation=28,ha="right")
        ax.set_ylabel(label);ax.set_xlabel("Membership inference attack")
        ax.set_title(f"Llama-3.2-1B on MeDAL: {label}")
        if "fpr" in metric or metric.startswith("tpr_"):
            ax.yaxis.set_major_formatter(PercentFormatter(xmax=1,decimals=1))
        ax.set_axisbelow(True);ax.grid(axis="y",alpha=.2)
        ax.legend(ncol=2,fontsize=9)
        fig.tight_layout()
        name=figure_dir/f"mia_comparison_{metric}"
        fig.savefig(str(name)+".png",dpi=300,bbox_inches="tight")
        fig.savefig(str(name)+".svg",bbox_inches="tight")
        plt.close(fig)
    # Detailed point-and-interval figures, useful when all AUCs cluster near 0.5.
    for metric, chart_title, ci_stem in [
        ("roc_auc_calibrated", "Calibrated ROC-AUC", "auc"),
        ("f1", "F1-score", "f1"),
    ]:
        fig, ax = plt.subplots(figsize=(13.2, 5.8))
        offsets = [-0.18, 0, 0.18]
        for offset, method in zip(offsets, METHODS):
            sub = summary.loc[summary.model.eq(method)].set_index("attack").reindex(attacks)
            val = pd.to_numeric(sub[metric], errors="coerce").to_numpy(dtype=float)
            low_col, high_col = ci_stem + "_ci95_low", ci_stem + "_ci95_high"
            if low_col in sub and high_col in sub:
                low = pd.to_numeric(sub[low_col], errors="coerce").to_numpy(dtype=float)
                high = pd.to_numeric(sub[high_col], errors="coerce").to_numpy(dtype=float)
                errs = np.vstack((np.maximum(0, val-low), np.maximum(0, high-val)))
            else:
                errs = np.zeros((2, len(attacks)))
            ax.errorbar(np.arange(len(attacks))+offset, val, yerr=errs,
                        fmt="o", linestyle="none", capsize=3, markersize=5,
                        color=palette[method], label=method, elinewidth=1)
        if metric == "roc_auc_calibrated":
            ax.axhline(0.5, color="#657585", linestyle="--", label="Chance AUC = 0.50")
        ax.set_xticks(np.arange(len(attacks)))
        ax.set_xticklabels(attacks, rotation=28, ha="right")
        ax.set_ylabel(chart_title)
        ax.set_title(f"MeDAL | Llama-3.2-1B | {chart_title} (95% bootstrap confidence intervals)")
        ax.grid(axis="y", alpha=0.22, linestyle=":")
        ax.legend(ncol=4, fontsize=9)
        fig.tight_layout()
        stem=figure_dir / f"llama32_medal_mia_{metric}_detail"
        for extension in ("png", "svg", "pdf"):
            fig.savefig(str(stem)+"."+extension, dpi=300, bbox_inches="tight")
        plt.close(fig)
    # Export wide metric tables to facilitate direct insertion into the manuscript.
    for metric in PLOT_METRICS:
        matrix = summary.pivot(index="attack", columns="model", values=metric)
        matrix.reindex(index=attacks, columns=METHODS).to_csv(figure_dir / f"metric_table_{metric}.csv")
    # Compact multi-panel overview, consistent with the GPT-2-Large benchmark.
    panel_metrics = ["roc_auc_calibrated", "tpr_at_1pct_fpr", "tpr_at_10pct_fpr", "f1"]
    fig, axes = plt.subplots(2, 2, figsize=(15, 9))
    for ax, met in zip(axes.ravel(), panel_metrics):
        for i, method in enumerate(METHODS):
            vals = summary.loc[summary.model.eq(method)].set_index("attack").reindex(attacks)[met].to_numpy(dtype=float)
            ax.bar(x + (i-1) * width, vals, width, label=method, color=palette[method])
        if met == "roc_auc_calibrated":
            ax.axhline(.5, ls="--", color="gray", linewidth=1)
        ax.set_xticks(x)
        ax.set_xticklabels(attacks, rotation=35, ha="right", fontsize=8)
        ax.set_ylabel(PLOT_METRICS[met]);ax.grid(axis="y", alpha=.18);ax.set_axisbelow(True)
        if met in ("tpr_at_1pct_fpr", "tpr_at_10pct_fpr"):
            ax.yaxis.set_major_formatter(PercentFormatter(xmax=1, decimals=1))
    axes[0, 0].legend(ncol=3, fontsize=9)
    fig.suptitle("Llama-3.2-1B on MeDAL: membership inference comparison")
    fig.tight_layout()
    for ext in ("png", "pdf"):
        fig.savefig(figure_dir / f"llama32_medal_mia_primary_four_panel.{ext}", dpi=300, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved eight grouped plots, detailed AUC/F1, four-panel summary, and metric tables: {figure_dir}")




def write_likelihood_health(out, manifest):
    """Report extreme LM likelihoods, without silently classifying model damage as privacy."""
    rows = []
    for method in METHODS:
        p = out / f"scores_{method}.csv"
        if not p.is_file():
            continue
        x = pd.read_csv(p, usecols=["sample_id", "score_ppl", "score_minkpp", "score_entropy"])
        if x.empty:
            continue
        x = x.merge(manifest[["sample_id"]], on="sample_id", how="inner", validate="one_to_one")
        if x.empty:
            continue
        logp = pd.to_numeric(x.score_ppl, errors="coerce")
        low = pd.to_numeric(x.score_minkpp, errors="coerce")
        row = {
            "model": method, "n": int(logp.notna().sum()),
            "mean_token_logp": float(logp.mean()),
            "median_token_logp": float(logp.median()),
            "p05_token_logp": float(logp.quantile(.05)),
            "n_mean_token_logp_below_minus_30": int((logp < -30).sum()),
            "n_abs_minkpp_over_1e6": int((low.abs() > 1e6).sum()),
            "warning": "Extreme likelihood / possible checkpoint or quality issue" if logp.median() < -30 else "",
        }
        rows.append(row)
        if row["warning"]:
            warnings.warn(f"{method}: median token log-probability {row['median_token_logp']:.2f}. "
                          "Investigate checkpoint quality, tokenizer and LoRA alpha before claiming attack resistance.")
    if rows:
        dest = out / "model_likelihood_health.csv"
        pd.DataFrame(rows).to_csv(dest, index=False)
        print("Wrote likelihood health audit:", dest)


def report(args, out, make_plots=True):
    manifest_path=out / "sample_manifest.csv"
    if not manifest_path.exists():raise FileNotFoundError("No manifest; run inference first")
    manifest=pd.read_csv(manifest_path,dtype={"sample_id":str})
    required_ids=set(manifest.sample_id)
    # A standalone report may only use scores created by the checkpoint-verified runner.
    for meth in METHODS:
        scores_file = out / f"scores_{meth}.csv"
        prov_file = out / f"score_provenance_{meth.replace('-', '_')}.json"
        if scores_file.exists() and scores_file.stat().st_size > len(",".join(SCORE_FIELDS)) + 3:
            if not prov_file.is_file():
                raise RuntimeError(f"{meth}: score file lacks checkpoint-verification provenance: {prov_file}")
            provenance = json.loads(prov_file.read_text(encoding="utf-8"))
            if provenance.get("manifest_sha256") != sha256_file(out / "sample_manifest.csv"):
                raise RuntimeError(f"{meth}: sample manifest changed since scoring")
    imported=external_scores(args,manifest)
    rows=[]; records=[]
    for method in METHODS:
        f=out / f"scores_{method}.csv"
        model_scores = pd.read_csv(f,dtype={"sample_id":str}) if f.exists() else pd.DataFrame()
        if not model_scores.empty:
            if model_scores.sample_id.duplicated().any():raise RuntimeError(f"Repeated score IDs in {f}")
            if not set(model_scores.sample_id).issubset(required_ids):raise RuntimeError(f"Unknown ID in {f}")
            model_scores=model_scores.merge(manifest[["sample_id","split","label"]],on="sample_id",how="left",validate="one_to_one",suffixes=("_saved",""))
        for attack in ALL_ATTACKS:
            if attack in SCORE_MAP and not model_scores.empty:
                col=SCORE_MAP[attack]
                src=model_scores[["sample_id","label","split",col]].rename(columns={col:"score"}).copy()
            elif attack in EXTERNAL_ATTACKS and not imported.empty:
                src=imported[(imported.model==method)&(imported.attack==attack)][["sample_id","score"]]
                src=src.merge(manifest[["sample_id","label","split"]],on="sample_id",how="left",validate="one_to_one")
            else:
                src=pd.DataFrame()
            if len(src):
                src["score"]=pd.to_numeric(src.score,errors="coerce")
                src=src[np.isfinite(src.score)].copy()
                # Save every model × attack experiment separately, including
                # partial data; no scoring values are silently fabricated.
                safe_attack = re.sub(r"[^A-Za-z0-9_-]+", "_", attack)
                per_attack = src[["sample_id","label","split","score"]].copy()
                per_attack.rename(columns={"score":"raw_score"}).to_csv(
                    out / f"per_example_{method}_{safe_attack}.csv",index=False)
                for _,r in src.iterrows():
                    records.append({"sample_id":r.sample_id,"model":method,"attack":attack,
                                    "label":int(r.label),"split":r.split,"raw_score":float(r.score)})
            n_expected=len(manifest)
            # Do not quietly measure different attack subsets or incomplete runs.
            if len(src)!=n_expected:
                rows.append({"model":method,"attack":attack,"status":f"INCOMPLETE {len(src)}/{n_expected}: no metrics"})
                continue
            result=assess_one(src,method,attack,args)
            if result is None:rows.append({"model":method,"attack":attack,"status":"INSUFFICIENT CAL/TEST DATA"})
            else:rows.append(result)
    write_likelihood_health(out, manifest)
    result_df=pd.DataFrame(rows)
    result_df.to_csv(out / "mia_summary.csv",index=False)
    pd.DataFrame(records).to_csv(out / "all_per_example_attack_scores.csv",index=False)
    # Separate wide table useful for manuscripts, unmeasured attacks remain blank.
    show_cols=["model","attack","f1","tpr_at_1pct_fpr","tpr_at_10pct_fpr","roc_auc_calibrated","status"]
    for c in show_cols:
        if c not in result_df:result_df[c]=np.nan
    summary=result_df[show_cols].copy()
    summary.to_csv(out / "table_for_manuscript.csv",index=False)
    for method in METHODS:
        summary[summary.model==method].to_csv(out/f"table_{method}.csv",index=False)
    print("\n=== MIA summary (calibrated scores on independent held-out test set) ===")
    with pd.option_context('display.max_rows',100,'display.width',180):
        print(summary.to_string(index=False,float_format=lambda x:f'{x:.4f}'))
    print("Wrote",out / "mia_summary.csv")
    if make_plots and not args.no_plot:
        keep = result_df[result_df.status == "computed"].copy()
        if len(keep):
            # Plot only attacks computed for all 3 methods; never display missing metrics as zeros.
            valid_attacks = set.intersection(*(set(keep.loc[keep.model == m,"attack"]) for m in METHODS))
            keep = keep[keep.attack.isin(valid_attacks)].copy()
            if not keep.empty:
                keep["all_member_f1_baseline"] = 2 * keep.n_test_members / (2 * keep.n_test_members + keep.n_test_nonmembers)
                draw_grouped_metrics(keep, out, args.bootstrap)
    return result_df


def main():
    args = get_args()
    if (args.max_tokens < args.min_tokens or not 0 < args.calibration_fraction < 1 or
            not 0 < args.k_percent <= 100 or args.train_size <= 0 or args.test_size < 0 or
            args.extra_validation_nonmembers < 0 or args.require_per_class < 0):
        raise ValueError("Invalid data selection or attack hyperparameters")
    out = Path(args.output).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)
    if args.report_only:
        report(args, out)
        return
    if args.inspect_only:
        inspect_sources(args)
        return
    if not (args.verify_only or args.trust_membership):
        raise SystemExit("Membership audit requires --trust-membership: confirm exact training membership for ALL 3 checkpoints and no train/test leakage.")
    if args.verify_only:
        inspect_sources(args)
    else:
        verify_run_config(args, out)
    preflight_model_architectures(args)
    deps = load_transformers()
    torch, AutoTokenizer, *_ = deps
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    device = torch_device(torch, args)
    print("Device:", device)
    if args.verify_only:
        for method,path in zip(METHODS, [args.lora,args.dp_lora,args.fibna]):
            if args.verify_method != "all" and method != args.verify_method:
                continue
            model = load_target(path, method, args, device, deps, out)
            del model; gc.collect()
            if torch.cuda.is_available(): torch.cuda.empty_cache()
        print(f"CHECKPOINT VERIFICATION PASSED: {args.verify_method}. No member/nonmember scoring performed.")
        return
    tokenizer = AutoTokenizer.from_pretrained(args.model_id)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    rows = choose_data(args, out, tokenizer)
    if args.prepare_only:
        print("Selection and membership exclusion audit ready. No GPU inference performed.")
        return
    # Before any expensive reference/Neighborhood scoring, verify all three model states.
    # When the quality smoke check is enabled it performs verification for each model
    # and also compares a few held-out likelihoods with the pretrained base.
    if args.quality_check_samples > 0:
        run_quality_smoke_check(rows,args,out,deps,device)
    else:
        for method,path in zip(METHODS, [args.lora,args.dp_lora,args.fibna]):
            model = load_target(path, method, args, device, deps, out)
            del model; gc.collect()
            if torch.cuda.is_available(): torch.cuda.empty_cache()
    reference = precompute_base_reference(rows,args,out,tokenizer,deps,device)
    neighbors = generate_t5_neighbors(rows,args,out,deps,device,tokenizer)
    for method,path in zip(METHODS, [args.lora,args.dp_lora,args.fibna]):
        evaluate_model(rows,args,out,deps,device,tokenizer,reference,neighbors,method,path)
    report_cmd = [sys.executable, str(Path(__file__).resolve()), "--report-only",
                  "--output", str(out), "--bootstrap", str(args.bootstrap), "--seed", str(args.seed)]
    if args.external_scores:
        report_cmd += ["--external-scores", str(args.external_scores)]
    if args.no_plot:
        report_cmd.append("--no-plot")
    if args.no_auto_report:
        print("Run report later: " + " ".join(report_cmd))
    else:
        finished = subprocess.run(report_cmd, check=False)
        if finished.returncode:
            raise SystemExit(f"Reporting subprocess failed ({finished.returncode}); all scores were preserved. Rerun: {' '.join(report_cmd)}")


if __name__=="__main__":
    main()
