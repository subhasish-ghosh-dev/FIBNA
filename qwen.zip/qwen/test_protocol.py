#!/usr/bin/env python
"""No-GPU tests: frozen XSum cohort, completion mask, SHAP weights and MIAs."""
from __future__ import annotations
import tempfile,sys,types
from pathlib import Path
import numpy as np
from xsum_common import XSumCodec,audit
from fibna_math import coalition_matrix,kernelshap_wls
from mia_math import ez_score,metrics_for_score

class ToyTokenizer:
    eos_token_id=2
    pad_token_id=2
    def encode(self,text,add_special_tokens=False):
        return [5+(len(w)*7+sum(map(ord,w)))%240 for w in text.split()]


def main():
    tok=ToyTokenizer();codec=XSumCodec(tok,max_length=64,max_target_tokens=10)
    ex=codec.example('test article about long-term science research','A short news summary.')
    assert len(ex['input_ids'])==len(ex['labels'])<=64
    assert ex['input_ids'][-1]==tok.eos_token_id
    assert all(q==-100 for q in ex['labels'][:-len(codec.summary_ids('A short news summary.'))])
    assert len(codec.prompt_ids('a '*1000)) +len(codec.summary_ids('a '*50))<=64
    rng=np.random.default_rng(42)
    masks=coalition_matrix(3,8,rng)
    target=np.array([.5,-1.25,2.0]); values=(masks@target + .7)[:,None]
    phi=kernelshap_wls(masks,values)
    assert np.allclose(phi[:,0],target,atol=1e-4),(phi,target)
    score=ez_score(np.array([-1,-2,-3]),np.array([-2,-1,-4]),np.array([1,1,1]),np.ones(3,bool))
    assert np.isfinite(score) and score>0
    import pandas as pd
    rng=np.random.default_rng(42)
    rows=[]
    for split,n in [('attack_calibration',100),('attack_test',100)]:
        for member in [0,1]:
            for i in range(n):
                rows.append({'attack_split':split,'membership':member,'s':rng.normal(member*.5,1)})
    df=pd.DataFrame(rows)
    m=metrics_for_score(df,df.s,bootstrap=10,seed=42)
    assert 0<=m['roc_auc']<=1 and 0<=m['tpr_at_1pct_fpr']<=1
    # Simulate HF Dataset records to test deterministic split writes and replay verification.
    def records(split,n):
        return [{'id':f'{split}{i}','document':f'{split} scientific news document {i}',
                 'summary':f'A unique summary number {i} from {split}.'} for i in range(n)]
    class FakeDS(dict):pass
    fake=FakeDS(train=records('train',5101),validation=records('val',20),test=records('test',20))
    fake_module=types.ModuleType('datasets');fake_module.load_dataset=lambda name:fake
    prev=sys.modules.get('datasets');sys.modules['datasets']=fake_module
    try:
        from prepare_xsum import create
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)/'frozen'
            create(root,42,2500,4,4,4)
            meta,parts=audit(root)
            assert len(parts['attack_all.csv'])==5000
            assert len(parts['target_train.csv'])==2500
            assert all(x in (0,1) for x in parts['attack_test.csv'].membership)
            assert len(parts['attack_test.csv'])==2000
    finally:
        if prev is not None:sys.modules['datasets']=prev
        else:sys.modules.pop('datasets',None)
    print('PASS: XSum codec/immutable cohorts, KernelSHAP, EZ and calibrated attack metrics')

if __name__=='__main__':main()
