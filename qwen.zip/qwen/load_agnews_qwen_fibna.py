#!/usr/bin/env python3
"""Load the complete Qwen/AG News FIBNA checkpoint for utility and MIAs.

FIBNA == pretrained base + LoRA adapter + FP32 LM-head delta.
Adapter-only loading is invalid and is refused when FIBNA checkpoint metadata
is present. The underlying Qwen original tied input/output weights are
intentionally untied for FP32 output-only FIBNA perturbation.
"""
from __future__ import annotations
import json
from pathlib import Path


def load_fibna_model(run_dir, base_model='Qwen/Qwen2.5-1.5B', dtype='bf16', device='cuda:0'):
    import torch
    import torch.nn as nn
    from transformers import AutoModelForCausalLM
    from peft import PeftModel
    from safetensors import safe_open

    root=Path(run_dir)
    conf_file=root/'fibna_checkpoint.json'
    if not conf_file.is_file():raise FileNotFoundError('Missing FIBNA checkpoint metadata: '+str(conf_file))
    conf=json.loads(conf_file.read_text(encoding='utf8'))
    if conf['base']!=base_model or conf.get('formal_DP') is not False:
        raise RuntimeError('FIBNA provenance mismatch')
    path=root/conf['head_delta_file']
    if not path.is_file():
        raise FileNotFoundError('Missing LM-head delta. Adapter alone is NOT a FIBNA checkpoint: '+str(path))
    adapter=root/conf['adapter_dir']
    if not (adapter/'adapter_config.json').is_file():raise FileNotFoundError(adapter/'adapter_config.json')
    dtype_pt={'bf16':torch.bfloat16,'fp16':torch.float16,'fp32':torch.float32}[dtype]
    try:
        base=AutoModelForCausalLM.from_pretrained(base_model,torch_dtype=dtype_pt)
    except TypeError:
        base=AutoModelForCausalLM.from_pretrained(base_model,dtype=dtype_pt)
    tied=base.get_input_embeddings().weight.data_ptr()==base.get_output_embeddings().weight.data_ptr()
    if not tied:
        raise RuntimeError('Base no longer ties its input/output embeddings; inspect model revision')

    class FP32OutputHead(nn.Module):
        def __init__(self,orig):
            super().__init__()
            self.weight=nn.Parameter(orig.weight.detach().float().clone(),requires_grad=False)
        def forward(self,hidden):
            with torch.autocast(device_type='cuda',enabled=False):
                return torch.nn.functional.linear(hidden.float(),self.weight)
    base.set_output_embeddings(FP32OutputHead(base.get_output_embeddings()))
    with safe_open(str(path),framework='pt',device='cpu') as safetensors_file:
        delta=safetensors_file.get_tensor('lm_head_delta')
    head=base.get_output_embeddings().weight
    if delta.shape!=head.shape or delta.dtype!=torch.float32:
        raise RuntimeError(f'LM-head delta incompatible: {tuple(delta.shape)} {delta.dtype}, expected {tuple(head.shape)} float32')
    if not torch.isfinite(delta).all():raise FloatingPointError('Corrupt nonfinite LM-head delta')
    with torch.no_grad():head.add_(delta)
    model=PeftModel.from_pretrained(base,str(adapter),is_trainable=False)
    if model.get_output_embeddings().weight.data_ptr()==model.get_input_embeddings().weight.data_ptr():
        raise RuntimeError('The output and input embeddings were re-tied; FIBNA head delta not preserved')
    model=model.to(device).eval()
    model.config.use_cache=False
    return model
