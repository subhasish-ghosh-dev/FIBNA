#!/usr/bin/env python3
"""Compare real, completed 5-epoch AG News training overhead across methods.

No timings or memory values are estimated or imputed. All model scripts must
export overhead_summary.json with the same synchronized timing protocol.
"""
from __future__ import annotations
import argparse
import csv
import json
import math
from pathlib import Path

METHODS = ('LoRA', 'DP-LoRA', 'FIBNA')
FIELDS = ('model', 'data_sha256', 'epochs', 'train_count', 'max_length',
          'validation_schedule', 'gpu', 'dtype')
REQUIRED = ('training_wall_seconds', 'peak_gpu_training_allocated_gib',
            'peak_gpu_training_reserved_gib', 'optimizer_steps')


def load(path: str, method: str) -> dict:
    path = Path(path)
    if path.is_dir():
        path = path / 'overhead_summary.json'
    if not path.is_file():
        raise FileNotFoundError(f'{method}: measured overhead summary missing: {path}')
    record = json.loads(path.read_text(encoding='utf-8'))
    if record.get('method') != method:
        raise ValueError(f'{path}: expected method={method}, got {record.get("method")}')
    if not record.get('training_finished'):
        raise ValueError(f'{path}: training_finished is not true; cannot report incomplete training')
    if record.get('is_pilot'):
        raise ValueError(f'{path}: pilot data are not comparable to full runs')
    for key in REQUIRED:
        value = record.get(key)
        if not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
            raise ValueError(f'{path}: missing or invalid measured {key}={value}')
    return record


def percent(candidate: float, baseline: float) -> float:
    return 100.0 * (candidate - baseline) / baseline


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lora', required=True, help='LoRA overhead_summary.json or directory')
    parser.add_argument('--dp-lora', required=True, help='DP-LoRA overhead_summary.json or directory')
    parser.add_argument('--fibna', required=True, help='FIBNA overhead_summary.json or directory')
    parser.add_argument('--out', default='agnews_overhead_comparison.csv')
    parser.add_argument('--tex', default='agnews_overhead_comparison.tex',
                        help='Measured-overhead LaTeX table path')
    a = parser.parse_args()
    specs = {'LoRA': a.lora, 'DP-LoRA': a.dp_lora, 'FIBNA': a.fibna}
    records = {m: load(specs[m], m) for m in METHODS}
    reference = records['LoRA']
    if reference['epochs'] != 5 or reference['train_count'] != 10000:
        raise ValueError('For this manuscript configuration require 5 epochs and 10,000 target texts')
    for method in METHODS[1:]:
        cur = records[method]
        different = [(f, reference.get(f), cur.get(f)) for f in FIELDS
                     if reference.get(f) != cur.get(f)]
        if different:
            raise ValueError(f'{method}: protocol mismatch, cannot calculate comparable differences: {different}')
    rows = []
    for method in METHODS:
        m = records[method]
        rows.append({
            'method': method,
            'epochs': m['epochs'],
            'n_training_examples': m['train_count'],
            'optimizer_steps': m['optimizer_steps'],
            'training_wall_seconds': round(m['training_wall_seconds'], 3),
            'training_wall_hours': round(m['training_wall_seconds'] / 3600, 4),
            'training_overhead_vs_lora_pct': round(percent(m['training_wall_seconds'], reference['training_wall_seconds']), 2),
            'peak_gpu_allocated_gib': round(m['peak_gpu_training_allocated_gib'], 3),
            'gpu_allocated_overhead_vs_lora_pct': round(percent(m['peak_gpu_training_allocated_gib'], reference['peak_gpu_training_allocated_gib']), 2),
            'peak_gpu_reserved_gib': round(m['peak_gpu_training_reserved_gib'], 3),
            'gpu_reserved_overhead_vs_lora_pct': round(percent(m['peak_gpu_training_reserved_gib'], reference['peak_gpu_training_reserved_gib']), 2),
            'seconds_per_optimizer_step': round(m['training_wall_seconds'] / m['optimizer_steps'], 3),
        })
    target = Path(a.out)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('w', encoding='utf-8', newline='') as fh:
        writer = csv.DictWriter(fh, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    tex_lines = [
        r'\begin{table}[htbp]',
        r'\centering',
        r'\small',
        r'\caption{Measured five-epoch training overhead on Qwen2.5-1.5B/AG News (10,000 examples). Runtime excludes validation and checkpoint saving. GPU memory is peak PyTorch CUDA allocated memory.}',
        r'\label{tab:demia_train_overhead}',
        r'\begin{tabular}{lrrrr}',
        r'\hline',
        r'Fine-tuning & Training (h) & Peak GPU (GiB) & Time $\Delta$ (\%) & Memory $\Delta$ (\%) \\',
        r'\hline',
    ]
    for row in rows:
        tex_lines.append(f'{row["method"]} & {row["training_wall_hours"]:.4f} & '
                         f'{row["peak_gpu_allocated_gib"]:.3f} & '
                         f'{row["training_overhead_vs_lora_pct"]:+.2f} & '
                         f'{row["gpu_allocated_overhead_vs_lora_pct"]:+.2f} ' + r'\\')
    tex_lines.extend([r'\hline',r'\end{tabular}',r'\end{table}'])
    Path(a.tex).write_text('\n'.join(tex_lines) + '\n', encoding='utf-8')
    print('PASS: three completed runs compared using actual GPU measurements')
    for r in rows:
        print(f'{r["method"]:8s} train={r["training_wall_hours"]:>9.4f} h | '
              f'peak allocated={r["peak_gpu_allocated_gib"]:>7.3f} GiB | '
              f'time delta={r["training_overhead_vs_lora_pct"]:>+8.2f}% | '
              f'memory delta={r["gpu_allocated_overhead_vs_lora_pct"]:>+8.2f}%')
    print('Saved CSV:', target.resolve())
    print('Saved LaTeX:', Path(a.tex).resolve())


if __name__ == '__main__':
    main()
