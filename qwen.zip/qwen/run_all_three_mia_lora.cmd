@echo off
setlocal
REM Invoke from demia_multitask after extracting the package.
python test_attack_math.py || exit /b 1
python run_three_mia_agnews.py --stage audit || exit /b 1
python run_three_mia_agnews.py --stage score-target || exit /b 1
python run_three_mia_agnews.py --stage score-base || exit /b 1
python run_three_mia_agnews.py --stage score-icp || exit /b 1
python run_three_mia_agnews.py --stage report --bootstrap 1000 || exit /b 1
echo Real attack results saved in agnews_lora_qwen15_5ep\three_mia\attack_results.csv
