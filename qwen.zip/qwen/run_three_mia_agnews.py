#!/usr/bin/env python3
"""Paper-aligned AG News / Qwen LoRA MIA evaluation: EZ-MIA, Min-K%++, ICP-MIA.

Original integration for the user's completed, label-completion-only Qwen2.5-1.5B
AG News fine-tuning experiment. Not an unmodified run of any authors' code.

References:
  EZ-MIA: Ilic et al., ACL 2026 https://github.com/JetBrains-Research/ez-mia
  Min-K%++: Zhang et al., ICLR 2025 https://github.com/zjysteven/mink-plus-plus
  ICP-MIA: Lu et al., NDSS 2026 https://github.com/RPI-DSPlab/ICP-MIA

Uses exactly the existing AGNewsCodec; does not train or modify any target weights.
"""
from __future__ import annotations
import argparse, csv, hashlib, json, math, os, sys, time
from pathlib import Path
import numpy as np
import pandas as pd
from agnews_qwen_common import AGNewsCodec, LABELS, sha_file

PARTS = ('attack_train', 'attack_calibration', 'attack_test')


def manifest_and_samples(root: Path):
    meta_file = root / 'split_manifest.json'
    if not meta_file.is_file(): raise FileNotFoundError(meta_file)
    meta = json.loads(meta_file.read_text(encoding='utf-8'))
    for fn, digest in meta.get('file_sha256', {}).items():
        path=root/fn
        if not path.is_file() or sha_file(path)!=digest:
            raise RuntimeError(f'Immutable AG News split missing/changed: {path}')
    if meta.get('base_model') != 'Qwen/Qwen2.5-1.5B':
        raise RuntimeError('Unexpected base model; adapt the protocol deliberately')
    parts=[]
    for split in PARTS:
        f=root/f'{split}.csv'
        df=pd.read_csv(f, keep_default_na=False, dtype={'sample_id':str, 'text_hash':str})
        needed={'sample_id','text','label_id','membership','text_hash','completion'}
        if not needed.issubset(df):raise RuntimeError(f'{f} missing {needed-set(df)}')
        df['attack_split']=split
        df['label_id']=df.label_id.astype(int)
        df['membership']=df.membership.astype(int)
        if df.sample_id.duplicated().any() or df.text_hash.duplicated().any():
            raise RuntimeError(f'{f} duplicates')
        if (df['completion'] != df.label_id.map(lambda i: ' '+LABELS[i])).any():
            raise RuntimeError(f'{f} labels/completions incompatible with training tokenizer')
        if set(df.membership)!={0,1}:raise RuntimeError(f'{f} missing member/nonmember class')
        parts.append(df)
    full=pd.concat(parts,ignore_index=True)
    if full.sample_id.duplicated().any() or full.text_hash.duplicated().any():
        raise RuntimeError('Candidates reused across attack partitions')
    target=pd.read_csv(root/'target_train.csv', dtype={'text_hash':str}, usecols=['text_hash'])
    members=set(full.loc[full.membership.eq(1),'text_hash'])
    nonmembers=set(full.loc[full.membership.eq(0),'text_hash'])
    training=set(target.text_hash)
    if not members.issubset(training) or nonmembers.intersection(training):
        raise RuntimeError('Membership labels inconsistent with target training manifest')
    if len(full)!=5000 or any(len(p)!=n for p,n in zip(parts,[2000,1000,2000])):
        raise RuntimeError('Unexpected attack candidate counts; inspect original split')
    # All three attacks are training-free. The 2,000 attack-training examples
    # remain reserved and are not used to score, calibrate, or select an attack.
    scored=full.loc[full.attack_split.ne('attack_train')].reset_index(drop=True)
    assert len(scored)==3000
    return meta, scored


def adapter_fingerprint(path: Path):
    if not path.is_dir() or not (path/'adapter_config.json').is_file():
        raise RuntimeError('Expected a PEFT adapter folder with adapter_config.json: '+str(path))
    files=[p for p in path.rglob('*') if p.is_file() and (p.name.endswith('.safetensors') or p.name.endswith('.bin') or p.name=='adapter_config.json')]
    if not files:raise RuntimeError('No model weights for adapter')
    h=hashlib.sha256()
    for f in sorted(files):
        h.update(str(f.relative_to(path)).encode()); h.update(sha_file(f).encode())
    return h.hexdigest()


def check_target_summary(summary_path:Path, a, data_root, meta):
    if not summary_path.is_file():raise FileNotFoundError(summary_path)
    summary=json.loads(summary_path.read_text(encoding='utf-8'))
    if summary.get('is_pilot') or int(summary.get('epochs',0))!=5:
        raise RuntimeError('Publication attack requires the non-pilot 5-epoch target')
    if summary.get('model')!=meta['base_model']:
        raise RuntimeError('Target base model mismatch')
    if summary.get('target_train_csv_sha256')!=sha_file(data_root/'target_train.csv'):
        raise RuntimeError('Target training population hash mismatch')
    if summary.get('split_manifest_sha256')!=sha_file(data_root/'split_manifest.json'):
        raise RuntimeError('Split manifest hash mismatch')
    if summary.get('loss_mask')!='label completion and EOS tokens only':
        raise RuntimeError('Unknown target loss mask; this attack matches class-completion-only loss')
    if int(summary.get('max_length',0))!=a.max_length:
        raise RuntimeError('Attack must use the exact target 256-token tokenizer budget')
    return summary


def read_or_create_meta(file:Path, expected:dict):
    if file.exists():
        prev=json.loads(file.read_text(encoding='utf-8'))
        if prev!=expected: raise RuntimeError('Score provenance mismatch: '+str(file)+'\n'+json.dumps(prev,indent=2))
    else:
        file.parent.mkdir(parents=True,exist_ok=True)
        tmp=file.with_suffix('.tmp')
        tmp.write_text(json.dumps(expected,indent=2)+'\n',encoding='utf-8')
        tmp.replace(file)


def atomic_file_init(csv_path:Path, fields):
    if not csv_path.exists():
        with csv_path.open('w',newline='',encoding='utf-8') as f:csv.DictWriter(f,fieldnames=fields).writeheader()
    else:
        with csv_path.open(newline='',encoding='utf-8') as f:
            hdr=csv.DictReader(f).fieldnames
        if hdr!=fields:raise RuntimeError(f'Existing CSV has incompatible schema: {csv_path}')


def done_ids(path:Path, valid):
    if not path.exists():return set()
    d=pd.read_csv(path,usecols=['sample_id'],dtype={'sample_id':str})
    if d.sample_id.duplicated().any() or not set(d.sample_id).issubset(valid):
        raise RuntimeError(f'Corrupt or foreign cache {path}')
    return set(d.sample_id)


def load_model(a, mode):
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer
    if not torch.cuda.is_available():raise RuntimeError('CUDA required for Qwen scoring')
    dtype={'bf16':torch.bfloat16,'fp16':torch.float16,'fp32':torch.float32}[a.dtype]
    tok=AutoTokenizer.from_pretrained(a.base,use_fast=True)
    if tok.pad_token is None: tok.pad_token=tok.eos_token
    tok.padding_side='right'
    opts={'torch_dtype':dtype}
    try:model=AutoModelForCausalLM.from_pretrained(a.base,**opts)
    except TypeError:model=AutoModelForCausalLM.from_pretrained(a.base,dtype=dtype)
    if mode=='target':
        from peft import PeftModel
        model=PeftModel.from_pretrained(model,a.adapter,is_trainable=False)
    model.eval().to('cuda:0')
    model.config.use_cache=False
    return model,tok,torch


def token_statistics(logits, ids_shifted, completion_mask, is_target, chunk_size=32, ratio=.2):
    """Official Min-K%++ statistic: (log p_true - E_p log p) / SD_p log p.

    Computed in fp32 chunks, preserving the authors' categorical distribution
    mean/variance rather than approximating it by vocabulary-uniform statistics.
    """
    import torch
    import torch.nn.functional as F
    tgt=ids_shifted
    logpt=[]; errors=[]; zvals=[]
    for low in range(0,len(tgt),chunk_size):
        part=logits[low:low+chunk_size].float()
        tok=tgt[low:low+chunk_size]
        lp=F.log_softmax(part,dim=-1)
        obs=lp.gather(dim=1,index=tok[:,None]).squeeze(1)
        logpt.append(obs.cpu().numpy().astype(np.float32))
        if is_target:
            # Error zone is determined by target argmax, NOT base argmax.
            err=(part.argmax(-1)!=tok)
            errors.append(err.cpu().numpy().astype(np.uint8))
            probs=lp.exp()
            mu=(probs*lp).sum(-1)
            variance=(probs*(lp-mu[:,None]).square()).sum(-1).clamp_min(1e-14)
            z=(obs-mu)/variance.sqrt()
            zvals.append(z.cpu().numpy().astype(np.float32))
        del part,lp
    lps=np.concatenate(logpt)
    if not is_target:return {'logp':lps}
    er=np.concatenate(errors); z=np.concatenate(zvals)
    def lowest(mask):
        selected=z[mask]
        if len(selected)==0:return float('nan')
        kk=max(1,int(len(selected)*ratio))
        return float(np.partition(selected,kk-1)[:kk].mean())
    return {'logp':lps,'errors':er,'min_k_pp_full':lowest(np.ones(len(z),bool)),
            'min_k_pp_completion':lowest(completion_mask),'n_error_full':int(er.sum()),
            'n_error_completion':int(er[completion_mask].sum())}


def score_model(a, data, which):
    from tqdm import tqdm
    root=Path(a.out); root.mkdir(parents=True,exist_ok=True)
    csv_path=root/f'{which}_tokens.csv'
    ck_hash=adapter_fingerprint(Path(a.adapter)) if which=='target' else 'original-pretrained-base'
    meta={'stage':which,'dataset_sha256':sha_file(Path(a.data)/'split_manifest.json'),
          'target_train_sha256':sha_file(Path(a.data)/'target_train.csv'),
          'target_checkpoint':ck_hash if which=='target' else None,
          'base':a.base,'max_length':a.max_length,'dtype':a.dtype,'min_k_ratio':a.min_k_ratio,
          'tokenizer_mode':'AGNewsCodec training segment-wise, completion + EOS'}
    read_or_create_meta(root/f'{which}_tokens.provenance.json',meta)
    fields=['sample_id','attack_split','membership','label_id','ids_sha256','n_tokens',
            'n_completion_tokens','logp_json','error_json','min_k_pp_full',
            'min_k_pp_completion','n_error_full','n_error_completion'] if which=='target' else [
            'sample_id','attack_split','membership','label_id','ids_sha256','n_tokens','logp_json']
    atomic_file_init(csv_path,fields)
    done=done_ids(csv_path,set(data.sample_id))
    todo=data.loc[~data.sample_id.isin(done)]
    if a.limit>0:todo=todo.iloc[:a.limit]
    print(f'{which}: {len(todo)} candidates remaining (total {len(data)})',flush=True)
    if todo.empty:return
    model,tok,torch=load_model(a,which)
    codec=AGNewsCodec(tok,a.max_length)
    device=torch.device('cuda:0')
    start=time.perf_counter()
    with csv_path.open('a',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields)
        for j, row in enumerate(tqdm(todo.itertuples(index=False),total=len(todo),desc=which)):
            ex=codec.example(row.text,int(row.label_id))
            seq=ex['input_ids']
            labs=np.asarray(ex['labels'][1:]); cmask=labs!=-100
            x=torch.tensor([seq],dtype=torch.long,device=device)
            with torch.inference_mode():
                logits=model(input_ids=x,use_cache=False).logits[0,:-1]
                stats=token_statistics(logits,x[0,1:],cmask,which=='target',a.vocab_chunk,a.min_k_ratio)
            rec={'sample_id':row.sample_id,'attack_split':row.attack_split,'membership':int(row.membership),
                 'label_id':int(row.label_id),'ids_sha256':hashlib.sha256(np.asarray(seq,dtype=np.int32).tobytes()).hexdigest(),
                 'n_tokens':len(seq)-1,'logp_json':json.dumps([float(t) for t in stats['logp']],separators=(',',':'))}
            if which=='target':
                rec.update({'n_completion_tokens':int(cmask.sum()),
                            'error_json':json.dumps([int(i) for i in stats['errors']],separators=(',',':')),
                            'min_k_pp_full':stats['min_k_pp_full'],
                            'min_k_pp_completion':stats['min_k_pp_completion'],
                            'n_error_full':stats['n_error_full'],'n_error_completion':stats['n_error_completion']})
            writer.writerow(rec)
            if (j+1)%a.flush_every==0:f.flush();print(f'Cached {j+1}/{len(todo)} | {time.perf_counter()-start:.0f}s',flush=True)
        f.flush()
    print('Saved:',csv_path.resolve())


def completion_score(model,codec,text,label_id,device,prefix=None,context_budget=768):
    import torch
    ex=codec.example(text,int(label_id))
    query=ex['input_ids']
    start=len(query)-sum(x!=-100 for x in ex['labels'])
    prefix=prefix or []
    total=prefix+query
    if len(total)>context_budget:return None
    x=torch.tensor([total],device=device,dtype=torch.long)
    # Log-likelihood of the same label-completion + EOS targets as fine-tuning.
    with torch.inference_mode():
        logits=model(input_ids=x,use_cache=False).logits[0]
        pos=torch.arange(len(prefix)+start-1,len(total)-1,device=device)
        ids=x[0,pos+1]
        out=logits[pos].float().log_softmax(-1).gather(-1,ids[:,None]).squeeze(1)
    return float(out.mean().cpu().item())


def get_icp_indices(a, data, pool):
    """Similarity-based ICP reference retrieval from independent utility validation corpus."""
    from sentence_transformers import SentenceTransformer
    from sklearn.preprocessing import normalize
    retrieval_path=Path(a.out)/'icp_retrieval.csv'
    provenance={'data_hash':sha_file(Path(a.data)/'split_manifest.json'),
                'pool_hash':sha_file(Path(a.data)/'utility_val.csv'),
                'encoder':a.icp_encoder,'retrieval_k':a.icp_candidates,'query_definition':'raw AG News article'}
    read_or_create_meta(Path(a.out)/'icp_retrieval.provenance.json',provenance)
    if retrieval_path.is_file():
        old=pd.read_csv(retrieval_path,dtype={'sample_id':str})
        if len(old)!=len(data) or set(old.sample_id)!=set(data.sample_id):
            raise RuntimeError('Incomplete or foreign ICP retrieval cache')
        return {r.sample_id:json.loads(r.pool_indices_json) for r in old.itertuples(index=False)}
    print('Building sentence-embedding similarity index; no membership labels used',flush=True)
    encoder=SentenceTransformer(a.icp_encoder,device='cpu')
    e_pool=encoder.encode(pool.text.astype(str).tolist(),batch_size=32,normalize_embeddings=True,show_progress_bar=True)
    e_q=encoder.encode(data.text.astype(str).tolist(),batch_size=32,normalize_embeddings=True,show_progress_bar=True)
    e_pool=np.asarray(e_pool,np.float32); e_q=np.asarray(e_q,np.float32)
    sims=e_q @ e_pool.T
    idx={};records=[]
    for i,s in enumerate(data.sample_id):
        candidate=np.argsort(-sims[i]); candidates=[]
        for p in candidate:
            p=int(p)
            if pool.iloc[p].text_hash==data.iloc[i].text_hash:continue
            candidates.append(p)
            if len(candidates)>=a.icp_candidates:break
        if len(candidates)<a.icp_candidates:raise RuntimeError('Insufficient independent ICP prefix pool')
        idx[str(s)]=candidates
        records.append({'sample_id':str(s),'pool_indices_json':json.dumps(candidates)})
    pd.DataFrame(records).to_csv(retrieval_path,index=False)
    return idx


def score_icp(a, data):
    from tqdm import tqdm
    root=Path(a.out);root.mkdir(parents=True,exist_ok=True)
    ck=adapter_fingerprint(Path(a.adapter))
    provenance={'attack':'ICP-MIA reference-data similarity probing, Qwen class-completion adaptation',
                'base_model':a.base,'checkpoint_sha256':ck,
                'dataset_sha256':sha_file(Path(a.data)/'split_manifest.json'),
                'pool_sha256':sha_file(Path(a.data)/'utility_val.csv'),
                'max_length':a.max_length,'icp_max_length':a.icp_max_length,
                'embedding_model':a.icp_encoder,'candidate_count':a.icp_candidates,
                'selection':'maximize query-label log-likelihood among similarity retrieved demonstrations',
                'score':'query-only mean logp minus best demonstrated mean logp'}
    read_or_create_meta(root/'icp.provenance.json',provenance)
    out=root/'icp_scores.csv'
    fields=['sample_id','attack_split','membership','label_id','icp_score','base_logp','best_demo_logp',
            'selected_demo_pool_row','n_prefix_candidates_scored']
    atomic_file_init(out,fields)
    finished=done_ids(out,set(data.sample_id))
    todo=data.loc[~data.sample_id.isin(finished)]
    if a.limit>0:todo=todo.iloc[:a.limit]
    print(f'ICP target: {len(todo)} remaining',flush=True)
    if todo.empty:return
    pool=pd.read_csv(Path(a.data)/'utility_val.csv',keep_default_na=False,dtype={'text_hash':str})
    if set(pool.text_hash) & set(data.text_hash):
        raise RuntimeError('ICP reference pool overlaps membership candidates')
    if set(pool.text_hash) & set(pd.read_csv(Path(a.data)/'target_train.csv',usecols=['text_hash']).text_hash):
        raise RuntimeError('ICP prefix pool overlaps target training data')
    indices=get_icp_indices(a,data,pool)
    model,tok,torch=load_model(a,'target')
    codec=AGNewsCodec(tok,a.max_length)
    device=torch.device('cuda:0')
    with out.open('a',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fields)
        for i,row in enumerate(tqdm(todo.itertuples(index=False),total=len(todo),desc='ICP')):
            plain=completion_score(model,codec,row.text,row.label_id,device,None,a.icp_max_length)
            if plain is None:raise RuntimeError('Query completion longer than ICP context budget')
            scores=[]
            for j in indices[row.sample_id]:
                demo=pool.iloc[int(j)]
                demo_tokens=codec.example(demo.text,int(demo.label_id))['input_ids']
                val=completion_score(model,codec,row.text,row.label_id,device,demo_tokens,a.icp_max_length)
                if val is not None:scores.append((val,int(j)))
            if not scores:raise RuntimeError('ICP context budget rejected all candidate demonstrations; raise --icp-max-length')
            best_ll,best_id=max(scores,key=lambda x:x[0])
            writer.writerow({'sample_id':row.sample_id,'attack_split':row.attack_split,
                            'membership':int(row.membership),'label_id':int(row.label_id),
                            'icp_score':plain-best_ll,'base_logp':plain,'best_demo_logp':best_ll,
                            'selected_demo_pool_row':best_id,'n_prefix_candidates_scored':len(scores)})
            if (i+1)%a.flush_every==0:f.flush()
        f.flush()
    print('Saved:',out.resolve())


def ez_score(target_lp,base_lp,errors,span):
    """EZ P/N score: positive versus negative log-probability movement at error tokens.

    Returns NaN when there are no error positions or no negative deltas; no fabricated
    membership score is assigned to an undefined P/N ratio.
    """
    use=np.asarray(errors,dtype=bool)&np.asarray(span,dtype=bool)
    if use.sum()==0:return float('nan')
    delta=np.asarray(target_lp,dtype=float)[use]-np.asarray(base_lp,dtype=float)[use]
    p=float(np.clip(delta,0,None).sum())
    n=float(np.clip(-delta,0,None).sum())
    if n==0:
        # Finite, declared epsilon convention for a zero downward-movement denominator.
        # Without this convention the paper's unsmoothed P/N ratio is unbounded.
        return p / 1e-12
    return p/n


def threshold_at_fpr(neg,rate):
    neg=np.asarray(neg,dtype=float)
    if not np.isfinite(neg).all() or not len(neg):raise RuntimeError('Bad calibration negatives')
    unique=np.sort(np.unique(neg))[::-1]
    threshold=float(np.nextafter(np.max(neg),np.inf));count=0
    for value in unique:
        n=int(np.count_nonzero(neg>=value))
        if n/len(neg)<=rate+1e-15:threshold=float(value);count=n
        else:break
    return threshold,count/len(neg)


def metrics_for_score(data,score,bootstrap=1000,seed=42):
    from sklearn.metrics import roc_auc_score
    data=data.copy();data['attack_score']=pd.to_numeric(score,errors='coerce')
    covered=data.attack_score.notna()&np.isfinite(data.attack_score)
    coverage=float(covered.mean())
    all_n=len(data);covered_data=data.loc[covered].copy()
    # At minimum the heldout test must have both membership classes.
    cal=covered_data[covered_data.attack_split.eq('attack_calibration')]
    tst=covered_data[covered_data.attack_split.eq('attack_test')]
    out={'n_total':all_n,'n_covered':int(covered.sum()),'coverage':coverage,
         'n_cal_nonmembers':int(cal.membership.eq(0).sum()),
         'n_test_members':int(tst.membership.eq(1).sum()),
         'n_test_nonmembers':int(tst.membership.eq(0).sum())}
    if min(out['n_cal_nonmembers'],out['n_test_members'],out['n_test_nonmembers'])<20:
        out['status']='insufficient_coverage'
        for field in ['threshold','calibration_fpr','roc_auc','tpr_at_1pct_fpr','observed_fpr']:
            out[field]=None
        return out
    if coverage<1:
        out['caveat']='Metrics conditional on covered samples. Not directly comparable to full-coverage attacks.'
    threshold,cal_fpr=threshold_at_fpr(cal.loc[cal.membership.eq(0),'attack_score'],.01)
    pred=tst.attack_score.to_numpy()>=threshold
    y=tst.membership.to_numpy(int)
    score_t=tst.attack_score.to_numpy(float)
    out.update({'threshold':threshold,'calibration_fpr':cal_fpr,
                'roc_auc':float(roc_auc_score(y,score_t)),
                'tpr_at_1pct_fpr':float(np.mean(pred[y==1])),
                'observed_fpr':float(np.mean(pred[y==0]))})
    if bootstrap:
        rng=np.random.default_rng(seed)
        groups=[np.flatnonzero(y==0),np.flatnonzero(y==1)]
        draws=[]
        for _ in range(bootstrap):
            ix=np.concatenate([rng.choice(g,len(g),replace=True) for g in groups])
            yy=y[ix];ss=score_t[ix];pp=ss>=threshold
            draws.append([roc_auc_score(yy,ss),np.mean(pp[yy==1]),np.mean(pp[yy==0])])
        q=np.quantile(draws,[.025,.975],axis=0)
        out['roc_auc_ci95']=[float(q[0,0]),float(q[1,0])]
        out['tpr_ci95']=[float(q[0,1]),float(q[1,1])]
        out['observed_fpr_ci95']=[float(q[0,2]),float(q[1,2])]
    return out


def report(a,data):
    root=Path(a.out)
    required=[root/'target_tokens.csv',root/'base_tokens.csv',root/'icp_scores.csv']
    for p in required:
        if not p.is_file():raise FileNotFoundError(f'Run all scoring stages first: {p}')
    expected_data=sha_file(Path(a.data)/'split_manifest.json')
    expected_adapter=adapter_fingerprint(Path(a.adapter))
    for stage, file in [('target','target_tokens.provenance.json'),('base','base_tokens.provenance.json'),('ICP','icp.provenance.json')]:
        p=root/file
        if not p.is_file():raise RuntimeError(f'Missing attack provenance {p}')
        prov=json.loads(p.read_text(encoding='utf-8'))
        if prov.get('dataset_sha256')!=expected_data:
            raise RuntimeError(f'{stage} scores were computed against a different dataset')
        if stage=='target' and prov.get('target_checkpoint')!=expected_adapter:
            raise RuntimeError('Cached EZ/Min-K scores correspond to another target checkpoint')
        if stage=='ICP' and prov.get('checkpoint_sha256')!=expected_adapter:
            raise RuntimeError('Cached ICP scores correspond to another target checkpoint')
    t=pd.read_csv(required[0],dtype={'sample_id':str});b=pd.read_csv(required[1],dtype={'sample_id':str})
    icp=pd.read_csv(required[2],dtype={'sample_id':str})
    ids=set(data.sample_id)
    for name,tab in [('target',t),('base',b),('ICP',icp)]:
        if len(tab)!=len(ids) or set(tab.sample_id)!=ids or tab.sample_id.duplicated().any():
            raise RuntimeError(f'{name}: incomplete/foreign cached scores')
    mt=data[['sample_id','attack_split','membership','label_id','text']].merge(t,on='sample_id',validate='one_to_one',suffixes=('','_target'))
    mt=mt.merge(b,on='sample_id',validate='one_to_one',suffixes=('','_base'))
    mt=mt.merge(icp[['sample_id','icp_score']],on='sample_id',validate='one_to_one')
    if not (mt.ids_sha256==mt.ids_sha256_base).all():raise RuntimeError('Reference/target sequence tokenization differs')
    if not (mt.n_tokens==mt.n_tokens_base).all():raise RuntimeError('Scoring length mismatch')
    outrows=[]
    for row in mt.itertuples(index=False):
        tgt=np.asarray(json.loads(row.logp_json),float)
        ref=np.asarray(json.loads(row.logp_json_base),float)
        err=np.asarray(json.loads(row.error_json),bool)
        if len(tgt)!=int(row.n_tokens) or len(ref)!=len(tgt) or len(err)!=len(tgt):
            raise RuntimeError('Malformed per-token cache '+row.sample_id)
        cmask=np.zeros(len(tgt),bool);cmask[-int(row.n_completion_tokens):]=True
        ezfull=ez_score(tgt,ref,err,np.ones(len(tgt),bool))
        ezcomp=ez_score(tgt,ref,err,cmask)
        outrows.append({'sample_id':row.sample_id,'attack_split':row.attack_split,'membership':int(row.membership),
                        'ez_mia_full':ezfull,'ez_mia_completion':ezcomp,
                        'min_k_pp_full':float(row.min_k_pp_full),
                        'min_k_pp_completion':float(row.min_k_pp_completion),
                        'icp_mia_reference':float(row.icp_score),
                        'n_error_full':int(row.n_error_full),
                        'n_error_completion':int(row.n_error_completion),
                        'n_tokens':int(row.n_tokens)})
    score_df=pd.DataFrame(outrows)
    score_df.to_csv(root/'per_example_attack_scores.csv',index=False)
    summaries=[]
    for score_name in ['ez_mia_full','min_k_pp_full','icp_mia_reference',
                       'ez_mia_completion','min_k_pp_completion']:
        result=metrics_for_score(score_df,score_df[score_name],a.bootstrap,a.seed)
        summaries.append({'attack':score_name,**result})
    pd.DataFrame(summaries).to_csv(root/'attack_results.csv',index=False)
    (root/'attack_results.json').write_text(json.dumps(summaries,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    lines=['\\begin{tabular}{lrrrr}',r'\hline',
           r'Attack & ROC-AUC & TPR at 1\% FPR (\%) & Observed FPR (\%) & Coverage (\%) \\',r'\hline']
    for res in summaries:
        attack_label=res['attack'].replace('_', r'\_')
        if res.get('roc_auc') is None:
            row=f"{attack_label} & -- & -- & -- & {100*res['coverage']:.1f} "
        else:
            row=f"{attack_label} & {res['roc_auc']:.4f} & {100*res['tpr_at_1pct_fpr']:.2f} & {100*res['observed_fpr']:.2f} & {100*res['coverage']:.1f} "
        lines.append(row + r'\\')
    lines.extend([r'\hline',r'\end{tabular}'])
    (root/'attack_results_table.tex').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(pd.DataFrame(summaries)[['attack','roc_auc','tpr_at_1pct_fpr','observed_fpr','coverage']].to_string(index=False))
    print('Real attack results:',(root/'attack_results.csv').resolve())


def parser():
    p=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    p.add_argument('--stage',required=True,choices=['audit','score-target','score-base','score-icp','report'])
    p.add_argument('--data',default='agnews_demia_qwen15')
    # p.add_argument('--adapter',default='agnews_lora_qwen15_5ep/adapter')
    # p.add_argument('--train-summary',default='agnews_lora_qwen15_5ep/run_summary.json')
    # p.add_argument('--out',default='agnews_lora_qwen15_5ep/three_mia')
    p.add_argument('--adapter',default='agnews_fibna_qwen15_nu_0p001_5ep/adapter')
    p.add_argument('--train-summary',default='agnews_fibna_qwen15_nu_0p001_5ep/run_summary.json')
    p.add_argument('--out',default='agnews_fibna_qwen15_nu_0p001_5ep/three_mia')
    p.add_argument('--base',default='Qwen/Qwen2.5-1.5B')
    p.add_argument('--max-length',type=int,default=256)
    p.add_argument('--dtype',choices=['bf16','fp16','fp32'],default='bf16')
    p.add_argument('--vocab-chunk',type=int,default=32)
    p.add_argument('--min-k-ratio',type=float,default=.2)
    p.add_argument('--icp-encoder',default='sentence-transformers/all-MiniLM-L6-v2')
    p.add_argument('--icp-candidates',type=int,default=5)
    p.add_argument('--icp-max-length',type=int,default=768)
    p.add_argument('--limit',type=int,default=0,help='Scoring smoke test, not reportable')
    p.add_argument('--flush-every',type=int,default=50)
    p.add_argument('--bootstrap',type=int,default=1000)
    p.add_argument('--seed',type=int,default=42)
    return p


def main():
    a=parser().parse_args()
    if not (0<a.min_k_ratio<=1):raise RuntimeError('invalid Min-K%++ ratio')
    if a.vocab_chunk<1 or a.icp_candidates<1:raise RuntimeError('invalid token/probe settings')
    meta,data=manifest_and_samples(Path(a.data))
    summary=check_target_summary(Path(a.train_summary),a,Path(a.data),meta)
    print(f"PASS: 5-epoch {summary.get('method')} target; 3000 calibration/test candidates; 2000 reserved attack-training examples unused",flush=True)
    if a.stage=='audit':
        print('stage=audit: no model loading, no privacy result')
        print('Attack split:', data.groupby(['attack_split','membership']).size().to_dict())
        return
    if a.base!=meta['base_model']:raise RuntimeError('Base Qwen model mismatch')
    if a.stage in ('score-target','score-icp') and not Path(a.adapter).is_dir():raise FileNotFoundError(a.adapter)
    Path(a.out).mkdir(parents=True,exist_ok=True)
    if a.stage=='score-target':score_model(a,data,'target')
    elif a.stage=='score-base':score_model(a,data,'base')
    elif a.stage=='score-icp':score_icp(a,data)
    elif a.stage=='report':report(a,data)


if __name__=='__main__':main()
