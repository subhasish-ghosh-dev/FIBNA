#!/usr/bin/env python3
"""Offline mathematical smoke tests only — never treat as attack measurements."""
import numpy as np
import pandas as pd
import torch
from run_three_mia_agnews import token_statistics,ez_score,threshold_at_fpr,metrics_for_score

def main():
    torch.manual_seed(11)
    logits=torch.randn(7,13,dtype=torch.float32)
    chosen=torch.tensor([1,2,4,3,2,0,8])
    mask=np.array([False,False,False,False,True,True,True])
    got=token_statistics(logits,chosen,mask,True,chunk_size=3,ratio=.2)
    p=torch.softmax(logits,dim=-1)
    lp=p.log()
    mu=(p*lp).sum(-1)
    var=(p*(lp-mu[:,None]).square()).sum(-1)
    z=(lp[torch.arange(7),chosen]-mu)/var.sqrt()
    assert np.allclose(got['logp'],lp[torch.arange(7),chosen].numpy(),atol=1e-6)
    assert np.allclose(got['min_k_pp_full'],z.min().item(),atol=1e-6)
    assert np.allclose(got['min_k_pp_completion'],z[4:7].min().item(),atol=1e-6)
    fake_target=np.array([-2.0,-3.0,-1.0]);fake_base=np.array([-3.0,-2.0,-4.0]);err=[1,1,1]
    assert np.isclose(ez_score(fake_target,fake_base,err,[1,1,1]),4.0)
    assert np.isnan(ez_score(fake_target,fake_base,[0,0,0],[1,1,1]))
    thresh,fpr=threshold_at_fpr(np.arange(500,dtype=float),.01)
    assert np.isclose(fpr,.01) and np.isclose(thresh,495)
    rng=np.random.default_rng(9)
    data=[]
    for split,n in [('attack_train',100),('attack_calibration',100),('attack_test',100)]:
        for y in [0,1]:
            for _ in range(n):
                data.append({'attack_split':split,'membership':y,
                             'score':float(rng.normal(0.4*y,1))})
    frame=pd.DataFrame(data)
    results=metrics_for_score(frame,frame.score,bootstrap=20)
    assert results['n_cal_nonmembers']==100 and results['n_test_members']==100
    assert 0<=results['roc_auc']<=1 and results['coverage']==1
    print('PASS: Min-K%++ categorical normalization, EZ ratio, FPR calibration, bootstrap; SYNTHETIC ONLY')
if __name__=='__main__':main()
