#!/usr/bin/env python3
"""Qwen2.5-1.5B DP-LoRA for AG News; Poisson sampled, true per-example clipping.

Uses direct per-example gradients for transformer compatibility and Opacus PRV/RDP
accounting (NOT Opacus GradSampleModule hooks). Produces training-only wall time
and PyTorch allocated/reserved memory with the same schema as the LoRA baseline.

This is record-level DP-SGD under the specified add/remove adjacency, assuming
an ideal Gaussian mechanism; default PyTorch RNG is not cryptographically secure.
"""
from __future__ import annotations
import argparse
import contextlib
import json
import math
import platform
import random
import secrets
import sys
import time
from pathlib import Path
import numpy as np
import pandas as pd
from agnews_qwen_common import AGNewsCodec, LABELS, sha_file


def audit_data(root, limit=0):
    root = Path(root)
    manifest = json.loads((root / 'split_manifest.json').read_text(encoding='utf-8'))
    for name in ('target_train.csv', 'utility_val.csv', 'utility_test.csv',
                 'attack_train.csv', 'attack_calibration.csv', 'attack_test.csv', 'attack_all.csv'):
        src = root / name
        if not src.exists() or sha_file(src) != manifest['file_sha256'].get(name):
            raise RuntimeError(f'Dataset missing or changed since Step 2: {src}')
    tr = pd.read_csv(root / 'target_train.csv', keep_default_na=False)
    va = pd.read_csv(root / 'utility_val.csv', keep_default_na=False)
    required = {'sample_id', 'text', 'text_hash', 'label_id', 'label_name', 'prompt', 'completion'}
    for name, frame in [('target_train.csv', tr), ('utility_val.csv', va)]:
        if not required.issubset(frame):
            raise ValueError(f'{name} missing columns {required - set(frame)}')
        if frame.sample_id.duplicated().any() or frame.text_hash.duplicated().any():
            raise RuntimeError(f'Duplicate members in {name}')
        labels = frame.label_id.astype(int)
        if not set(labels).issubset(set(LABELS)) or not (frame.completion.astype(str) == labels.map(LABELS).map(lambda x: ' ' + x)).all():
            raise RuntimeError(f'Inconsistent labels and completions in {name}')
    if not set(tr.text_hash).isdisjoint(set(va.text_hash)):
        raise RuntimeError('Train/validation text overlap')
    if len(tr) != manifest['training_members'] or len(va) != manifest['utility_validation']:
        raise RuntimeError('Dataset size differs from manifest')
    if manifest.get('base_model') != 'Qwen/Qwen2.5-1.5B':
        raise RuntimeError('Incorrect model in Step 2 manifest')
    if limit:
        if not 0 < limit <= len(tr):
            raise ValueError('Invalid smoke-test cap')
        tr = tr.iloc[:limit].copy()
    return manifest, tr, va


def choose_dtype(torch, mode):
    if mode == 'auto':
        mode = 'bf16' if torch.cuda.is_bf16_supported() else 'fp16'
    return mode, {'bf16': torch.bfloat16, 'fp16': torch.float16, 'fp32': torch.float32}[mode]


def amp_context(torch, mode):
    if mode == 'fp32':
        return contextlib.nullcontext()
    return torch.autocast('cuda', dtype={'bf16': torch.bfloat16, 'fp16': torch.float16}[mode])


def predict_class(model, codec, text, torch, mode, device):
    choices = codec.choices(text)
    maximum = max(len(item[1]) for item in choices)
    ids = torch.tensor([seq + [codec.tok.pad_token_id] * (maximum - len(seq))
                        for _, seq, _, _ in choices], device=device, dtype=torch.long)
    mask = torch.tensor([[1] * len(seq) + [0] * (maximum - len(seq))
                         for _, seq, _, _ in choices], device=device, dtype=torch.long)
    with torch.inference_mode(), amp_context(torch, mode):
        logits = model(input_ids=ids, attention_mask=mask, use_cache=False).logits
    scores = {}
    for row, (category, _, prompt_len, n_label) in enumerate(choices):
        positions = torch.arange(prompt_len-1, prompt_len+n_label-1, device=device)
        targets = ids[row, prompt_len:prompt_len+n_label]
        lp = torch.log_softmax(logits[row, positions].float(), dim=-1)
        scores[category] = float(lp.gather(-1, targets[:, None]).mean().item())
    return max(scores, key=scores.get)


def validation(model, codec, df, torch, mode, device, limit=0):
    from sklearn.metrics import accuracy_score, f1_score
    frame = df.iloc[:limit] if limit else df
    model.eval()
    t0 = time.perf_counter()
    pred = []
    for i, text in enumerate(frame.text, 1):
        pred.append(int(predict_class(model, codec, text, torch, mode, device)))
        if i % 100 == 0:
            print(f'Validation {i}/{len(frame)}', flush=True)
    torch.cuda.synchronize(device)
    return {'n': len(frame),
            'accuracy': float(accuracy_score(frame.label_id.astype(int), pred)),
            'macro_f1': float(f1_score(frame.label_id.astype(int), pred, labels=list(LABELS), average='macro', zero_division=0)),
            'wall_seconds': round(time.perf_counter()-t0, 4),
            'prediction': pred}


def dp_step(model, params, examples, codec, optim, gaussian_gen, torch, mode, device,
            clip, sigma, expected_batch_size, scaler_value=1.0):
    """One logical Poisson-batch DP-SGD update. Clipping is across ALL LoRA params.

    Per-example loss is mean supervised-token CE for that record. Clip each
    resulting gradient at C, sum, add N(0,(sigma*C)^2 I) and divide by B_expected.
    This is the fixed-denominator formulation for Poisson sampling.
    """
    summed = [torch.zeros_like(p, dtype=torch.float32, device=device) for p in params]
    loss_total = 0.0
    clipped = 0
    for item in examples:
        optim.zero_grad(set_to_none=True)
        batch = codec.collate([item])
        batch = {k: v.to(device, non_blocking=True) for k, v in batch.items()}
        with amp_context(torch, mode):
            loss = model(**batch).loss
        if not bool(torch.isfinite(loss).item()):
            raise FloatingPointError('Nonfinite per-example loss')
        (loss * scaler_value).backward()
        norm_sq = torch.zeros((), dtype=torch.float32, device=device)
        grads = []
        for p in params:
            # PEFT LoRA should produce a gradient for every trainable LoRA parameter.
            g = p.grad
            if g is None:
                raise RuntimeError('Trainable adapter parameter has no gradient: refuse incomplete DP clipping')
            gg = g.detach().float() / scaler_value
            if not bool(torch.isfinite(gg).all().item()):
                raise FloatingPointError('Nonfinite per-example LoRA gradient')
            grads.append(gg)
            norm_sq.add_((gg * gg).sum())
        grad_norm = norm_sq.sqrt()
        factor = torch.clamp(float(clip)/(grad_norm + 1e-12), max=1.0)
        clipped += int((grad_norm > clip).item())
        for acc, g in zip(summed, grads):
            acc.add_(g * factor)
        loss_total += float(loss.detach().float().item())
    optim.zero_grad(set_to_none=True)
    noise_std = sigma * clip
    for p, acc in zip(params, summed):
        noise = torch.randn(acc.shape, dtype=torch.float32, device=device, generator=gaussian_gen)
        p.grad = ((acc + noise * noise_std) / expected_batch_size).to(p.dtype)
    optim.step()
    optim.zero_grad(set_to_none=True)
    return loss_total, clipped


def get_options():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--stage', choices=['audit','train'], default='audit')
    p.add_argument('--data', default='agnews_demia_qwen15')
    p.add_argument('--out', default='agnews_dp_lora_qwen15_5ep')
    p.add_argument('--base', default='Qwen/Qwen2.5-1.5B')
    p.add_argument('--seed', type=int, default=42)
    p.add_argument('--epochs', type=int, default=5)
    p.add_argument('--max-length', type=int, default=256)
    p.add_argument('--logical-batch-size', type=int, default=16)
    p.add_argument('--lr', type=float, default=1e-4)
    p.add_argument('--weight-decay', type=float, default=0.01)
    p.add_argument('--warmup-ratio', type=float, default=0.03)
    p.add_argument('--rank', type=int, default=8)
    p.add_argument('--alpha', type=int, default=16)
    p.add_argument('--dropout', type=float, default=.05)
    p.add_argument('--clip', type=float, default=1.0)
    p.add_argument('--epsilon', type=float, default=10.0)
    p.add_argument('--delta', type=float, default=1e-5)
    p.add_argument('--accountant', choices=['prv','rdp'], default='prv')
    p.add_argument('--noise-multiplier', type=float, default=0.0,
                   help='>0 explicitly sets sigma; else calibrate to epsilon over all 5 epochs')
    p.add_argument('--dtype', choices=['auto','bf16','fp16','fp32'], default='auto')
    p.add_argument('--no-gradient-checkpointing', action='store_true')
    p.add_argument('--eval-last-only', action='store_true')
    p.add_argument('--eval-max', type=int, default=0)
    p.add_argument('--max-train-records', type=int, default=0)
    p.add_argument('--log-every', type=int, default=25, help='logical optimizer updates')
    return p.parse_args()


def main():
    a = get_options()
    root = Path(a.data)
    meta, tr, va = audit_data(root, a.max_train_records)
    if a.stage == 'audit':
        print('PASS: fixed AG News split integrity; train=', len(tr), 'validation=', len(va))
        print('Dataset SHA256:', sha_file(root/'target_train.csv'))
        return
    if a.base != meta['base_model']:
        raise RuntimeError('Base model does not match fixed dataset manifest')
    if not (0 < a.delta < 1 and a.epsilon > 0 and a.clip > 0 and a.logical_batch_size > 0 and a.epochs > 0):
        raise ValueError('Invalid DP arguments')
    if not (a.lr > 0 and a.max_length >= 64 and a.noise_multiplier >= 0):
        raise ValueError('Invalid optimizer/sequence settings')
    out = Path(a.out)
    if out.exists() and any(out.iterdir()):
        raise FileExistsError(f'Output already exists: {out}')
    out.mkdir(parents=True, exist_ok=True)
    import torch
    from torch.optim import AdamW
    from transformers import AutoModelForCausalLM, AutoTokenizer, get_linear_schedule_with_warmup
    from peft import LoraConfig, get_peft_model
    from opacus.accountants import create_accountant
    from opacus.accountants.utils import get_noise_multiplier
    if not torch.cuda.is_available():
        raise RuntimeError('CUDA required for this Qwen training')
    device = torch.device('cuda:0')
    model_init_start = time.perf_counter()
    random.seed(a.seed); np.random.seed(a.seed); torch.manual_seed(a.seed)
    torch.cuda.manual_seed_all(a.seed)
    mode, dvalue = choose_dtype(torch, a.dtype)
    tokenizer = AutoTokenizer.from_pretrained(a.base, use_fast=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = 'right'
    codec = AGNewsCodec(tokenizer, max_length=a.max_length)
    examples = [codec.example(t, label) for t, label in zip(tr.text, tr.label_id)]
    try:
        model = AutoModelForCausalLM.from_pretrained(a.base, torch_dtype=dvalue)
    except TypeError:
        model = AutoModelForCausalLM.from_pretrained(a.base, dtype=dvalue)
    model.config.use_cache = False
    adapter_cfg = LoraConfig(task_type='CAUSAL_LM', r=a.rank, lora_alpha=a.alpha,
                             lora_dropout=a.dropout, bias='none', target_modules=['q_proj','v_proj'])
    model = get_peft_model(model, adapter_cfg)
    if not a.no_gradient_checkpointing:
        model.gradient_checkpointing_enable()
        if hasattr(model, 'enable_input_require_grads'):
            model.enable_input_require_grads()
    model.to(device)
    named_trainable = [(name, p) for name, p in model.named_parameters() if p.requires_grad]
    params = [p for _, p in named_trainable]
    if not named_trainable or any(p.grad is not None for p in params):
        raise RuntimeError('No trainable adapter parameters or already populated gradients')
    unexpected = [name for name, _ in named_trainable if 'lora_' not in name]
    if unexpected:
        raise RuntimeError(f'Non-LoRA trainable parameters detected: {unexpected[:5]}')
    optim = AdamW(params, lr=a.lr, weight_decay=a.weight_decay)
    n = len(examples)
    q = min(1.0, a.logical_batch_size / n)
    if q >= 1.0 and not a.max_train_records:
        raise ValueError('Use a logical batch smaller than the training dataset')
    steps_per_epoch = math.ceil(n / a.logical_batch_size)
    n_steps = a.epochs * steps_per_epoch
    if a.noise_multiplier:
        sigma = float(a.noise_multiplier)
        sigma_source = 'explicit'
    else:
        sigma = float(get_noise_multiplier(target_epsilon=a.epsilon, target_delta=a.delta,
                                           sample_rate=q, steps=n_steps, accountant=a.accountant))
        sigma_source = 'calibrated_to_total_steps'
    if sigma <= 0 or not math.isfinite(sigma):
        raise RuntimeError('Invalid Gaussian noise multiplier')
    accountant = create_accountant(mechanism=a.accountant)
    warmup_steps = int(round(n_steps * a.warmup_ratio))
    scheduler = get_linear_schedule_with_warmup(optim, num_warmup_steps=warmup_steps,
                                                num_training_steps=n_steps)
    # RNG for DP randomness is independent of published model initialization seed.
    # PyTorch CUDA RNG is OS seeded, but NOT a secure CSPRNG.
    poisson_rng = np.random.default_rng(secrets.randbits(128))
    gaussian_rng = torch.Generator(device=device)
    gaussian_rng.manual_seed(secrets.randbits(63))
    loss_scale = 1024.0 if mode == 'fp16' else 1.0
    if mode == 'fp16':
        print('WARNING: FP16 manual loss scaling used. Reject any nonfinite per-example gradients.')
    print('Model:', a.base, '| GPU:', torch.cuda.get_device_name(device), '| dtype:', mode, flush=True)
    print('Trainable params:', sum(p.numel() for p in params), flush=True)
    print('Poisson rate:', q, '| expected logical batch:', a.logical_batch_size, '| steps:', n_steps,
          '| epochs:', a.epochs, '| clip C:', a.clip, '| noise sigma:', sigma, flush=True)
    print('Method: manual per-example clipping, independent Gaussian noise, Opacus', a.accountant,
          'privacy accounting; not Opacus hooks.', flush=True)
    torch.cuda.synchronize(device)
    setup_seconds = time.perf_counter() - model_init_start
    peak_allocated = peak_reserved = 0.0
    training_time = validation_time = 0.0
    updates = 0
    epoch_rows = []
    final_validation = None
    for epoch in range(a.epochs):
        model.train()
        torch.cuda.synchronize(device)
        torch.cuda.reset_peak_memory_stats(device)
        t0 = time.perf_counter()
        observed = clipped = 0
        epoch_loss_sum = 0.0
        for step in range(steps_per_epoch):
            # Binomial draw + uniform subset is equivalent to independent Bernoulli inclusion.
            k = int(poisson_rng.binomial(n, q))
            idx = poisson_rng.choice(n, size=k, replace=False) if k else []
            selected = [examples[int(i)] for i in idx]
            losses, n_clipped = dp_step(model, params, selected, codec, optim,
                                         gaussian_rng, torch, mode, device, a.clip,
                                         sigma, a.logical_batch_size, loss_scale)
            scheduler.step()
            accountant.step(noise_multiplier=sigma, sample_rate=q)
            epoch_loss_sum += losses
            observed += k
            clipped += n_clipped
            updates += 1
            if a.log_every and updates % a.log_every == 0:
                print(f'Epoch {epoch+1}/{a.epochs} update {step+1}/{steps_per_epoch} '
                      f'(total {updates}/{n_steps}); sampled records so far={observed}', flush=True)
        torch.cuda.synchronize(device)
        wall = time.perf_counter()-t0
        train_alloc = torch.cuda.max_memory_allocated(device)/2**30
        train_res = torch.cuda.max_memory_reserved(device)/2**30
        peak_allocated = max(peak_allocated, train_alloc)
        peak_reserved = max(peak_reserved, train_res)
        training_time += wall
        spent = float(accountant.get_epsilon(delta=a.delta))
        print(f'Epoch {epoch+1}: train={wall:.2f}s, sampled={observed}, '
              f'epsilon={spent:.4f}, allocated peak={train_alloc:.3f} GiB', flush=True)
        eval_seconds = 0.0
        eval_result = None
        if not a.eval_last_only or epoch+1 == a.epochs:
            torch.cuda.synchronize(device)
            tval = time.perf_counter()
            eval_result = validation(model, codec, va, torch, mode, device, limit=a.eval_max)
            torch.cuda.synchronize(device)
            eval_seconds = time.perf_counter() - tval
            validation_time += eval_seconds
            final_validation = {k:v for k,v in eval_result.items() if k!='prediction'}
            pd.DataFrame({'sample_id': (va.iloc[:a.eval_max] if a.eval_max else va).sample_id,
                          'true_label': (va.iloc[:a.eval_max] if a.eval_max else va).label_id,
                          'pred_label': eval_result['prediction']}).to_csv(out/f'validation_predictions_epoch_{epoch+1}.csv',index=False)
            print('Validation accuracy:', eval_result['accuracy'], 'macro-F1:', eval_result['macro_f1'],flush=True)
        epoch_rows.append({'epoch':epoch+1, 'examples_seen':observed,
                           'microbatches':observed, 'optimizer_steps':steps_per_epoch,
                           'training_wall_seconds':round(wall,4),
                           'validation_wall_seconds':round(eval_seconds,4),
                           'peak_gpu_training_allocated_gib':round(train_alloc,4),
                           'peak_gpu_training_reserved_gib':round(train_res,4),
                           'sampled_records':observed,
                           'clipped_records':clipped,
                           'mean_per_example_masked_nll_for_internal_debugging':round(epoch_loss_sum/observed,6) if observed else None,
                           'epsilon_spent':round(spent,6)})
        pd.DataFrame(epoch_rows).to_csv(out/'epoch_overhead.csv',index=False)
        (out/'privacy_progress.json').write_text(json.dumps({
            'mechanism':'Poisson-sampled record-level DP-SGD',
            'accountant':a.accountant, 'delta':a.delta,'epsilon_spent':spent,
            'sigma':sigma,'clip':a.clip,'sample_rate':q,'steps':updates,'sampled_records_epoch':observed
        },indent=2),encoding='utf-8')
    torch.cuda.synchronize(device)
    t_save = time.perf_counter()
    model.eval()
    model.save_pretrained(out/'adapter',safe_serialization=True)
    tokenizer.save_pretrained(out/'adapter')
    torch.cuda.synchronize(device)
    save_seconds = time.perf_counter()-t_save
    achieved_epsilon = float(accountant.get_epsilon(delta=a.delta))
    if not a.max_train_records and a.noise_multiplier == 0 and achieved_epsilon > a.epsilon + 1e-3:
        raise RuntimeError(f'Privacy overspend: achieved={achieved_epsilon}, target={a.epsilon}; review accountant')
    overhead = {
        'method':'DP-LoRA', 'is_pilot':bool(a.max_train_records or a.eval_max),
        'measurement_protocol':'CUDA-synchronized time.perf_counter per training epoch; reset PyTorch memory peaks',
        'gpu':torch.cuda.get_device_name(device),
        'gpu_total_gib':round(torch.cuda.get_device_properties(device).total_memory/2**30,3),
        'cuda_version':torch.version.cuda,
        'data_sha256':sha_file(root/'target_train.csv'), 'model':a.base,
        'seed':a.seed, 'dtype':mode, 'gradient_checkpointing':not a.no_gradient_checkpointing,
        'train_count':n, 'epochs':a.epochs, 'max_length':a.max_length,
        'microbatch_size':1,'gradient_accumulation':'Poisson logical batch',
        'effective_batch_size':a.logical_batch_size,
        'optimizer_steps':updates,
        'training_wall_seconds':round(training_time,4),
        'training_wall_hours':round(training_time/3600,5),
        'validation_wall_seconds':round(validation_time,4),
        'checkpoint_save_wall_seconds':round(save_seconds,4),
        'setup_wall_seconds':round(setup_seconds,4),
        'seconds_per_optimizer_step':round(training_time/updates,4),
        'wall_seconds_per_1000_training_examples':round(training_time*1000/(n*a.epochs),4),
        'peak_gpu_training_allocated_gib':round(peak_allocated,4),
        'peak_gpu_training_reserved_gib':round(peak_reserved,4),
        'gpu_memory_note':'PyTorch peak allocated/reserved memory, not nvidia-smi device utilization',
        'validation_schedule':'final_epoch_only' if a.eval_last_only else 'each_epoch',
        'epoch_overhead':epoch_rows, 'training_finished':True,
    }
    (out/'overhead_summary.json').write_text(json.dumps(overhead,indent=2),encoding='utf-8')
    summary = {
        'protocol':'AG News class-completion only masked next-token CE',
        'method':'DP-LoRA','is_pilot':overhead['is_pilot'],
        'model':a.base, 'seed':a.seed, 'train_count':n, 'epochs':a.epochs,
        'data_sha256':overhead['data_sha256'],
        'split_manifest_sha256':sha_file(root/'split_manifest.json'),
        'lora':{'rank':a.rank,'alpha':a.alpha,'dropout':a.dropout,'target_modules':['q_proj','v_proj']},
        'optimizer':{'name':'AdamW','lr':a.lr,'weight_decay':a.weight_decay,'warmup_steps':warmup_steps,
                     'logical_batch_size_expected':a.logical_batch_size,'physical_batch_size':1},
        'privacy':{'unit':'record-level','adjacency':'add/remove one distinct target training example',
                   'sampling':'Poisson/Bernoulli independent across steps',
                   'sample_rate':q, 'total_steps':updates, 'expected_samples_per_step':a.logical_batch_size,
                   'max_grad_norm':a.clip,'noise_multiplier':sigma,'noise_source':sigma_source,
                   'noise_std_pre_average':sigma*a.clip,'target_epsilon':a.epsilon,
                   'achieved_epsilon':achieved_epsilon,'delta':a.delta,'accountant':a.accountant,
                   'dp_randomness':'OS-seeded PyTorch CUDA generator; not cryptographically secure',
                   'nonprivate_artifacts':'training loss / timings / memory / validation logs not covered by checkpoint DP bound'},
        'validation':final_validation, 'training_wall_seconds':overhead['training_wall_seconds'],
        'peak_gpu_allocated_gib':overhead['peak_gpu_training_allocated_gib'],
        'overhead_summary_file':'overhead_summary.json',
        'software':{'python':sys.version.split()[0], 'torch':torch.__version__,
                    'transformers':__import__('transformers').__version__,
                    'peft':__import__('peft').__version__,
                    'opacus':__import__('opacus').__version__},
        'finished':True,
    }
    (out/'run_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print('PASS: DP-LoRA checkpoint:', (out/'adapter').resolve(), flush=True)
    print(f'PRIVACY: epsilon={achieved_epsilon:.5f} delta={a.delta:g} '
          f'sigma={sigma:.6f} C={a.clip:g} steps={updates} q={q:.8f}', flush=True)
    print(f'OVERHEAD: training={training_time/3600:.4f}h, '
          f'peak allocated={peak_allocated:.3f}GiB, reserved={peak_reserved:.3f}GiB', flush=True)

if __name__ == '__main__':
    main()
