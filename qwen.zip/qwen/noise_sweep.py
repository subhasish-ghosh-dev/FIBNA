#!/usr/bin/env python3
"""Reproducible FIBNA noise-strength sweep; RETRAINS one model per noise level.

Uses the original AG News and XSum Qwen2.5-1.5B scripts shipped alongside this
orchestrator. Never fabricates MIA results. Full output-head delta is always loaded.
Run `python noise_sweep.py --stage plan` first.
"""
from __future__ import annotations
import argparse, ast, csv, hashlib, json, math, shutil, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TASKS = ('agnews', 'xsum')
ATTACKS = {'ez_mia_full': 'EZ-MIA',
           'icp_mia_reference': 'ICP-MIA',
           'min_k_pp_full': 'Min-K%++'}
EPS_CODE, DELTA_CODE = 10.0, 1e-5
FACTOR = math.sqrt(2 * math.log(1.25 / DELTA_CODE)) / EPS_CODE
DEFAULT_NOISE = '2.5e-5,5e-5,1e-4,2e-4,4e-4'


def sha_file(p: Path) -> str:
    h = hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


def parse_levels(raw: str) -> list[float]:
    levels = [float(x.strip()) for x in raw.split(',') if x.strip()]
    if not levels or any(not math.isfinite(v) or v <= 0 for v in levels):
        raise ValueError('All FIBNA nu levels must be positive finite numbers')
    if len(levels) != len(set(levels)):
        raise ValueError('Duplicate noise levels')
    return sorted(levels)


def key(nu: float) -> str:
    return ('nu_' + format(nu, '.3e').replace('.', 'p').replace('+', 'p').replace('-', 'm'))


def find_path(root: Path, path: str) -> Path:
    p = Path(path)
    return p.resolve() if p.is_absolute() else (root / p).resolve()


def dataset_path(a, task: str):
    return find_path(a.project_root, a.agnews_data if task == 'agnews' else a.xsum_data)


def checkpoint(a, task: str, nu: float) -> Path:
    if a.reuse_baseline and math.isclose(nu, 1e-4, rel_tol=1e-12):
        existing = find_path(a.project_root, a.baseline_agnews if task == 'agnews' else a.baseline_xsum)
        if (existing / 'run_summary.json').is_file():
            return existing
    return a.out_root / task / key(nu)


def assert_run_matches(a, task: str, nu: float, run: Path):
    """Fail closed: do not reuse a checkpoint with different noise/config/data."""
    f = run / 'run_summary.json'
    if not f.is_file():
        raise RuntimeError(f'Checkpoint not complete: {f}')
    obj = json.loads(f.read_text(encoding='utf-8'))
    data = dataset_path(a, task)
    checks = {'model': 'Qwen/Qwen2.5-1.5B', 'epochs': 5, 'seed': 42,
              'train_count': 10000,
              'target_train_csv_sha256': sha_file(data / 'target_train.csv'),
              'split_manifest_sha256': sha_file(data / 'split_manifest.json')}
    for field, val in checks.items():
        if obj.get(field) != val:
            raise RuntimeError(f'{task} {run}: {field} mismatch ({obj.get(field)!r} != {val!r})')
    if obj.get('is_pilot'):
        raise RuntimeError('A pilot checkpoint cannot be used for manuscript MIA: ' + str(run))
    if obj.get('dtype') != 'bf16':
        raise RuntimeError('Not the BF16 training configuration: ' + str(run))
    if int(obj.get('optimizer_steps_total', -1)) != 3125:
        raise RuntimeError('Expected 3125 optimizer updates for the complete five-epoch run: '+str(run))
    lora = obj.get('lora', {})
    if (lora.get('rank') != 8 or lora.get('alpha') != 16 or
        not math.isclose(float(lora.get('dropout', -1)), 0.05, abs_tol=1e-12) or
        lora.get('target_modules') != ['q_proj','v_proj']):
        raise RuntimeError('LoRA architecture mismatch: '+str(run))
    optim = obj.get('optimizer', {})
    if (not math.isclose(float(optim.get('lr', -1)), 1e-4, rel_tol=1e-12) or
        optim.get('microbatch') != 2 or optim.get('grad_accum') != 8):
        raise RuntimeError('Optimizer microbatch/accumulation/lr mismatch: '+str(run))
    if task == 'agnews':
        actual_nu = float(obj['noise']['multiplier_nu'])
        actual_kappa = float(obj['noise']['kappa'])
        shap = obj['shap']
        if (obj.get('max_length') != 256 or shap.get('features') != 8 or
            shap.get('nsamples') != 100 or shap.get('refresh_every_optimizer_steps') != 125 or
            obj['noise'].get('injection_every_optimizer_steps') != 1):
            raise RuntimeError('AG News SHAP/noise protocol mismatch for ' + str(run))
    else:
        actual_nu = float(obj['requested_configuration']['fibna_noise_nu'])
        actual_kappa = float(obj['fibna']['kappa'])
        shap = obj['fibna']
        if (obj.get('method') != 'fibna' or obj.get('max_length') != 512 or
            obj.get('max_target_tokens') != 64 or shap.get('shap_features') != 8 or
            shap.get('shap_samples') != 100 or shap.get('shap_refresh_steps') != 125 or
            shap.get('noise_every_steps') != 1):
            raise RuntimeError('XSum SHAP/noise protocol mismatch for ' + str(run))
    if not math.isclose(actual_nu, nu, rel_tol=1e-9):
        raise RuntimeError(f'{run}: requested nu {nu} != checkpoint nu {actual_nu}')
    if not math.isclose(actual_kappa, nu * FACTOR, rel_tol=1e-9):
        raise RuntimeError(f'{run}: effective kappa does not match the fixed scaling formula')
    for filename in ('adapter/adapter_config.json', 'lm_head_delta.safetensors', 'fibna_checkpoint.json'):
        if not (run / filename).is_file():
            raise FileNotFoundError(run / filename)
    if not any((run / 'adapter').glob('*.safetensors')):
        raise FileNotFoundError(f'Missing adapter weight file in {run / "adapter"}')
    return obj


def execute(a, args):
    print('\n>>>', ' '.join(map(str, args)), flush=True)
    if not a.dry_run:
        subprocess.run(args, cwd=str(a.project_root), check=True)


def train(a, task, nu):
    run = checkpoint(a, task, nu)
    if (run / 'run_summary.json').is_file():
        assert_run_matches(a, task, nu, run)
        print('SKIP: verified existing complete checkpoint:', run)
        return
    if run.exists() and any(run.iterdir()):
        raise RuntimeError('An incomplete/foreign training folder already exists. '
                           'Do not overwrite it automatically; inspect or move it: ' + str(run))
    data = dataset_path(a, task)
    if task == 'agnews':
        cmd = [sys.executable, str(ROOT / 'agnews' / 'train_agnews_qwen_fibna.py'),
               '--stage', 'train', '--data', str(data), '--out', str(run),
               '--seed', '42', '--epochs', '5', '--max-length', '256',
               '--batch-size', '2', '--grad-accum', '8', '--dtype', 'bf16',
               '--rank', '8', '--alpha', '16', '--dropout', '0.05', '--lr', '1e-4',
               '--shap-features', '8', '--shap-samples', '100',
               '--shap-every-steps', '125', '--noise-every-steps', '1',
               '--noise-multiplier', repr(nu), '--epsilon-code', '10', '--delta-code', '1e-5',
               '--eval-last-only']
    else:
        cmd = [sys.executable, str(ROOT / 'xsum' / 'train_xsum.py'),
               '--stage', 'train', '--method', 'fibna', '--data', str(data),
               '--out', str(run), '--seed', '42', '--epochs', '5', '--max-length', '512',
               '--max-target-tokens', '64', '--batch-size', '2', '--grad-accum', '8',
               '--dtype', 'bf16', '--rank', '8', '--alpha', '16', '--dropout', '0.05',
               '--lr', '1e-4', '--shap-features', '8', '--shap-samples', '100',
               '--shap-every-steps', '125', '--noise-every-steps', '1',
               '--fibna-noise-nu', repr(nu), '--epsilon-code', '10', '--delta-code', '1e-5']
    execute(a, cmd)
    if not a.dry_run:
        assert_run_matches(a, task, nu, run)


def share_independent_cache(a, task, run, previous: Path | None):
    if previous is None or previous == run:
        return
    target = run / 'three_mia'
    prior = previous / 'three_mia'
    if not prior.is_dir():
        return
    # All variants share exactly the same immutable data and reference encoder.
    # Score-cache provenance is checked by the original runner on access.
    for name in ('base_tokens.csv', 'base_tokens.provenance.json',
                 'icp_retrieval.csv', 'icp_retrieval.provenance.json'):
        src = prior / name
        dst = target / name
        if src.is_file() and not dst.exists():
            target.mkdir(parents=True, exist_ok=True)
            if not a.dry_run:
                shutil.copy2(src, dst)
                print('Copied checkpoint-independent cache:', name, flush=True)


def attacks(a, task, nu, previous=None):
    run = checkpoint(a, task, nu)
    if not a.dry_run:
        assert_run_matches(a, task, nu, run)
        share_independent_cache(a, task, run, previous)
    out = run / 'three_mia'
    if task == 'agnews':
        script = ROOT / 'agnews' / 'run_three_mia_agnews_fibna.py'
        base = [sys.executable, str(script), '--data', str(dataset_path(a, task)),
                '--adapter', str(run / 'adapter'), '--train-summary', str(run / 'run_summary.json'),
                '--out', str(out), '--dtype', 'bf16', '--bootstrap', str(a.bootstrap),
                '--seed', '42', '--max-length', '256']
        for stage in ('audit', 'score-target', 'score-base', 'score-icp', 'report'):
            execute(a, base + ['--stage', stage])
    else:
        script = ROOT / 'xsum' / 'mia_xsum.py'
        base = [sys.executable, str(script), '--method', 'fibna',
                '--data', str(dataset_path(a, task)), '--checkpoint', str(run),
                '--out', str(out), '--dtype', 'bf16', '--bootstrap', str(a.bootstrap),
                '--seed', '42', '--max-length', '512', '--max-target-tokens', '64']
        for stage in ('audit', 'score-target', 'score-base', 'score-icp', 'report'):
            execute(a, base + ['--stage', stage])


def utility(a, task, nu):
    run = checkpoint(a, task, nu)
    if not a.dry_run:
        assert_run_matches(a, task, nu, run)
    if task == 'agnews':
        out = run / 'test_evaluation'
        if (out / 'test_metrics.json').is_file():
            print('SKIP utility already exists:', out)
            return
        args = [sys.executable, str(ROOT / 'agnews' / 'evaluate_agnews_qwen_fibna_test.py'),
                '--stage', 'evaluate', '--data', str(dataset_path(a, task)),
                '--checkpoint', str(run), '--out', str(out), '--dtype', 'bf16',
                '--bootstrap', str(a.bootstrap)]
    else:
        out = run / 'utility_test'
        if (out / 'test_metrics.json').is_file():
            print('SKIP utility already exists:', out)
            return
        args = [sys.executable, str(ROOT / 'xsum' / 'eval_xsum.py'),
                '--method', 'fibna', '--data', str(dataset_path(a, task)),
                '--checkpoint', str(run), '--out', str(out), '--split', 'test',
                '--dtype', 'bf16', '--max-new-tokens', '64', '--num-beams', '4',
                '--bootstrap', str(a.bootstrap)]
    execute(a, args)


def read_csv(p):
    with p.open(newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))


def maybe_float(value):
    try:
        return float(value)
    except (ValueError, TypeError):
        return None


def gather(a):
    rows = []
    missing = []
    for task in a.tasks:
        for nu in a.noise_values:
            run = checkpoint(a, task, nu)
            if not (run / 'run_summary.json').is_file():
                missing.append(f'{task} {nu:g}: training missing')
                continue
            summary = assert_run_matches(a, task, nu, run)
            attack = run / 'three_mia' / 'attack_results.csv'
            if not attack.is_file():
                missing.append(f'{task} {nu:g}: MIA report missing')
                continue
            all_ = read_csv(attack)
            by_attack = {str(r['attack']): r for r in all_}
            if set(ATTACKS) - set(by_attack):
                raise RuntimeError(f'Missing requested attacks in {attack}: {set(ATTACKS)-set(by_attack)}')
            util_path = run / ('test_evaluation' if task == 'agnews' else 'utility_test') / 'test_metrics.json'
            utility_info = json.loads(util_path.read_text(encoding='utf-8')) if util_path.is_file() else {}
            events_file = run / 'noise_events.csv'
            realized = {}
            if events_file.is_file():
                ev = read_csv(events_file)
                for key_ in ('noise_rms', 'sigma_rms'):
                    vals = [float(v[key_]) for v in ev if v.get(key_) not in (None, '')]
                    if vals:
                        realized['mean_' + key_] = sum(vals)/len(vals)
                realized['noise_events'] = len(ev)
            for attack_name, friendly in ATTACKS.items():
                rec = by_attack[attack_name]
                auc = maybe_float(rec.get('roc_auc'))
                tpr = maybe_float(rec.get('tpr_at_1pct_fpr'))
                fpr = maybe_float(rec.get('observed_fpr'))
                cover = maybe_float(rec.get('coverage'))
                if any(x is None or not math.isfinite(x) for x in (auc,tpr,fpr,cover)):
                    raise RuntimeError(f'MIA missing numerical metrics: {attack}, {attack_name}')
                if not (0 <= auc <= 1 and 0 <= tpr <= 1 and 0 <= fpr <= 1 and 0 <= cover <= 1):
                    raise RuntimeError(f'MIA metric out of range: {attack}')
                if cover < 0.95:
                    raise RuntimeError(f'Full-sequence MIA coverage below 95% for {run}: {attack_name}: {cover}')
                ci_fields = {}
                for csv_field, target_prefix, scale in (
                    ('roc_auc_ci95','auc_ci',1),
                    ('tpr_ci95','tpr_ci_pct',100),
                    ('observed_fpr_ci95','fpr_ci_pct',100)):
                    raw = rec.get(csv_field)
                    try:
                        bounds = ast.literal_eval(raw) if raw not in (None, '', 'nan') else []
                    except (ValueError, SyntaxError, TypeError):
                        bounds = []
                    ci_fields[target_prefix+'_low'] = float(bounds[0])*scale if len(bounds)==2 else ''
                    ci_fields[target_prefix+'_high'] = float(bounds[1])*scale if len(bounds)==2 else ''
                rows.append({'task':task, 'attack':friendly, 'attack_key':attack_name,
                             'nu':nu, 'kappa':nu*FACTOR, 'roc_auc':auc,
                             'tpr_at_1pct_fpr_pct':tpr*100, 'observed_fpr_pct':fpr*100,
                             'coverage_pct':cover*100,
                             'training_hours':float(summary['training_wall_seconds'])/3600,
                             'gpu_allocated_gib':float(summary.get('peak_gpu_allocated_gib', 'nan')),
                             'utility_accuracy_pct':float(utility_info['accuracy'])*100 if task=='agnews' and 'accuracy' in utility_info else '',
                             'utility_rougeL_pct':float(utility_info['rougeL']) if task=='xsum' and 'rougeL' in utility_info else '',
                             'mean_realized_noise_rms':realized.get('mean_noise_rms', ''),
                             'mean_realized_sigma_rms':realized.get('mean_sigma_rms', ''),
                             'noise_injection_events':realized.get('noise_events', ''),
                             **ci_fields,
                             'checkpoint_path':str(run.resolve())})
    out = a.out_root
    out.mkdir(exist_ok=True, parents=True)
    dest = out / 'measured_noise_vs_mia.csv'
    if rows:
        fields = list(rows[0])
        with dest.open('w', newline='', encoding='utf-8') as fh:
            writer = csv.DictWriter(fh, fields)
            writer.writeheader()
            writer.writerows(rows)
        print('Collected measured attack results:', dest.resolve())
    else:
        print('No complete measured MIA results available to collect.')
    if missing:
        print('Missing results (never synthesized):')
        for i in missing:
            print('  -', i)
    return dest if rows else None


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    p.add_argument('--stage', choices=('plan','train','attacks','utility','all','collect','plot'), default='plan')
    p.add_argument('--project-root', type=Path, default=Path.cwd())
    p.add_argument('--out-root', default='fibna_noise_sweep_runs')
    p.add_argument('--tasks', nargs='+', choices=TASKS, default=list(TASKS))
    p.add_argument('--noise-values', default=DEFAULT_NOISE,
                   help='Comma-separated Gaussian nu coefficients; re-train each level')
    p.add_argument('--agnews-data', default='agnews_demia_qwen15')
    p.add_argument('--xsum-data', default='xsum_qwen15_data')
    p.add_argument('--reuse-baseline', action='store_true',
                   help='Reuse independently verified 1e-4 original FIBNA checkpoints')
    p.add_argument('--baseline-agnews', default='agnews_fibna_qwen15_5ep')
    p.add_argument('--baseline-xsum', default='xsum_fibna_qwen15_5ep')
    p.add_argument('--with-utility', action='store_true', help='Also run held-out utility tests on each level')
    p.add_argument('--bootstrap', type=int, default=1000)
    p.add_argument('--dry-run', action='store_true')
    a = p.parse_args()
    a.project_root = a.project_root.resolve()
    a.out_root = find_path(a.project_root, a.out_root)
    a.noise_values = parse_levels(a.noise_values)
    if a.bootstrap < 0: p.error('--bootstrap must be >= 0')
    print(f'FIBNA sensitivity: tasks={a.tasks}, levels={a.noise_values}, epsilon_code={EPS_CODE}, delta_code={DELTA_CODE}')
    for nu in a.noise_values:
        print(f'  nu={nu:.6g}, kappa={nu*FACTOR:.9g} (NOT a DP privacy parameter)')
    if a.stage == 'plan':
        for task in a.tasks:
            print('\n', task.upper())
            print(' dataset:', dataset_path(a,task))
            for nu in a.noise_values:
                print(' ', f'nu={nu:g}', '->', checkpoint(a,task,nu))
        print('\nNo training/scoring performed during plan.')
        return
    for task in a.tasks:
        previous = None
        for nu in a.noise_values:
            if a.stage in ('train','all'):
                train(a, task, nu)
            if a.stage in ('attacks','all'):
                attacks(a, task, nu, previous)
                previous = checkpoint(a,task,nu)
            if a.stage == 'utility' or (a.stage == 'all' and a.with_utility):
                utility(a, task, nu)
    if a.stage in ('all','collect','plot') and not a.dry_run:
        merged = gather(a)
        if merged and a.stage in ('all','plot'):
            plot_file = ROOT / 'plot_noise_sensitivity.py'
            subprocess.run([sys.executable,str(plot_file),'--csv',str(merged),
                            '--out', str(a.out_root/'figures')],check=True)
    if a.dry_run:
        print('\nDRY RUN ONLY. No model was trained or scored.')

if __name__ == '__main__':
    main()
