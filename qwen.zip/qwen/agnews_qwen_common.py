#!/usr/bin/env python3
"""Immutable AG News prompt/label tokenizer shared by target training and attack scoring.

Segment-wise tokenization, reserved label suffix, and right-padding are intentional.
Use this exact formatter for all three methods and attack likelihood features.
"""
from __future__ import annotations
import hashlib
from pathlib import Path

LABELS = {0: 'World', 1: 'Sports', 2: 'Business', 3: 'Sci/Tech'}
PREFIX = (
    'Classify the following news article into exactly one of these categories: '
    'World, Sports, Business, Sci/Tech.\n\nArticle:\n'
)
SUFFIX = '\n\nCategory:'


def sha_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for part in iter(lambda: f.read(2 * 1024 * 1024), b''):
            h.update(part)
    return h.hexdigest()


class AGNewsCodec:
    def __init__(self, tok, max_length=256):
        if tok.eos_token_id is None:
            raise ValueError('Tokenizer must provide an EOS token')
        if tok.pad_token_id is None:
            raise ValueError('Set tok.pad_token to tok.eos_token before constructing codec')
        self.tok = tok
        self.max_length = max_length
        self.pre = tok.encode(PREFIX, add_special_tokens=False)
        self.tail = tok.encode(SUFFIX, add_special_tokens=False)
        self.completions = {i: tok.encode(' ' + name, add_special_tokens=False)
                            for i, name in LABELS.items()}
        if any(not t for t in self.completions.values()):
            raise RuntimeError('Empty class completion')
        reserved = len(self.pre) + len(self.tail) + max(len(x) for x in self.completions.values()) + 1
        if reserved + 8 > max_length:
            raise ValueError(f'max_length {max_length} too short; at least {reserved+8} required')
        self.article_budget = max_length - reserved

    def prompt_ids(self, text):
        article = self.tok.encode(str(text), add_special_tokens=False)
        return self.pre + article[:self.article_budget] + self.tail

    def example(self, text, label_id):
        label_id = int(label_id)
        ids = self.prompt_ids(text)
        c = self.completions[label_id]
        all_ids = ids + c + [self.tok.eos_token_id]
        labels = [-100] * len(ids) + c + [self.tok.eos_token_id]
        if len(all_ids) > self.max_length:
            raise AssertionError('Label truncated')
        return {'input_ids': all_ids, 'labels': labels}

    def choices(self, text):
        prefix = self.prompt_ids(text)
        return [(k, prefix + c, len(prefix), len(c)) for k, c in self.completions.items()]

    def collate(self, examples):
        import torch
        maxlen = max(len(x['input_ids']) for x in examples)
        all_ids = [e['input_ids'] + [self.tok.pad_token_id] * (maxlen - len(e['input_ids']))
                   for e in examples]
        mask = [[1] * len(e['input_ids']) + [0] * (maxlen - len(e['input_ids']))
                for e in examples]
        labels = [e['labels'] + [-100] * (maxlen - len(e['labels']))
                  for e in examples]
        return {'input_ids': torch.tensor(all_ids, dtype=torch.long),
                'attention_mask': torch.tensor(mask, dtype=torch.long),
                'labels': torch.tensor(labels, dtype=torch.long)}
