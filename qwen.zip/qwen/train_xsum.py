#!/usr/bin/env python
"""Five-epoch Qwen XSum training: LoRA, record-level DP-LoRA, or Qwen-adapted FIBNA."""
from __future__ import annotations
import argparse,contextlib,json,math,random,secrets,sys,time
from pathlib import Path
import numpy as np
import pandas as pd
from xsum_common import BASE,XSumCodec,FP32OutputHead,audit,autocast,dtype_choice,get_base,sha_file,tokenizer_model
from fibna_math import compute_shap_psi,add_fibna_noise


def options():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--stage',choices=('audit','train'),default='train')
    p.add_argument('--method',choices=('lora','dp-lora','fibna'),required=True)
    p.add_argument('--data',default='xsum_qwen15_data')
    p.add_argument('--out',default=None)
    p.add_argument('--base',default=BASE)
    p.add_argument('--seed',type=int,default=42)
    p.add_argument('--epochs',type=int,default=5)
    p.add_argument('--max-length',type=int,default=512)
    p.add_argument('--max-target-tokens',type=int,default=64)
    p.add_argument('--batch-size',type=int,default=2)
    p.add_argument('--grad-accum',type=int,default=8)
    p.add_argument('--logical-batch-size',type=int,default=16)
    p.add_argument('--lr',type=float,default=1e-4)
    p.add_argument('--weight-decay',type=float,default=.01)
    p.add_argument('--rank',type=int,default=8)
    p.add_argument('--alpha',type=int,default=16)
    p.add_argument('--dropout',type=float,default=.05)
    p.add_argument('--dtype',choices=('auto','bf16','fp16','fp32'),default='auto')
    p.add_argument('--target-epsilon',type=float,default=10.0)
    p.add_argument('--delta',type=float,default=1e-5)
    p.add_argument('--clip',type=float,default=1.)
    p.add_argument('--accountant',choices=('prv','rdp'),default='prv')
    p.add_argument('--noise-multiplier',type=float,default=0.)
    p.add_argument('--shap-features',type=int,default=8)
    p.add_argument('--shap-samples',type=int,default=100)
    p.add_argument('--shap-every-steps',type=int,default=125)
    p.add_argument('--shap-forward-batch',type=int,default=1)
    p.add_argument('--noise-every-steps',type=int,default=1)
    p.add_argument('--fibna-noise-nu',type=float,default=1e-4)
    p.add_argument('--epsilon-code',type=float,default=10.)
    p.add_argument('--delta-code',type=float,default=1e-5)
    p.add_argument('--max-train-records',type=int,default=0,help='Smoke experiment only')
    p.add_argument('--log-every',type=int,default=25)
    return p.parse_args()


def dp_update(model,params,records,codec,optimizer,torch,device,dtype,clip,sigma,expected,noise_rng):
    sums=[torch.zeros_like(p,dtype=torch.float32,device=device) for p in params]
    total=0.;clipped=0;loss_scale=1024. if dtype=='fp16' else 1.
    for rec in records:
        optimizer.zero_grad(set_to_none=True)
        batch={k:v.to(device) for k,v in codec.collate([rec]).items()}
        with autocast(torch,dtype):loss=model(**batch,use_cache=False).loss
        if not torch.isfinite(loss):raise FloatingPointError('Nonfinite DP loss')
        (loss*loss_scale).backward()
        grad=[];squared=torch.zeros((),device=device,dtype=torch.float32)
        for p in params:
            if p.grad is None:raise RuntimeError('Missing LoRA DP gradient')
            g=p.grad.detach().float()/loss_scale
            if not bool(torch.isfinite(g).all()):raise FloatingPointError('Nonfinite DP gradient')
            squared.add_(g.square().sum());grad.append(g)
        gn=squared.sqrt()
        factor=torch.clamp(clip/(gn+1e-12),max=1.)
        clipped+=int((gn>clip).item())
        for dst,g in zip(sums,grad):dst.add_(g*factor)
        total+=float(loss.detach().float().item())
    optimizer.zero_grad(set_to_none=True)
    for p,s in zip(params,sums):
        n=torch.randn(s.shape,generator=noise_rng,device=device,dtype=torch.float32)
        p.grad=((s+n*sigma*clip)/expected).to(p.dtype)
    optimizer.step();optimizer.zero_grad(set_to_none=True)
    return total,clipped


def main():
    a=options();root=Path(a.data);manifest,parts=audit(root)
    if a.stage=='audit':return
    if a.base!=BASE:raise RuntimeError('Fixed base model is required')
    if not (a.epochs>=1 and a.max_length>128 and a.max_target_tokens>0 and a.lr>0):raise ValueError('Bad configuration')
    # Explicit checks below (avoid mistaking FIBNA scale constants for epsilon privacy).
    if a.method=='fibna' and not (a.shap_samples>=2*a.shap_features+2 and a.shap_every_steps>=1 and a.shap_features>=2):
        raise ValueError('Insufficient KernelSHAP coalitions or invalid feature groups')
    train=parts['target_train.csv']
    if a.max_train_records:
        if a.max_train_records>len(train):raise ValueError('Smoke cap too large')
        train=train.iloc[:a.max_train_records].copy()
    out=Path(a.out or ('xsum_'+a.method.replace('-','_')+'_qwen15_5ep'))
    requested_configuration={k:v for k,v in vars(a).items() if k not in ('out','stage','data')}
    summary_file=out/'run_summary.json'
    if summary_file.is_file():
        summary=json.loads(summary_file.read_text(encoding='utf8'))
        if (summary.get('target_train_csv_sha256')==sha_file(root/'target_train.csv')
            and summary.get('method')==a.method and summary.get('epochs')==a.epochs
            and summary.get('max_length')==a.max_length and summary.get('max_target_tokens')==a.max_target_tokens
            and summary.get('training_finished') is True
            and summary.get('requested_configuration')==requested_configuration
            and summary.get('train_count')==len(train)
            and (out/'adapter'/'adapter_config.json').is_file()
            and (a.method!='fibna' or (out/'lm_head_delta.safetensors').is_file())):
            print('SKIP verified finished checkpoint:',out);return
        raise RuntimeError('Existing checkpoint differs from requested protocol: '+str(out))
    if out.exists() and any(out.iterdir()):raise RuntimeError('Incomplete output exists. Inspect/move before retry: '+str(out))
    out.mkdir(parents=True,exist_ok=True)
    import torch
    from torch.utils.data import DataLoader
    from transformers import get_linear_schedule_with_warmup
    from peft import LoraConfig,get_peft_model
    from safetensors.torch import save_file
    if not torch.cuda.is_available():raise RuntimeError('CUDA GPU required')
    t_setup=time.perf_counter();device=torch.device('cuda:0')
    random.seed(a.seed);np.random.seed(a.seed);torch.manual_seed(a.seed);torch.cuda.manual_seed_all(a.seed)
    mode,dtype=dtype_choice(torch,a.dtype)
    tokenizer=tokenizer_model(a.base);codec=XSumCodec(tokenizer,a.max_length,a.max_target_tokens)
    examples=[codec.example(d,s) for d,s in zip(train.document,train.summary)]
    model=get_base(a.base,dtype);model.config.use_cache=False
    if a.method=='fibna':
        if model.get_input_embeddings().weight.data_ptr()!=model.get_output_embeddings().weight.data_ptr():
            raise RuntimeError('Expected tied Qwen output head for FP32 FIBNA adaptation')
        model.set_output_embeddings(FP32OutputHead.create(model.get_output_embeddings()))
    cfg=LoraConfig(r=a.rank,lora_alpha=a.alpha,lora_dropout=a.dropout,
                   target_modules=['q_proj','v_proj'],bias='none',task_type='CAUSAL_LM')
    model=get_peft_model(model,cfg)
    model.gradient_checkpointing_enable()
    if hasattr(model,'enable_input_require_grads'):model.enable_input_require_grads()
    model.to(device)
    params=[p for n,p in model.named_parameters() if p.requires_grad]
    unexpected=[n for n,p in model.named_parameters() if p.requires_grad and 'lora_' not in n]
    if unexpected:raise RuntimeError('Unexpected optimizer parameters: '+str(unexpected[:5]))
    nparams=sum(p.numel() for p in params)
    optimizer=torch.optim.AdamW(params,lr=a.lr,weight_decay=a.weight_decay)
    logical=a.logical_batch_size if a.method=='dp-lora' else a.batch_size*a.grad_accum
    steps_epoch=math.ceil(len(examples)/logical)
    total_steps=steps_epoch*a.epochs
    warmup=round(.03*total_steps)
    scheduler=get_linear_schedule_with_warmup(optimizer,num_warmup_steps=warmup,num_training_steps=total_steps)
    scalar=torch.amp.GradScaler('cuda',enabled=mode=='fp16')
    rng=np.random.default_rng(secrets.randbits(128));noise_rng=torch.Generator(device=device).manual_seed(secrets.randbits(63))
    noise_sigma=None;accountant=None
    if a.method=='dp-lora':
        from opacus.accountants import create_accountant
        from opacus.accountants.utils import get_noise_multiplier
        q=a.logical_batch_size/len(examples)
        if not 0<q<1:raise ValueError('DP sampling rate must satisfy 0<q<1')
        noise_sigma=(a.noise_multiplier if a.noise_multiplier>0 else get_noise_multiplier(
            target_epsilon=a.target_epsilon,target_delta=a.delta,sample_rate=q,steps=total_steps,accountant=a.accountant))
        accountant=create_accountant(mechanism=a.accountant)
    loader=None
    if a.method!='dp-lora':
        loader=DataLoader(examples,batch_size=a.batch_size,shuffle=True,
            generator=torch.Generator().manual_seed(a.seed),collate_fn=codec.collate,num_workers=0,pin_memory=True)
    head=None;initial_head=None;cache_psi=None
    shap_events=[];noise_events=[];shap_time=0.;noise_time=0.
    if a.method=='fibna':
        head=model.get_output_embeddings().weight
        if head.dtype!=torch.float32:raise RuntimeError('FIBNA head must be FP32')
        initial_head=head.detach().cpu().clone()
        fibna_rng=torch.Generator(device=device).manual_seed(a.seed+7600)
        kappa=(a.fibna_noise_nu/a.epsilon_code)*math.sqrt(2*math.log(1.25/a.delta_code))
    print('TRAIN',a.method,'epochs',a.epochs,'records',len(examples),'updates',total_steps,
          'trainable LoRA params',nparams,'dtype',mode,'GPU',torch.cuda.get_device_name(0),flush=True)
    torch.cuda.synchronize();setup_seconds=time.perf_counter()-t_setup
    epoch_rows=[];global_step=0;train_seconds=0.;peak_alloc=0.;peak_reserved=0.
    for epoch in range(a.epochs):
        model.train();torch.cuda.synchronize();torch.cuda.reset_peak_memory_stats()
        t_epoch=time.perf_counter();loss_sum=0.;n_examples=0;clip_count=0
        if a.method=='dp-lora':
            for local_step in range(steps_epoch):
                k=int(rng.binomial(len(examples),q))
                ix=rng.choice(len(examples),size=k,replace=False) if k else []
                selected=[examples[int(j)] for j in ix]
                losses,clips=dp_update(model,params,selected,codec,optimizer,torch,device,mode,
                       a.clip,noise_sigma,a.logical_batch_size,noise_rng)
                scheduler.step();accountant.step(noise_multiplier=noise_sigma,sample_rate=q)
                loss_sum+=losses;n_examples+=k;clip_count+=clips;global_step+=1
                if a.log_every and global_step%a.log_every==0:
                    print(f'  DP epoch {epoch+1} step {local_step+1}/{steps_epoch} sampled {n_examples}',flush=True)
        else:
            optimizer.zero_grad(set_to_none=True);micro=0
            for i,batch in enumerate(loader):
                if a.method=='fibna' and micro==0:
                    if cache_psi is None or global_step%a.shap_every_steps==0:
                        torch.cuda.synchronize();t=time.perf_counter()
                        cache_psi,stat=compute_shap_psi(model,batch,codec,torch,mode,device,
                            a.shap_features,a.shap_samples,a.seed+37*global_step,
                            forward_batch=a.shap_forward_batch,max_prompt_tokens=0)
                        torch.cuda.synchronize();dt=time.perf_counter()-t;shap_time+=dt
                        shap_events.append({'epoch':epoch+1,'optimizer_step':global_step,'wall_seconds':dt,**stat})
                        model.train()
                    if global_step%a.noise_every_steps==0:
                        torch.cuda.synchronize();t=time.perf_counter()
                        stat=add_fibna_noise(head,cache_psi,kappa,fibna_rng,chunk_rows=1024)
                        torch.cuda.synchronize();dt=time.perf_counter()-t;noise_time+=dt
                        noise_events.append({'epoch':epoch+1,'optimizer_step':global_step,'wall_seconds':dt,**stat})
                batch={k:v.to(device,non_blocking=True) for k,v in batch.items()}
                with autocast(torch,mode):loss=model(**batch,use_cache=False).loss
                if not bool(torch.isfinite(loss)):raise FloatingPointError('Nonfinite training loss')
                count=int((batch['labels'][:,1:]!=-100).sum().item())
                loss_sum+=float(loss.detach().float().item())*count;n_examples+=count
                group_size=min(a.grad_accum,len(loader)-(i//a.grad_accum)*a.grad_accum)
                scalar.scale(loss/group_size).backward();micro+=1
                if micro==a.grad_accum or i+1==len(loader):
                    scalar.unscale_(optimizer)
                    torch.nn.utils.clip_grad_norm_(params,1.)
                    scalar.step(optimizer);scalar.update();scheduler.step();optimizer.zero_grad(set_to_none=True)
                    global_step+=1;micro=0
                if a.log_every and (i+1)%a.log_every==0:
                    print(f'  {a.method} epoch {epoch+1} batch {i+1}/{len(loader)} loss={loss.item():.4f}',flush=True)
        torch.cuda.synchronize();dt=time.perf_counter()-t_epoch
        train_seconds+=dt;pa=torch.cuda.max_memory_allocated()/2**30;pr=torch.cuda.max_memory_reserved()/2**30
        peak_alloc=max(peak_alloc,pa);peak_reserved=max(peak_reserved,pr)
        row={'epoch':epoch+1,'training_wall_seconds':round(dt,4),'peak_gpu_training_allocated_gib':round(pa,4),
             'peak_gpu_training_reserved_gib':round(pr,4),'optimizer_steps_cumulative':global_step,
             'mean_supervised_nll':loss_sum/max(n_examples,1),
             'examples_or_supervised_tokens':n_examples}
        if accountant is not None:row['achieved_epsilon']=accountant.get_epsilon(delta=a.delta)
        epoch_rows.append(row)
        pd.DataFrame(epoch_rows).to_csv(out/'epoch_overhead.csv',index=False)
        if shap_events:pd.DataFrame(shap_events).to_csv(out/'shap_events.csv',index=False)
        if noise_events:pd.DataFrame(noise_events).to_csv(out/'noise_events.csv',index=False)
        print('Epoch completed:',row,flush=True)
    torch.cuda.synchronize();t_save=time.perf_counter()
    model.save_pretrained(out/'adapter',safe_serialization=True,
                          **({'save_embedding_layers':False} if a.method=='fibna' else {}))
    tokenizer.save_pretrained(out/'adapter')
    if a.method=='fibna':
        delta=(head.detach().cpu()-initial_head).contiguous()
        save_file({'lm_head_delta':delta},str(out/'lm_head_delta.safetensors'))
        (out/'fibna_checkpoint.json').write_text(json.dumps({
          'base':a.base,'formal_DP':False,'adapter_dir':'adapter',
          'head_delta_file':'lm_head_delta.safetensors','head_dtype':'fp32',
          'shap_samples':a.shap_samples,'shap_features':a.shap_features,
          'shap_every_optimizer_steps':a.shap_every_steps,'noise_coefficient_kappa':kappa},indent=2),encoding='utf8')
    torch.cuda.synchronize();save_seconds=time.perf_counter()-t_save
    prv=({'epsilon':float(accountant.get_epsilon(delta=a.delta)),'delta':a.delta,'sigma':float(noise_sigma),
          'clip':a.clip,'accountant':a.accountant,'sampling':'Poisson','sampling_rate':q,
          'note':'Privacy accounting presumes ideal Gaussian randomness; RNG is not cryptographic.'}
         if accountant is not None else None)
    if prv and not a.max_train_records and a.noise_multiplier==0 and prv['epsilon']>a.target_epsilon+1e-3:
        raise RuntimeError('Achieved epsilon exceeds calibrated target')
    result={'protocol':'XSum one-sentence summary-completion masked causal LM loss',
            'method':a.method,'model':a.base,'epochs':a.epochs,
            'requested_configuration':requested_configuration,
            'training_finished':True,'is_pilot':bool(a.max_train_records or a.epochs!=5),
            'seed':a.seed,'train_count':len(examples),
            'target_train_csv_sha256':sha_file(root/'target_train.csv'),
            'split_manifest_sha256':sha_file(root/'split_manifest.json'),
            'max_length':a.max_length,'max_target_tokens':a.max_target_tokens,
            'dtype':mode,'lora':{'rank':a.rank,'alpha':a.alpha,'dropout':a.dropout,'target_modules':['q_proj','v_proj']},
            'optimizer':{'name':'AdamW','lr':a.lr,'weight_decay':a.weight_decay,
                         'microbatch':1 if a.method=='dp-lora' else a.batch_size,
                         'grad_accum':None if a.method=='dp-lora' else a.grad_accum,
                         'effective_batch':logical,'warmup_steps':warmup},
            'trainable_params':nparams,'optimizer_steps_total':global_step,
            'training_wall_seconds':round(train_seconds,4),
            'peak_gpu_allocated_gib':round(peak_alloc,4),'peak_gpu_reserved_gib':round(peak_reserved,4),
            'privacy':prv,'fibna':({'kappa':kappa,'shap_samples':a.shap_samples,'shap_features':a.shap_features,
                                  'shap_refresh_steps':a.shap_every_steps,'noise_every_steps':a.noise_every_steps,
                                  'architecture':'untied frozen FP32 head; full-vocabulary KernelSHAP WLS'}
                                 if a.method=='fibna' else None),
            'software':{'python':sys.version.split()[0],'torch':torch.__version__,
                        'transformers':__import__('transformers').__version__,'peft':__import__('peft').__version__}}
    (out/'run_summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    overhead={'method':a.method,'training_wall_seconds':train_seconds,'training_wall_hours':train_seconds/3600,
              'peak_gpu_training_allocated_gib':peak_alloc,'peak_gpu_training_reserved_gib':peak_reserved,
              'optimizer_steps':global_step,'epoch_overhead':epoch_rows,
              'shap_wall_seconds':shap_time,'noise_wall_seconds':noise_time,'save_seconds':save_seconds,
              'measurement_protocol':'CUDA synchronized training epochs, excludes setup, evaluation and saving'}
    (out/'overhead_summary.json').write_text(json.dumps(overhead,indent=2)+'\n',encoding='utf8')
    if prv:(out/'privacy_progress.json').write_text(json.dumps(prv,indent=2)+'\n',encoding='utf8')
    print('PASS saved',a.method,out,'time hours',train_seconds/3600,'GPU GiB',peak_alloc,flush=True)
if __name__=='__main__':main()
