@echo off
setlocal EnableExtensions
cd /d "%~dp0"
REM This file should be extracted into demia_multitask project ROOT.
REM Both FIBNA checkpoints must already be trained at nu=4e-4.
REM It will NOT retrain or overwrite checkpoints.

set "PYTHONNOUSERSITE=1"
set "MKL_THREADING_LAYER=SEQUENTIAL"
set "OMP_NUM_THREADS=1"
set "MKL_NUM_THREADS=1"
set "OPENBLAS_NUM_THREADS=1"
set "NUMEXPR_NUM_THREADS=1"
set "PYTHONUNBUFFERED=1"
set "ROOT=%CD%"
set "SWEEP=FIBNA_Gaussian_Noise_Sensitivity_Qwen_AGNews_XSum\noise_sweep.py"
set "XDATA=xsum_qwen_pipeline\xsum_qwen15_data"
if not exist "%SWEEP%" (echo ERROR: Missing %SWEEP% & exit /b 2)
if not exist "%XDATA%\split_manifest.json" (echo ERROR: Missing %XDATA%\split_manifest.json & exit /b 2)

if not exist "fibna_noise_sweep_runs\agnews\nu_4p000em04\run_summary.json" (echo ERROR: AG News highest-noise checkpoint missing & exit /b 2)
if not exist "fibna_noise_sweep_runs\xsum\nu_4p000em04\run_summary.json" (echo ERROR: XSum highest-noise checkpoint missing & exit /b 2)

set "STATUS=0"
echo [1/4] AG News and XSum held-out utility
python "%SWEEP%" --stage utility --project-root "%ROOT%" --tasks agnews xsum --noise-values 4e-4 --xsum-data "%XDATA%" --reuse-baseline
if errorlevel 1 (set "STATUS=1" & goto :report)

echo [2/4] AG News attacks (EZ-MIA, ICP-MIA, Min-K%++)
python "%SWEEP%" --stage attacks --project-root "%ROOT%" --tasks agnews --noise-values 4e-4 --xsum-data "%XDATA%" --reuse-baseline
if errorlevel 1 (set "STATUS=1" & goto :report)

echo [3/4] XSum attacks (EZ-MIA, ICP-MIA, Min-K%++)
python "%SWEEP%" --stage attacks --project-root "%ROOT%" --tasks xsum --noise-values 4e-4 --xsum-data "%XDATA%" --reuse-baseline
if errorlevel 1 (set "STATUS=1" & goto :report)

echo [4/4] Gather results and plot
python "%SWEEP%" --stage plot --project-root "%ROOT%" --tasks agnews xsum --noise-values 4e-4 --xsum-data "%XDATA%" --reuse-baseline
if errorlevel 1 set "STATUS=1"

:report
REM Generate a measured report even if a previous stage was interrupted.
python build_evaluation_report.py --project-root "%ROOT%"
if errorlevel 1 set "STATUS=1"
echo.
echo REPORT: fibna_noise_sweep_runs\evaluation_report_nu_4p000em04\FIBNA_AGNews_XSum_Highest_Noise_Evaluation.md
if "%STATUS%"=="0" echo SUCCESS: Utility and attacks evaluated for both tasks.
if not "%STATUS%"=="0" echo PARTIAL: See report for pending measurements. Rerun this CMD to resume.
exit /b %STATUS%
