#!/usr/bin/env python3
"""Copy the existing paper-aligned MIA runner with FIBNA checkpoint loading.

This changes only checkpoint restoration/provenance. EZ-MIA, ICP-MIA and
Min-K%++ attack equations and candidate partitions remain unchanged.
The original run_three_mia_agnews.py is never overwritten.
"""
from pathlib import Path


def main():
    src=Path('run_three_mia_agnews.py')
    out=Path('run_three_mia_agnews_fibna.py')
    if not src.is_file():
        raise FileNotFoundError('Copy the earlier Step MIA runner run_three_mia_agnews.py to this directory')
    code=src.read_text(encoding='utf8')
    old='''    for f in sorted(files):
        h.update(str(f.relative_to(path)).encode()); h.update(sha_file(f).encode())
    return h.hexdigest()'''
    new='''    for f in sorted(files):
        h.update(str(f.relative_to(path)).encode()); h.update(sha_file(f).encode())
    fibna_run=path.parent
    config_file=fibna_run/'fibna_checkpoint.json'
    if config_file.is_file():
        conf=json.loads(config_file.read_text(encoding='utf8'))
        extra=fibna_run/conf['head_delta_file']
        if not extra.is_file():raise FileNotFoundError('Missing full FIBNA head delta: '+str(extra))
        h.update(b'full-fibna-head-delta-v1')
        h.update(sha_file(config_file).encode())
        h.update(sha_file(extra).encode())
    return h.hexdigest()'''
    if code.count(old)!=1:raise RuntimeError('Attack runner changed: fingerprint patch anchor not unique')
    code=code.replace(old,new)
    old='''    opts={'torch_dtype':dtype}
    try:model=AutoModelForCausalLM.from_pretrained(a.base,**opts)
    except TypeError:model=AutoModelForCausalLM.from_pretrained(a.base,dtype=dtype)
    if mode=='target':
        from peft import PeftModel
        model=PeftModel.from_pretrained(model,a.adapter,is_trainable=False)
    model.eval().to('cuda:0')'''
    new='''    # FIBNA target requires BOTH adapter and FP32 output-head delta.
    is_fibna=(mode=='target' and (Path(a.adapter).parent/'fibna_checkpoint.json').is_file())
    if is_fibna:
        from load_agnews_qwen_fibna import load_fibna_model
        model=load_fibna_model(Path(a.adapter).parent,base_model=a.base,
                               dtype=a.dtype,device='cuda:0')
    else:
        opts={'torch_dtype':dtype}
        try:model=AutoModelForCausalLM.from_pretrained(a.base,**opts)
        except TypeError:model=AutoModelForCausalLM.from_pretrained(a.base,dtype=dtype)
        if mode=='target':
            from peft import PeftModel
            model=PeftModel.from_pretrained(model,a.adapter,is_trainable=False)
    model.eval().to('cuda:0')'''
    if code.count(old)!=1:raise RuntimeError('Attack runner changed: load_model patch anchor not unique')
    code=code.replace(old,new)
    if out.exists():raise FileExistsError(out)
    out.write_text(code,encoding='utf8')
    print('Created',out,'from',src,'with FIBNA checkpoint loader/provenance patches')

if __name__=='__main__':main()
