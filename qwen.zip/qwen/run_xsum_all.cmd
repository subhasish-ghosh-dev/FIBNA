@echo off
setlocal EnableExtensions
cd /d "%~dp0"
REM Complete, reproducible XSum Qwen2.5-1.5B experiment.
REM Requires existing gpu_env, CUDA, Hugging Face model/dataset access.
REM Training 3 methods x 5 epochs can take substantial GPU time.
REM This script stops immediately on errors. Finished stages have validated resume behavior.
call conda activate gpu_env
if errorlevel 1 (echo ERROR: activate gpu_env first or fix conda. & exit /b 1)

call :RUN python test_protocol.py
if errorlevel 1 exit /b 1
call :RUN python test_report_synthetic.py
if errorlevel 1 exit /b 1
call :RUN python prepare_xsum.py --stage prepare --out xsum_qwen15_data --seed 42
if errorlevel 1 exit /b 1
call :RUN python prepare_xsum.py --stage audit --out xsum_qwen15_data
if errorlevel 1 exit /b 1

REM Identical pretrained base, rank 8, alpha 16, 10k examples, five epochs.
call :RUN python train_xsum.py --stage train --method lora --epochs 5 --max-length 512 --max-target-tokens 64 --batch-size 2 --grad-accum 8 --dtype bf16
if errorlevel 1 exit /b 1
call :RUN python train_xsum.py --stage train --method dp-lora --epochs 5 --max-length 512 --max-target-tokens 64 --logical-batch-size 16 --target-epsilon 10 --delta 1e-5 --clip 1 --dtype bf16
if errorlevel 1 exit /b 1
call :RUN python train_xsum.py --stage train --method fibna --epochs 5 --max-length 512 --max-target-tokens 64 --batch-size 2 --grad-accum 8 --shap-features 8 --shap-samples 100 --shap-every-steps 125 --noise-every-steps 1 --fibna-noise-nu 0.0001 --dtype bf16
if errorlevel 1 exit /b 1

for %%M in (lora dp-lora fibna) do (
    call :RUN python eval_xsum.py --method %%M --split val --num-beams 4 --max-new-tokens 64 --bootstrap 1000
    if errorlevel 1 exit /b 1
    call :RUN python eval_xsum.py --method %%M --split test --num-beams 4 --max-new-tokens 64 --bootstrap 1000
    if errorlevel 1 exit /b 1
)

REM Attack stages write resumable per-sample caches. DP/FIBNA never use LoRA-only loaders.
for %%M in (lora dp-lora fibna) do (
    call :RUN python mia_xsum.py --stage audit --method %%M
    if errorlevel 1 exit /b 1
    call :RUN python mia_xsum.py --stage score-target --method %%M
    if errorlevel 1 exit /b 1
    call :RUN python mia_xsum.py --stage score-base --method %%M
    if errorlevel 1 exit /b 1
    call :RUN python mia_xsum.py --stage score-icp --method %%M --icp-candidates 3 --icp-max-length 1200
    if errorlevel 1 exit /b 1
    call :RUN python mia_xsum.py --stage report --method %%M --bootstrap 1000
    if errorlevel 1 exit /b 1
)

call :RUN python report_xsum.py
if errorlevel 1 exit /b 1
echo.
echo SUCCESS: XSum full pipeline completed.
echo Results: %CD%\xsum_qwen15_manuscript_results
exit /b 0

:RUN
echo.
echo ================================================================
echo Running: %*
echo ================================================================
%*
if errorlevel 1 (
    echo ERROR: Command failed. Correct the cause and rerun this CMD to resume.
    exit /b 1
)
exit /b 0
