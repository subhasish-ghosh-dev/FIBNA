@echo off
setlocal EnableExtensions
REM Qwen2.5-1.5B FIBNA: highest Gaussian-noise setting (nu = 4e-4).
REM Run this from the project root that contains the patched sweep folder and datasets.

set "PYTHONNOUSERSITE=1"
set "MKL_THREADING_LAYER=SEQUENTIAL"
set "OMP_NUM_THREADS=1"
set "MKL_NUM_THREADS=1"
set "OPENBLAS_NUM_THREADS=1"
set "NUMEXPR_NUM_THREADS=1"
set "PYTHONUNBUFFERED=1"

set "PROJECT=%CD%"
set "SWEEP=FIBNA_Gaussian_Noise_Sensitivity_Qwen_AGNews_XSum\noise_sweep.py"

if not exist "%SWEEP%" (
  echo ERROR: Run this file from the project root containing %SWEEP%.
  exit /b 2
)

where python >nul 2>nul
if errorlevel 1 (
  echo ERROR: Python is not available. Activate the gpu_env Conda environment first.
  exit /b 3
)

echo ================================================================
echo [1/5] Train AG News AND XSum at the highest FIBNA noise level.
echo ================================================================
python "%SWEEP%" --stage train --project-root "%PROJECT%" --tasks agnews xsum --noise-values 4e-4 --reuse-baseline
if errorlevel 1 goto :failed

echo ================================================================
echo [2/5] Evaluate held-out utility for BOTH tasks.
echo ================================================================
python "%SWEEP%" --stage utility --project-root "%PROJECT%" --tasks agnews xsum --noise-values 4e-4 --reuse-baseline
if errorlevel 1 goto :failed

echo ================================================================
echo [3/5] Evaluate AG News: EZ-MIA, ICP-MIA, Min-K%%++.
echo ================================================================
python "%SWEEP%" --stage attacks --project-root "%PROJECT%" --tasks agnews --noise-values 4e-4 --reuse-baseline
if errorlevel 1 goto :failed

echo ================================================================
echo [4/5] Evaluate XSum: EZ-MIA, ICP-MIA, Min-K%%++.
echo ================================================================
python "%SWEEP%" --stage attacks --project-root "%PROJECT%" --tasks xsum --noise-values 4e-4 --reuse-baseline
if errorlevel 1 goto :failed

echo ================================================================
echo [5/5] Collect measurements and create graphs.
echo ================================================================
python "%SWEEP%" --stage plot --project-root "%PROJECT%" --tasks agnews xsum --noise-values 4e-4 --reuse-baseline
if errorlevel 1 goto :failed

echo.
echo SUCCESS: Both tasks completed at nu=4e-4.
echo Results in: %PROJECT%\fibna_noise_sweep_runs
exit /b 0

:failed
echo.
echo ERROR: A stage failed. Completed checkpoints/results remain on disk.
echo Consult README for the command to rerun only the failing stage.
exit /b 1
