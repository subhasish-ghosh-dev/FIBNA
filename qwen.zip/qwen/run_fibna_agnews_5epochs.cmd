@echo off
setlocal
cd /d D:\Subhasish\projects\med_text_gan\demia_multitask
python train_agnews_qwen_fibna.py --stage self-test || exit /b 1
python train_agnews_qwen_fibna.py --stage audit --data agnews_demia_qwen15 || exit /b 1
python train_agnews_qwen_fibna.py ^
  --stage train ^
  --data agnews_demia_qwen15 ^
  --out agnews_fibna_qwen15_5ep ^
  --base Qwen/Qwen2.5-1.5B ^
  --seed 42 ^
  --epochs 5 ^
  --rank 8 ^
  --alpha 16 ^
  --dropout 0.05 ^
  --max-length 256 ^
  --batch-size 2 ^
  --grad-accum 8 ^
  --lr 0.0001 ^
  --dtype bf16 ^
  --shap-features 8 ^
  --shap-samples 100 ^
  --shap-every-steps 125 ^
  --noise-every-steps 1 ^
  --noise-multiplier 0.0001 ^
  --epsilon-code 10 ^
  --delta-code 1e-5 ^
  --eval-last-only
if errorlevel 1 exit /b 1
endlocal
