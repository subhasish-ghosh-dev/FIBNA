#!/usr/bin/env python
"""Aggregate the measured XSum utility, computational cost and 3 MIAs into manuscript tables."""
import argparse,json
from pathlib import Path
import pandas as pd
from xsum_common import audit,sha_file
from eval_xsum import fingerprint

METHODS=['lora','dp-lora','fibna']
ATTACKS=['ez_mia_full','icp_mia_reference','min_k_pp_full']
TITLES={'lora':'LoRA','dp-lora':'DP-LoRA','fibna':'FIBNA',
        'ez_mia_full':'EZ-MIA','icp_mia_reference':'ICP-MIA','min_k_pp_full':r'Min-K\%++'}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data',default='xsum_qwen15_data')
    p.add_argument('--out',default='xsum_qwen15_manuscript_results')
    a=p.parse_args();audit(a.data)
    rows=[];attack_rows=[];train_sha=sha_file(Path(a.data)/'target_train.csv')
    for m in METHODS:
        run=Path('xsum_'+m.replace('-','_')+'_qwen15_5ep')
        r=run/'run_summary.json';v=run/'utility_test'/'test_metrics.json';at=run/'three_mia'/'attack_results.csv'
        for f in (r,v,at):
            if not f.is_file():raise FileNotFoundError('Whole-pipeline results incomplete: '+str(f))
        tr=json.loads(r.read_text(encoding='utf8'));util=json.loads(v.read_text(encoding='utf8'))
        if tr.get('is_pilot') or not tr.get('training_finished') or tr.get('epochs')!=5:
            raise RuntimeError(m+' is not a completed five-epoch training run')
        if tr.get('target_train_csv_sha256')!=train_sha or util.get('test_count')!=2000 or util.get('is_pilot'):
            raise RuntimeError(m+' training/test provenance mismatch')
        rows.append({'method':TITLES[m],'rouge1':util['rouge1'],'rouge2':util['rouge2'],
                     'rougeL':util['rougeL'],'training_hours':tr['training_wall_seconds']/3600,
                     'peak_gpu_gib':tr['peak_gpu_allocated_gib']})
        expected_fp=fingerprint(run,m)
        ep=run/'utility_test'/'evaluation_provenance.json'
        if not ep.is_file():raise FileNotFoundError(ep)
        epmeta=json.loads(ep.read_text(encoding='utf8'))
        if epmeta.get('checkpoint_fingerprint')!=expected_fp or epmeta.get('data_sha256')!=sha_file(Path(a.data)/'split_manifest.json'):
            raise RuntimeError(m+' utility metrics not backed by the current checkpoint')
        for st in ('target_tokens','icp'):
            p=run/'three_mia'/(st+'.provenance.json')
            if not p.is_file():raise FileNotFoundError(p)
            ameta=json.loads(p.read_text(encoding='utf8'))
            if ameta.get('checkpoint')!=expected_fp or ameta.get('manifest_sha256')!=sha_file(Path(a.data)/'split_manifest.json'):
                raise RuntimeError(m+' attack scores not backed by current checkpoint')
        attacks=pd.read_csv(at)
        for attack in ATTACKS:
            hit=attacks[attacks.attack.eq(attack)]
            if len(hit)!=1 or pd.isna(hit.iloc[0].roc_auc):
                raise RuntimeError(f'Attack {attack} incomplete for {m}')
            x=hit.iloc[0]
            attack_rows.append({'attack':attack,'method':m,'roc_auc':float(x.roc_auc),
                                'tpr':float(x.tpr_at_1pct_fpr)*100,
                                'fpr':float(x.observed_fpr)*100,'coverage':float(x.coverage)*100})
    table=pd.DataFrame(rows)
    attacks=pd.DataFrame(attack_rows)
    baseline=table.iloc[0]
    table['time_overhead_pct']=(table.training_hours/baseline.training_hours-1)*100
    table['memory_overhead_pct']=(table.peak_gpu_gib/baseline.peak_gpu_gib-1)*100
    attack_base=attacks[attacks.method=='lora'].set_index('attack').tpr.to_dict()
    attacks['delta_tpr_pp']=attacks.apply(lambda r:attack_base[r.attack]-r.tpr,axis=1)
    out=Path(a.out);out.mkdir(exist_ok=True,parents=True)
    table.to_csv(out/'xsum_utility_overhead.csv',index=False)
    attacks.to_csv(out/'xsum_mia_results.csv',index=False)
    fmt=[]
    for r in table.itertuples(index=False):
        fmt.append(f'{r.method} & {r.rouge1:.2f} & {r.rouge2:.2f} & {r.rougeL:.2f} & {r.training_hours:.3f} & {r.peak_gpu_gib:.3f} '+r'\\')
    tex=[r'\begin{table*}[!t]',r'\centering\small',
         r'\caption{Held-out XSum summarization utility and five-epoch computational overhead of Qwen2.5-1.5B (ROUGE F1 in percent; training-only CUDA-synchronized time and peak allocated memory).}',
         r'\label{tab:xsum_utility}',r'\begin{tabular}{lrrrrr}',r'\toprule',
         'Method & ROUGE-1 & ROUGE-2 & ROUGE-L & Time (h) & GPU (GiB) '+r'\\',r'\midrule',*fmt,r'\bottomrule',r'\end{tabular}',r'\end{table*}']
    (out/'xsum_utility_table.tex').write_text('\n'.join(tex)+'\n',encoding='utf8')
    sec=[]
    for attack in ATTACKS:
        for r in attacks[attacks.attack==attack].itertuples(index=False):
            sec.append(f'{TITLES[attack]} & {TITLES[r.method]} & {r.roc_auc:.4f} & {r.tpr:.2f} & {r.fpr:.2f} & {r.delta_tpr_pp:+.2f} '+r'\\')
        if attack!=ATTACKS[-1]:sec.append(r'\addlinespace[2pt]')
    tex=[r'\begin{table*}[!t]',r'\centering\small',
        r'\caption{XSum membership inference on Qwen2.5-1.5B using published attack-score adaptations. A 1\% FPR threshold is selected on an independent calibration set; observed test FPR and the change in test TPR relative to LoRA (percentage points) are reported.}',
        r'\label{tab:xsum_mia}',r'\begin{tabular}{llrrrr}',r'\toprule',
        r'Attack & Fine-tuning & ROC-AUC & TPR@1\%FPR (\%) & Test FPR (\%) & $\Delta$TPR (pp) \\',
        r'\midrule',*sec,r'\bottomrule',r'\end{tabular}',r'\end{table*}']
    (out/'xsum_mia_table.tex').write_text('\n'.join(tex)+'\n',encoding='utf8')
    print('PASS consolidated:',out.resolve())
    print(table.to_string(index=False));print(attacks.to_string(index=False))
if __name__=='__main__':main()
