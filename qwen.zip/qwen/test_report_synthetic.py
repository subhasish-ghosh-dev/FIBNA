#!/usr/bin/env python
"""CPU-only synthetic integration test (never publication results)."""
import json,sys,types,tempfile,os
from pathlib import Path
import numpy as np
import pandas as pd
from xsum_common import audit,sha_file
from prepare_xsum import create
from mia_xsum import report as mia_report,fingerprint


def main():
    def make(split,n):
        return [{'id':f'{split}{i}','document':f'{split} report test document {i}',
                 'summary':f'Summary for {split} document {i}.'} for i in range(n)]
    prev=sys.modules.get('datasets');fake=types.ModuleType('datasets')
    fake.load_dataset=lambda name:{'train':make('train',5101),
                                    'validation':make('val',20),'test':make('test',20)}
    sys.modules['datasets']=fake
    try:
        with tempfile.TemporaryDirectory() as t:
            t=Path(t);data=t/'xsum_qwen15_data'
            create(data,42,2500,4,4,4)
            _,tables=audit(data);attack=tables['attack_all.csv']
            for method in ['lora','dp-lora','fibna']:
                out=t/f'xsum_{method.replace("-","_")}_qwen15_5ep'
                (out/'adapter').mkdir(parents=True)
                (out/'adapter'/'adapter_config.json').write_text('{}')
                (out/'adapter'/'adapter_model.safetensors').write_bytes(b'synthetic adapter')
                if method=='fibna':
                    (out/'fibna_checkpoint.json').write_text('{}')
                    (out/'lm_head_delta.safetensors').write_bytes(b'synthetic delta')
                (out/'run_summary.json').write_text(json.dumps({'method':method,'model':'Qwen/Qwen2.5-1.5B',
                   'epochs':5,'max_length':512,'max_target_tokens':64,'training_finished':True,
                   'is_pilot':False,'target_train_csv_sha256':sha_file(data/'target_train.csv'),
                   'training_wall_seconds':20000.,'peak_gpu_allocated_gib':5.2}))
                (out/'utility_test').mkdir()
                (out/'utility_test'/'evaluation_provenance.json').write_text(json.dumps({
                   'checkpoint_fingerprint':fingerprint(out,method),
                   'data_sha256':sha_file(data/'split_manifest.json')}))
                (out/'utility_test'/'test_metrics.json').write_text(json.dumps({'test_count':2000,
                   'is_pilot':False,'rouge1':30.,'rouge2':12.,'rougeL':27.}))
                mia=out/'three_mia';mia.mkdir()
                rows=[];base=[];icp=[]
                for i,row in enumerate(attack.itertuples(index=False)):
                    logp=[-1.,-2.,-3.];ref=[-1.1,-2.1,-3.2]
                    # Fake token IDs shared between base/target.
                    rows.append({'sample_id':row.sample_id,'attack_split':row.attack_split,
                                 'membership':row.membership,'ids_sha256':'f','n_tokens':3,
                                 'n_completion_tokens':2,'logp_json':json.dumps(logp),
                                 'error_json':json.dumps([1,0,1]),'min_k_pp_full':i%19/100.,
                                 'min_k_pp_completion':i%23/100.,'n_error_full':2,'n_error_completion':1})
                    base.append({'sample_id':row.sample_id,'attack_split':row.attack_split,
                                 'membership':row.membership,'ids_sha256':'f','n_tokens':3,
                                 'logp_json':json.dumps(ref)})
                    icp.append({'sample_id':row.sample_id,'attack_split':row.attack_split,
                                 'membership':row.membership,'icp_score':i%17/100.})
                pd.DataFrame(rows).to_csv(mia/'target_tokens.csv',index=False)
                pd.DataFrame(base).to_csv(mia/'base_tokens.csv',index=False)
                pd.DataFrame(icp).to_csv(mia/'icp_scores.csv',index=False)
                c=fingerprint(out,method);mh=sha_file(data/'split_manifest.json')
                for name,info in [('target_tokens',{'manifest_sha256':mh,'checkpoint':c}),
                                  ('base_tokens',{'manifest_sha256':mh,'checkpoint':'pretrained Qwen base'}),
                                  ('icp',{'manifest_sha256':mh,'checkpoint':c})]:
                    (mia/(name+'.provenance.json')).write_text(json.dumps(info))
                a=types.SimpleNamespace(out=str(mia),data=str(data),checkpoint=str(out),
                                        method=method,bootstrap=0,seed=42)
                mia_report(a,attack)
            import subprocess
            rr=subprocess.run([sys.executable,str(Path(__file__).parent/'report_xsum.py'),
                '--data',str(data),'--out',str(t/'manuscript')],cwd=t,capture_output=True,text=True)
            assert rr.returncode==0,(rr.stdout,rr.stderr)
            assert (t/'manuscript'/'xsum_mia_table.tex').is_file()
            assert (t/'manuscript'/'xsum_utility_table.tex').is_file()
            print('PASS: synthetic 3-method 3-attack reporting and LaTeX tables (NOT empirical results)')
    finally:
        if prev is None:sys.modules.pop('datasets',None)
        else:sys.modules['datasets']=prev
if __name__=='__main__':main()
