#!/usr/bin/env python
"""Evaluate held-out XSum summarization: ROUGE-1, ROUGE-2 and ROUGE-L (F1, %)."""
from __future__ import annotations
import argparse,json,time
from pathlib import Path
import numpy as np
import pandas as pd
from xsum_common import BASE,XSumCodec,audit,load_target,sha_file,tokenizer_model


def fingerprint(run_dir,method):
    run_dir=Path(run_dir)
    bits=[run_dir/'run_summary.json',run_dir/'adapter'/'adapter_config.json',
          run_dir/'adapter'/'adapter_model.safetensors']
    if method=='fibna':bits.extend([run_dir/'fibna_checkpoint.json',run_dir/'lm_head_delta.safetensors'])
    for f in bits:
        if not f.is_file():raise FileNotFoundError(f)
    return {f.name:sha_file(f) for f in bits}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--method',required=True,choices=('lora','dp-lora','fibna'))
    p.add_argument('--data',default='xsum_qwen15_data')
    p.add_argument('--checkpoint',default=None)
    p.add_argument('--out',default=None)
    p.add_argument('--split',choices=('test','val'),default='test')
    p.add_argument('--dtype',choices=('bf16','fp16','fp32'),default='bf16')
    p.add_argument('--max-new-tokens',type=int,default=64)
    p.add_argument('--num-beams',type=int,default=4)
    p.add_argument('--limit',type=int,default=0,help='Smoke test only; 0=all')
    p.add_argument('--bootstrap',type=int,default=1000)
    a=p.parse_args();_,tables=audit(a.data)
    run=Path(a.checkpoint or ('xsum_'+a.method.replace('-','_')+'_qwen15_5ep'))
    out=Path(a.out or str(run/('utility_'+a.split)));out.mkdir(parents=True,exist_ok=True)
    target=tables['utility_test.csv' if a.split=='test' else 'utility_val.csv']
    if a.limit>0:target=target.iloc[:a.limit].copy()
    meta=json.loads((run/'run_summary.json').read_text(encoding='utf8'))
    if meta.get('target_train_csv_sha256')!=sha_file(Path(a.data)/'target_train.csv'):
        raise RuntimeError('Checkpoint was trained on a different XSum data manifest')
    provenance={'checkpoint_fingerprint':fingerprint(run,a.method),
                'data_sha256':sha_file(Path(a.data)/'split_manifest.json'),
                'split':a.split,'limit':a.limit,'num_beams':a.num_beams,
                'max_new_tokens':a.max_new_tokens,'dtype':a.dtype}
    prov=out/'evaluation_provenance.json'
    if prov.is_file() and json.loads(prov.read_text(encoding='utf8'))!=provenance:
        raise RuntimeError('Evaluation protocol changed; choose a different output folder')
    prov.write_text(json.dumps(provenance,indent=2),encoding='utf8')
    pred_file=out/'predictions.csv'
    if pred_file.is_file():
        pred=pd.read_csv(pred_file,keep_default_na=False,dtype={'sample_id':str})
        if pred.sample_id.duplicated().any() or not set(pred.sample_id).issubset(set(target.sample_id)):
            raise RuntimeError('Corrupt or foreign prediction cache')
    else:pred=pd.DataFrame(columns=['sample_id','reference','prediction'])
    finished=set(pred.sample_id)
    if len(finished)<len(target):
        import torch
        if not torch.cuda.is_available():raise RuntimeError('CUDA GPU required')
        from tqdm.auto import tqdm
        tok=tokenizer_model(BASE);codec=XSumCodec(tok,meta['max_length'],meta['max_target_tokens'])
        model,run_meta=load_target(a.method,run,BASE,a.dtype)
        with pred_file.open('a',newline='',encoding='utf8') as f:
            import csv
            writer=csv.DictWriter(f,['sample_id','reference','prediction'])
            if not finished:writer.writeheader()
            for ix,row in enumerate(tqdm(target.itertuples(index=False),total=len(target),desc='ROUGE eval')):
                if row.sample_id in finished:continue
                prompt=codec.prompt_ids(row.document)
                ids=torch.tensor([prompt],dtype=torch.long,device='cuda:0')
                attn=torch.ones_like(ids)
                with torch.inference_mode():
                    gen=model.generate(input_ids=ids,attention_mask=attn,
                        max_new_tokens=a.max_new_tokens,num_beams=a.num_beams,
                        do_sample=False,pad_token_id=tok.eos_token_id,eos_token_id=tok.eos_token_id)
                output=tok.decode(gen[0,len(prompt):],skip_special_tokens=True).strip()
                writer.writerow({'sample_id':row.sample_id,'reference':row.summary,'prediction':output})
                if (ix+1)%25==0:f.flush()
            f.flush()
        del model
    pred=pd.read_csv(pred_file,keep_default_na=False,dtype={'sample_id':str})
    if len(pred)!=len(target) or set(pred.sample_id)!=set(target.sample_id):raise RuntimeError('Test evaluation incomplete')
    pred=target[['sample_id','summary']].merge(pred,on='sample_id',validate='one_to_one')
    if not (pred['summary']==pred.reference).all():raise RuntimeError('Reference summaries changed')
    from rouge_score import rouge_scorer
    scorer=rouge_scorer.RougeScorer(['rouge1','rouge2','rougeL'],use_stemmer=True)
    vals=np.array([[getattr(scorer.score(ref,out)[k],'fmeasure') for k in ('rouge1','rouge2','rougeL')]
                  for ref,out in zip(pred.reference,pred.prediction)])
    mean=vals.mean(axis=0)*100
    ci=np.full((2,3),np.nan)
    if a.bootstrap:
        rng=np.random.default_rng(42)
        boot=np.stack([vals[rng.integers(len(vals),size=len(vals))].mean(axis=0)
                       for _ in range(a.bootstrap)])*100
        ci=np.quantile(boot,[.025,.975],axis=0)
    result={'method':a.method,'dataset':'XSum','split':a.split,'test_count':len(pred),
            'is_pilot':bool(a.limit),'rouge1':float(mean[0]),'rouge2':float(mean[1]),'rougeL':float(mean[2]),
            'rouge1_ci95':ci[:,0].tolist(),'rouge2_ci95':ci[:,1].tolist(),
            'rougeL_ci95':ci[:,2].tolist(),'num_beams':a.num_beams,'max_new_tokens':a.max_new_tokens,
            'metric':'per-example ROUGE F1 averaged over all examples, using Porter stemming; percentages'}
    (out/'test_metrics.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    (out/'test_results_table.tex').write_text(
      '\\begin{tabular}{lrrr}\n\\hline\nMethod & ROUGE-1 & ROUGE-2 & ROUGE-L \\\\\n\\hline\n'+
      f'{a.method} & {mean[0]:.2f} & {mean[1]:.2f} & {mean[2]:.2f} '+r'\\'+'\n\\hline\n\\end{tabular}\n',encoding='utf8')
    print('COMPLETE',out,result,flush=True)
if __name__=='__main__':main()
