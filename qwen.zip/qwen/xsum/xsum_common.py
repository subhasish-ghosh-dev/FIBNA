"""Shared, immutable XSum Qwen causal-LM summarization protocol."""
from __future__ import annotations
import contextlib, hashlib, json, re
from pathlib import Path
import pandas as pd

BASE = 'Qwen/Qwen2.5-1.5B'
FILES = ['target_train.csv','utility_val.csv','utility_test.csv','attack_train.csv',
         'attack_calibration.csv','attack_test.csv','attack_all.csv','reference_pool.csv']


def sha_file(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for block in iter(lambda:f.read(1<<20),b''):h.update(block)
    return h.hexdigest()


def normalized_hash(text):
    return hashlib.sha256(re.sub(r'\s+',' ',str(text)).strip().encode('utf-8')).hexdigest()


def get_meta(root):
    root=Path(root)
    mf=root/'split_manifest.json'
    if not mf.is_file():raise FileNotFoundError(mf)
    meta=json.loads(mf.read_text(encoding='utf8'))
    if meta.get('base_model')!=BASE or meta.get('dataset')!='EdinburghNLP/xsum':
        raise RuntimeError('Wrong XSum experiment manifest/base model')
    for fn in FILES:
        p=root/fn
        if not p.is_file() or sha_file(p)!=meta['file_sha256'].get(fn):
            raise RuntimeError(f'Frozen split missing or changed: {p}')
    return meta


def audit(root):
    root=Path(root);meta=get_meta(root)
    tables={k:pd.read_csv(root/k,keep_default_na=False,dtype={'sample_id':str}) for k in FILES}
    required={'sample_id','document','summary','text_hash'}
    for name,df in tables.items():
        if not required.issubset(df.columns):raise RuntimeError(f'{name}: missing {required-set(df.columns)}')
        if df.sample_id.duplicated().any() or df.text_hash.duplicated().any():
            raise RuntimeError(f'{name}: duplicate sample IDs/documents')
        if any(normalized_hash(s)!=h for s,h in zip(df.document,df.text_hash)):
            raise RuntimeError(f'{name}: document/text hash mismatch')
        if len(df)!=meta['counts'][name]:raise RuntimeError(f'{name}: row count changed')
    disjoint=['target_train.csv','utility_val.csv','utility_test.csv']
    for i,ni in enumerate(disjoint):
        for nj in disjoint[i+1:]:
            if set(tables[ni].text_hash)&set(tables[nj].text_hash):
                raise RuntimeError(f'Cross-partition overlap: {ni}/{nj}')
    atr=tables['attack_all.csv']
    if len(atr)!=len(tables['attack_train.csv'])+len(tables['attack_calibration.csv'])+len(tables['attack_test.csv']):
        raise RuntimeError('Attack rows not partitioned exactly once')
    if atr.sample_id.duplicated().any():raise RuntimeError('Repeated attack samples')
    for section in ('attack_train','attack_calibration','attack_test'):
        d=tables[section+'.csv']
        if not (d.attack_split==section).all() or (d.membership.astype(int).value_counts().to_dict()!={0:len(d)//2,1:len(d)//2}):
            raise RuntimeError(f'Invalid attack balance: {section}')
        if set(d.sample_id)!=set(atr.loc[atr.attack_split==section,'sample_id']):
            raise RuntimeError(f'Attack partition mismatch: {section}')
    train_hash=set(tables['target_train.csv'].text_hash)
    mem=atr.loc[atr.membership.astype(int)==1]
    non=atr.loc[atr.membership.astype(int)==0]
    if not set(mem.text_hash).issubset(train_hash):raise RuntimeError('Attack member not in training population')
    if set(non.text_hash)&train_hash:raise RuntimeError('Attack nonmember in training population')
    ref=tables['reference_pool.csv']
    if set(ref.text_hash)&(set(atr.text_hash)|train_hash):raise RuntimeError('Contaminated ICP reference pool')
    print('PASS frozen XSum split audit:',len(tables['target_train.csv']),'train,',
          len(tables['utility_val.csv']),'val,',len(tables['utility_test.csv']),'test,',len(atr),'attack candidates')
    return meta,tables


class XSumCodec:
    """Identical tokenization for training, generation, scoring and attacks."""
    PRE='Summarize the following news article in one concise sentence.\n\nArticle:\n'
    TAIL='\n\nSummary:'
    def __init__(self,tok,max_length=512,max_target_tokens=64):
        self.tok=tok
        self.max_length=max_length;self.max_target_tokens=max_target_tokens
        self.pre=tok.encode(self.PRE,add_special_tokens=False)
        self.tail=tok.encode(self.TAIL,add_special_tokens=False)
        self.eos=tok.eos_token_id
        if self.eos is None:raise RuntimeError('Tokenizer requires EOS')
        if tok.pad_token_id is None:tok.pad_token=tok.eos_token
        if max_length< len(self.pre)+len(self.tail)+max_target_tokens+4:
            raise ValueError('max_length too small to preserve target completion')
    def prompt_ids(self,document):
        doc=self.tok.encode(str(document),add_special_tokens=False)
        room=self.max_length-len(self.pre)-len(self.tail)-self.max_target_tokens-1
        if room<1:raise ValueError('Article token budget exhausted')
        return self.pre+doc[:room]+self.tail
    def summary_ids(self,summary):
        ids=self.tok.encode(' '+str(summary).strip(),add_special_tokens=False)[:self.max_target_tokens]
        if not ids:raise ValueError('Empty summary completion')
        return ids+[self.eos]
    def example(self,document,summary):
        prompt=self.prompt_ids(document);comp=self.summary_ids(summary)
        ids=prompt+comp
        if len(ids)>self.max_length:raise RuntimeError('Codec exceeded maximum sequence length')
        return {'input_ids':ids,'labels':[-100]*len(prompt)+comp,'attention_mask':[1]*len(ids)}
    def collate(self,records):
        import torch
        ln=max(len(x['input_ids']) for x in records)
        return {'input_ids':torch.tensor([x['input_ids']+[self.tok.pad_token_id]*(ln-len(x['input_ids'])) for x in records],dtype=torch.long),
                'labels':torch.tensor([x['labels']+[-100]*(ln-len(x['labels'])) for x in records],dtype=torch.long),
                'attention_mask':torch.tensor([x['attention_mask']+[0]*(ln-len(x['attention_mask'])) for x in records],dtype=torch.long)}


def dtype_choice(torch,mode):
    if mode=='auto':mode='bf16' if torch.cuda.is_bf16_supported() else 'fp16'
    if mode not in ('bf16','fp16','fp32'):raise ValueError(mode)
    return mode,{'bf16':torch.bfloat16,'fp16':torch.float16,'fp32':torch.float32}[mode]


def autocast(torch,mode):
    if mode=='fp32':return contextlib.nullcontext()
    return torch.autocast(device_type='cuda',dtype={'bf16':torch.bfloat16,'fp16':torch.float16}[mode])


def tokenizer_model(base=BASE):
    from transformers import AutoTokenizer
    tok=AutoTokenizer.from_pretrained(base,use_fast=True)
    if tok.pad_token is None:tok.pad_token=tok.eos_token
    tok.padding_side='right'
    return tok


def get_base(base,torch_dtype):
    from transformers import AutoModelForCausalLM
    try: return AutoModelForCausalLM.from_pretrained(base,dtype=torch_dtype)
    except TypeError:return AutoModelForCausalLM.from_pretrained(base,torch_dtype=torch_dtype)


class FP32OutputHead:
    """Factory for a frozen, untied FP32 output head (Qwen FIBNA adaptation)."""
    @staticmethod
    def create(original):
        import torch
        class _Head(torch.nn.Module):
            def __init__(self,src):
                super().__init__()
                self.weight=torch.nn.Parameter(src.weight.detach().float().clone(),requires_grad=False)
            def forward(self,hidden):
                # No BF16 quantization of very small output-head perturbations.
                with torch.autocast(device_type='cuda',enabled=False):
                    return torch.nn.functional.linear(hidden.float(),self.weight)
        return _Head(original)


def load_target(method,run_dir,base=BASE,dtype='bf16',device='cuda:0'):
    import torch
    from peft import PeftModel
    from safetensors import safe_open
    run_dir=Path(run_dir)
    summary=run_dir/'run_summary.json'
    if not summary.is_file():raise FileNotFoundError(summary)
    meta=json.loads(summary.read_text(encoding='utf8'))
    if meta.get('method','').lower()!=method.lower() or meta.get('model')!=base:
        raise RuntimeError(f'Wrong method or model in {summary}')
    if meta.get('is_pilot') or meta.get('epochs')!=5:raise RuntimeError('Refusing pilot/non-five-epoch checkpoint')
    dt={'bf16':torch.bfloat16,'fp16':torch.float16,'fp32':torch.float32}[dtype]
    model=get_base(base,dt)
    if method.lower()=='fibna':
        cf=run_dir/'fibna_checkpoint.json'
        if not cf.is_file():raise FileNotFoundError(cf)
        cfg=json.loads(cf.read_text(encoding='utf8'))
        if not (cfg.get('base')==base and cfg.get('formal_DP') is False):raise RuntimeError('FIBNA provenance incompatible')
        if model.get_input_embeddings().weight.data_ptr()!=model.get_output_embeddings().weight.data_ptr():
            raise RuntimeError('FIBNA expects tied base Qwen embeddings')
        model.set_output_embeddings(FP32OutputHead.create(model.get_output_embeddings()))
        p=run_dir/cfg['head_delta_file']
        if not p.is_file():raise FileNotFoundError('FIBNA LM-head delta missing: '+str(p))
        with safe_open(str(p),framework='pt',device='cpu') as f:delta=f.get_tensor('lm_head_delta')
        head=model.get_output_embeddings().weight
        if tuple(delta.shape)!=tuple(head.shape) or delta.dtype!=torch.float32:raise RuntimeError('Corrupt FIBNA delta')
        with torch.no_grad():head.add_(delta)
    adapter=run_dir/'adapter'
    if not (adapter/'adapter_config.json').is_file():raise FileNotFoundError(adapter)
    model=PeftModel.from_pretrained(model,str(adapter),is_trainable=False)
    if method.lower()=='fibna' and model.get_input_embeddings().weight.data_ptr()==model.get_output_embeddings().weight.data_ptr():
        raise RuntimeError('FIBNA output head was retied during PEFT load')
    model.to(device).eval();model.config.use_cache=True
    return model,meta
