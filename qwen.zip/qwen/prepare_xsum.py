#!/usr/bin/env python
"""Deterministically prepare XSum summarization, utility and controlled-MIA partitions."""
import argparse,json,random
from pathlib import Path
import pandas as pd
from xsum_common import BASE,FILES,audit,normalized_hash,sha_file


def create(out,seed,train_n,val_n,test_n,ref_n):
    from datasets import load_dataset
    ds=load_dataset('EdinburghNLP/xsum')
    rng=random.Random(seed)
    seen=set()
    def unique_rows(split):
        rows=[]
        for row in ds[split]:
            doc=str(row['document']).strip();summary=str(row['summary']).strip()
            if not doc or not summary:continue
            h=normalized_hash(doc)
            if h in seen:continue
            seen.add(h)
            rows.append({'sample_id':f'{split}:{row["id"]}', 'document':doc,'summary':summary,'text_hash':h})
        rng.shuffle(rows)
        return rows
    # Deduplication precedence: official validation/test before original train.
    # This prevents membership contamination from official held-out documents.
    va=unique_rows('validation');te=unique_rows('test');tr=unique_rows('train')
    if len(va)<val_n+ref_n or len(te)<test_n or len(tr)<train_n+2500:
        raise RuntimeError(f'Insufficient unique data: train={len(tr)} val={len(va)} test={len(te)}')
    train=tr[:train_n];unused=tr[train_n:]
    if train_n<2500:raise ValueError('At least 2500 training members are required')
    if len(unused)<2500:raise ValueError('Need 2500 nonmember examples from unused XSum training partition')
    members=train[:2500];nonmembers=unused[:2500]
    partitions={}
    offset=0
    for name,k in (('attack_train',1000),('attack_calibration',500),('attack_test',1000)):
        rows=[]
        for item in members[offset:offset+k]:rows.append({**item,'membership':1,'attack_split':name})
        for item in nonmembers[offset:offset+k]:rows.append({**item,'membership':0,'attack_split':name})
        rng.shuffle(rows);partitions[name+'.csv']=rows
        offset+=k
    partitions['target_train.csv']=train
    partitions['utility_val.csv']=va[:val_n]
    partitions['reference_pool.csv']=va[val_n:val_n+ref_n]
    partitions['utility_test.csv']=te[:test_n]
    partitions['attack_all.csv']=sum([partitions[n+'.csv'] for n in ('attack_train','attack_calibration','attack_test')],[])
    out.mkdir(parents=True,exist_ok=False)
    hashes={};counts={}
    for file in FILES:
        pd.DataFrame(partitions[file]).to_csv(out/file,index=False,encoding='utf8')
        hashes[file]=sha_file(out/file);counts[file]=len(partitions[file])
    meta={'dataset':'EdinburghNLP/xsum','base_model':BASE,'seed':seed,
          'protocol':'five-epoch causal-LM summary-completion PEFT; distinct XSum original train nonmembers',
          'raw_official_splits':{k:len(ds[k]) for k in ('train','validation','test')},
          'counts':counts,'file_sha256':hashes,'text_hash':'SHA-256 of whitespace-normalized document',
          'attack_description':'1000/500/1000 members AND nonmembers for train/cal/test; unused original train as nonmembers',
          'task':'one-sentence abstractive summarization'}
    (out/'split_manifest.json').write_text(json.dumps(meta,indent=2)+'\n',encoding='utf8')
    audit(out)


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--stage',choices=['prepare','audit'],default='prepare')
    p.add_argument('--out',default='xsum_qwen15_data')
    p.add_argument('--seed',type=int,default=42)
    p.add_argument('--train-count',type=int,default=10000)
    p.add_argument('--val-count',type=int,default=1000)
    p.add_argument('--test-count',type=int,default=2000)
    p.add_argument('--reference-count',type=int,default=1000)
    a=p.parse_args();out=Path(a.out)
    if a.stage=='audit':audit(out)
    elif out.exists():
        audit(out);print('Existing immutable dataset reused; no resampling performed.')
    else:create(out,a.seed,a.train_count,a.val_count,a.test_count,a.reference_count)
if __name__=='__main__':main()
