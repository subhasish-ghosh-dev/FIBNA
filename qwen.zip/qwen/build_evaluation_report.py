#!/usr/bin/env python3
"""Produce a measured, checkpoint-specific FIBNA AG News + XSum evaluation report.

Uses standard-library Python only. Never invents absent utility or attack metrics.
"""
from __future__ import annotations
import argparse
import csv
import json
import math
from pathlib import Path
from datetime import datetime, timezone

NU=4e-4
KAPPA=NU/10.0 * math.sqrt(2 * math.log(1.25/1e-5))
RUN_NAME='nu_4p000em04'
KEYS = ('ez_mia_full','icp_mia_reference','min_k_pp_full')
LABELS = {'ez_mia_full':'EZ-MIA','icp_mia_reference':'ICP-MIA','min_k_pp_full':'Min-K%++',
          'ez_mia_completion':'EZ-MIA (continuation)',
          'min_k_pp_completion':'Min-K%++ (continuation)'}

def obj(path):
    if not path.is_file():return None
    return json.loads(path.read_text(encoding='utf-8'))

def rows(path):
    if not path.is_file(): return None
    with path.open(newline='',encoding='utf-8-sig') as f:return list(csv.DictReader(f))

def number(n):
    try:
        v=float(n)
        return v if math.isfinite(v) else None
    except (ValueError,TypeError):return None

def fmt(value,places=2,scale=1,suffix=''):
    v=number(value)
    return 'Pending' if v is None else f'{v*scale:.{places}f}{suffix}'

def ci(value,scale=1,places=2):
    if value is None:return ''
    if isinstance(value,str):
        try:value=json.loads(value)
        except Exception:
            import ast
            try:value=ast.literal_eval(value)
            except Exception:return ''
    if not isinstance(value,(tuple,list)) or len(value)!=2:return ''
    lo,hi=number(value[0]),number(value[1])
    if lo is None or hi is None:return ''
    return f' [95% CI {lo*scale:.{places}f}–{hi*scale:.{places}f}]'

def esc(x):return str(x).replace('|','\\|').replace('\n',' ')

def latex_esc(x):
    return str(x).replace('\\','\\textbackslash{}').replace('&','\\&').replace('%','\\%').replace('_','\\_').replace('#','\\#')

def build(root):
    out = root/'fibna_noise_sweep_runs'
    reports = out/'evaluation_report_nu_4p000em04'
    reports.mkdir(parents=True,exist_ok=True)
    document=['# FIBNA highest-noise evaluation — AG News and XSum',
      '',f'- Generated: {datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")}',
      '- Base model: Qwen/Qwen2.5-1.5B',
      f'- Gaussian regularization strength: ν={NU:.4g}; effective κ={KAPPA:.11g}',
      '- These are FIBNA regularization coefficients, **not** differential privacy parameters.',
      '- Runs: five epochs, 10,000 training examples/task, seed 42, 3,125 optimizer updates.',
      '- Inference should load **both** the trained LoRA adapter and the FP32 LM-head delta.',
      '', '## Training and held-out utility', '',
      '| Task | Training | Training time (h) | Peak GPU allocated (GiB) | Held-out utility | Test n |',
      '|---|---|---:|---:|---|---:|']
    meta=[]
    attacks_by_task={}
    for task in ('agnews','xsum'):
        run = out/task/RUN_NAME
        summ = obj(run/'run_summary.json')
        util = obj(run/('test_evaluation' if task=='agnews' else 'utility_test')/'test_metrics.json')
        attack=rows(run/'three_mia'/'attack_results.csv')
        warnings=[]
        if summ:
            if summ.get('is_pilot'):warnings.append('TRAINING IS A PILOT')
            if summ.get('epochs')!=5:warnings.append('Training epochs not equal to five')
            try:
                n = float(summ['noise']['multiplier_nu']) if task=='agnews' else float(summ['requested_configuration']['fibna_noise_nu'])
                if not math.isclose(n,NU,rel_tol=1e-9):warnings.append(f'Noise coefficient mismatch: {n}')
            except Exception:warnings.append('Noise coefficient not found in run_summary.json')
        else:warnings.append('No training summary found')
        train_s='Completed' if summ and not warnings else 'Verify' if summ else 'Missing'
        duration=fmt(summ.get('training_wall_seconds') if summ else None,3,1/3600)
        memory=fmt(summ.get('peak_gpu_allocated_gib') if summ else None,3)
        if util:
            if task=='agnews':
                u=f'Accuracy {fmt(util.get("accuracy"),2,100)}%; macro-F1 {fmt(util.get("macro_f1"),2,100)}%'
                n=util.get('n','—')
            else:
                u=(f'ROUGE-1 {fmt(util.get("rouge1"))}; ROUGE-2 {fmt(util.get("rouge2"))}; '
                   f'ROUGE-L {fmt(util.get("rougeL"))}')
                n=util.get('test_count','—')
                if util.get('is_pilot'):warnings.append('XSum utility is a pilot, not full test')
                if util.get('split')!='test':warnings.append('XSum utility split is not test')
        else:u='Pending';n='—'
        document.append(f'| {"AG News" if task=="agnews" else "XSum"} | {train_s} | {duration} | {memory} | {esc(u)} | {n} |')
        meta.append((task,run,summ,util,attack,warnings))
        attacks_by_task[task]=attack
    document+=['','### Utility details','']
    for task,run,summ,util,attack,warnings in meta:
        document += [f'**{("AG News" if task=="agnews" else "XSum")}**']
        if util is None:document+=['- Held-out test metrics are **not yet available**. Run the `--stage utility` command.']
        elif task=='agnews':
            document += [f'- Test accuracy: {fmt(util.get("accuracy"),2,100)}%{ci(util.get("accuracy_ci95"),100)}',
                         f'- Test macro-F1: {fmt(util.get("macro_f1"),2,100)}%{ci(util.get("macro_f1_ci95"),100)}',
                         f'- Evaluation time (s): {fmt(util.get("wall_seconds"),1)}',
                         f'- Per-class statistics: `{run/"test_evaluation"/"per_class_metrics.csv"}`',
                         f'- Confusion matrix: `{run/"test_evaluation"/"confusion_matrix.csv"}`']
        else:
            document += [f'- ROUGE-1: {fmt(util.get("rouge1"))}{ci(util.get("rouge1_ci95"))}',
                         f'- ROUGE-2: {fmt(util.get("rouge2"))}{ci(util.get("rouge2_ci95"))}',
                         f'- ROUGE-L: {fmt(util.get("rougeL"))}{ci(util.get("rougeL_ci95"))}',
                         f'- Beam search: {util.get("num_beams","unknown")} beams; generated tokens at most {util.get("max_new_tokens","unknown")}',
                         f'- Generated predictions: `{run/"utility_test"/"predictions.csv"}`']
        for warning in warnings:document += [f'- **Verification warning:** {warning}']
        document += ['']
    document += ['## Membership inference attack evaluation','',
      'Attack scores refer to the stated, calibrated score orientation. Near-chance ROC-AUC and even AUC below 0.5 do not by themselves establish privacy protection.',
      'TPR is evaluated at a threshold targeting **1% FPR on calibration data**; the observed held-out FPR is also reported.', '',
      '| Task | Attack | ROC-AUC | TPR@1% FPR (%) | Observed FPR (%) | Coverage (%) |',
      '|---|---|---:|---:|---:|---:|']
    attack_flat=[]
    for task,run,summ,util,attack,warnings in meta:
        bykey={r.get('attack',''):r for r in attack or []}
        for key in KEYS:
            r=bykey.get(key,{})
            attack_flat.append((task,key,r))
            document.append(f'| {"AG News" if task=="agnews" else "XSum"} | {LABELS[key]} | '
                f'{fmt(r.get("roc_auc"),4)}{ci(r.get("roc_auc_ci95"),1,4)} | '
                f'{fmt(r.get("tpr_at_1pct_fpr"),2,100)}{ci(r.get("tpr_ci95"),100)} | '
                f'{fmt(r.get("observed_fpr"),2,100)}{ci(r.get("observed_fpr_ci95"),100)} | '
                f'{fmt(r.get("coverage"),1,100)} |')
    document+=['','### Additional completion-token attacks','',
      'The XSum and AG News MIA reporters may also supply continuation-only variants. The main comparison above uses the three prespecified full-sequence attacks.', '',
      '| Task | Attack | ROC-AUC | TPR@1% FPR (%) | Observed FPR (%) |',
      '|---|---|---:|---:|---:|']
    for task,run,summ,util,attack,warnings in meta:
        bykey={r.get('attack',''):r for r in attack or []}
        for key in ('ez_mia_completion','min_k_pp_completion'):
            r=bykey.get(key)
            if r:
                document.append(f'| {task} | {LABELS[key]} | {fmt(r.get("roc_auc"),4)} | '
                f'{fmt(r.get("tpr_at_1pct_fpr"),2,100)} | {fmt(r.get("observed_fpr"),2,100)} |')
    document+=['','## Experimental completeness and interpretation','']
    for task,run,summ,util,attack,warnings in meta:
        missing=[x for x,p in [('training summary',summ),('held-out utility',util),('MIA summary',attack)] if p is None]
        bykey={r.get('attack',''):r for r in attack or []}
        missing.extend(f'{LABELS[k]} attack' for k in KEYS if k not in bykey)
        document.append(f'- **{task}:** ' + ('Complete files found for training, utility and the three primary attacks.' if not missing else 'Pending: '+', '.join(missing)+'.'))
    document+=['','Only measured results read from the specified run folders are shown. Any missing values are labeled Pending. '
       'Comparisons with LoRA, DP-LoRA, or other noise strengths require separately verified matched checkpoints and evaluations. '
       'FIBNA does not provide a formal differential privacy guarantee.', '',
       '## Source artifacts','',
       f'- Project root: `{root}`',
       '- AG News utility: `fibna_noise_sweep_runs/agnews/nu_4p000em04/test_evaluation/test_metrics.json`',
       '- XSum utility: `fibna_noise_sweep_runs/xsum/nu_4p000em04/utility_test/test_metrics.json`',
       '- Each task attack file: `fibna_noise_sweep_runs/<task>/nu_4p000em04/three_mia/attack_results.csv`','']
    report=reports/'FIBNA_AGNews_XSum_Highest_Noise_Evaluation.md'
    report.write_text('\n'.join(document)+'\n',encoding='utf-8')
    tab=reports/'FIBNA_AGNews_XSum_Highest_Noise_MIA.csv'
    with tab.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['task','attack','roc_auc','tpr_at_1pct_fpr','observed_fpr','coverage','roc_auc_ci95','tpr_ci95','observed_fpr_ci95'])
        w.writeheader()
        for task,k,r in attack_flat:
            w.writerow({'task':task,'attack':LABELS[k], **{name:r.get(name,'') for name in ['roc_auc','tpr_at_1pct_fpr','observed_fpr','coverage','roc_auc_ci95','tpr_ci95','observed_fpr_ci95']}})
    latex=['% Measured results only. Pending = not yet evaluated.','% Percentages for utility and TPR/FPR; ROC-AUC in [0,1].',
          r'\begin{table}[htbp]',r'\centering',r'\small',r'\caption{FIBNA highest-noise membership inference results ($\nu=4\times 10^{-4}$).}',
          r'\label{tab:fibna_highest_noise_mia}',r'\begin{tabular}{llrrrr}',r'\hline',
          r'Dataset & Attack & ROC-AUC & TPR@1\%FPR (\%) & Test FPR (\%) & Coverage (\%) \\',r'\hline']
    for task,k,r in attack_flat:
        latex.append(' & '.join([('AG News' if task=='agnews' else 'XSum'), latex_esc(LABELS[k]),
                          fmt(r.get('roc_auc'),4).replace('Pending','--'),
                          fmt(r.get('tpr_at_1pct_fpr'),2,100).replace('Pending','--'),
                          fmt(r.get('observed_fpr'),2,100).replace('Pending','--'),
                          fmt(r.get('coverage'),1,100).replace('Pending','--')])+r' \\')
    latex += [r'\hline',r'\end{tabular}',r'\end{table}','']
    (reports/'FIBNA_AGNews_XSum_Highest_Noise_MIA_Table.tex').write_text('\n'.join(latex),encoding='utf-8')
    summary={'nu':NU,'kappa':KAPPA,'model':'Qwen/Qwen2.5-1.5B','tasks':{}}
    for task,run,summ,util,attack,warnings in meta:
        summary['tasks'][task]={'checkpoint':str(run),'has_training_summary':bool(summ),
            'has_heldout_utility':bool(util),'has_mia_report':bool(attack),'verified_primary_attacks':
            [k for k in KEYS if k in {r.get('attack') for r in (attack or [])}], 'warnings':warnings}
    (reports/'report_status.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
    print('Report:',report)
    for task,status in summary['tasks'].items():
        print(f'{task}: training={status["has_training_summary"]}, utility={status["has_heldout_utility"]}, '
              f'MIA={status["has_mia_report"]}, attacks={len(status["verified_primary_attacks"])}/3')
    return 0

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--project-root',type=Path,default=Path.cwd())
    a=p.parse_args()
    return build(a.project_root.resolve())

if __name__=='__main__':raise SystemExit(main())
