"""Common token-level MIA scores and calibrated evaluation, adapted from verified AG News runner."""
import numpy as np
import pandas as pd
def token_statistics(logits, ids_shifted, completion_mask, is_target, chunk_size=32, ratio=.2):
    """Official Min-K%++ statistic: (log p_true - E_p log p) / SD_p log p.

    Computed in fp32 chunks, preserving the authors' categorical distribution
    mean/variance rather than approximating it by vocabulary-uniform statistics.
    """
    import torch
    import torch.nn.functional as F
    tgt=ids_shifted
    logpt=[]; errors=[]; zvals=[]
    for low in range(0,len(tgt),chunk_size):
        part=logits[low:low+chunk_size].float()
        tok=tgt[low:low+chunk_size]
        lp=F.log_softmax(part,dim=-1)
        obs=lp.gather(dim=1,index=tok[:,None]).squeeze(1)
        logpt.append(obs.cpu().numpy().astype(np.float32))
        if is_target:
            # Error zone is determined by target argmax, NOT base argmax.
            err=(part.argmax(-1)!=tok)
            errors.append(err.cpu().numpy().astype(np.uint8))
            probs=lp.exp()
            mu=(probs*lp).sum(-1)
            variance=(probs*(lp-mu[:,None]).square()).sum(-1).clamp_min(1e-14)
            z=(obs-mu)/variance.sqrt()
            zvals.append(z.cpu().numpy().astype(np.float32))
        del part,lp
    lps=np.concatenate(logpt)
    if not is_target:return {'logp':lps}
    er=np.concatenate(errors); z=np.concatenate(zvals)
    def lowest(mask):
        selected=z[mask]
        if len(selected)==0:return float('nan')
        kk=max(1,int(len(selected)*ratio))
        return float(np.partition(selected,kk-1)[:kk].mean())
    return {'logp':lps,'errors':er,'min_k_pp_full':lowest(np.ones(len(z),bool)),
            'min_k_pp_completion':lowest(completion_mask),'n_error_full':int(er.sum()),
            'n_error_completion':int(er[completion_mask].sum())}



def ez_score(target_lp,base_lp,errors,span):
    """EZ P/N score: positive versus negative log-probability movement at error tokens.

    Returns NaN when there are no error positions or no negative deltas; no fabricated
    membership score is assigned to an undefined P/N ratio.
    """
    use=np.asarray(errors,dtype=bool)&np.asarray(span,dtype=bool)
    if use.sum()==0:return float('nan')
    delta=np.asarray(target_lp,dtype=float)[use]-np.asarray(base_lp,dtype=float)[use]
    p=float(np.clip(delta,0,None).sum())
    n=float(np.clip(-delta,0,None).sum())
    if n==0:
        # Finite, declared epsilon convention for a zero downward-movement denominator.
        # Without this convention the paper's unsmoothed P/N ratio is unbounded.
        return p / 1e-12
    return p/n


def threshold_at_fpr(neg,rate):
    neg=np.asarray(neg,dtype=float)
    if not np.isfinite(neg).all() or not len(neg):raise RuntimeError('Bad calibration negatives')
    unique=np.sort(np.unique(neg))[::-1]
    threshold=float(np.nextafter(np.max(neg),np.inf));count=0
    for value in unique:
        n=int(np.count_nonzero(neg>=value))
        if n/len(neg)<=rate+1e-15:threshold=float(value);count=n
        else:break
    return threshold,count/len(neg)


def metrics_for_score(data,score,bootstrap=1000,seed=42):
    from sklearn.metrics import roc_auc_score
    data=data.copy();data['attack_score']=pd.to_numeric(score,errors='coerce')
    covered=data.attack_score.notna()&np.isfinite(data.attack_score)
    coverage=float(covered.mean())
    all_n=len(data);covered_data=data.loc[covered].copy()
    # At minimum the heldout test must have both membership classes.
    cal=covered_data[covered_data.attack_split.eq('attack_calibration')]
    tst=covered_data[covered_data.attack_split.eq('attack_test')]
    out={'n_total':all_n,'n_covered':int(covered.sum()),'coverage':coverage,
         'n_cal_nonmembers':int(cal.membership.eq(0).sum()),
         'n_test_members':int(tst.membership.eq(1).sum()),
         'n_test_nonmembers':int(tst.membership.eq(0).sum())}
    if min(out['n_cal_nonmembers'],out['n_test_members'],out['n_test_nonmembers'])<20:
        out['status']='insufficient_coverage'
        for field in ['threshold','calibration_fpr','roc_auc','tpr_at_1pct_fpr','observed_fpr']:
            out[field]=None
        return out
    if coverage<1:
        out['caveat']='Metrics conditional on covered samples. Not directly comparable to full-coverage attacks.'
    threshold,cal_fpr=threshold_at_fpr(cal.loc[cal.membership.eq(0),'attack_score'],.01)
    pred=tst.attack_score.to_numpy()>=threshold
    y=tst.membership.to_numpy(int)
    score_t=tst.attack_score.to_numpy(float)
    out.update({'threshold':threshold,'calibration_fpr':cal_fpr,
                'roc_auc':float(roc_auc_score(y,score_t)),
                'tpr_at_1pct_fpr':float(np.mean(pred[y==1])),
                'observed_fpr':float(np.mean(pred[y==0]))})
    if bootstrap:
        rng=np.random.default_rng(seed)
        groups=[np.flatnonzero(y==0),np.flatnonzero(y==1)]
        draws=[]
        for _ in range(bootstrap):
            ix=np.concatenate([rng.choice(g,len(g),replace=True) for g in groups])
            yy=y[ix];ss=score_t[ix];pp=ss>=threshold
            draws.append([roc_auc_score(yy,ss),np.mean(pp[yy==1]),np.mean(pp[yy==0])])
        q=np.quantile(draws,[.025,.975],axis=0)
        out['roc_auc_ci95']=[float(q[0,0]),float(q[1,0])]
        out['tpr_ci95']=[float(q[0,1]),float(q[1,1])]
        out['observed_fpr_ci95']=[float(q[0,2]),float(q[1,2])]
    return out


