#!/usr/bin/env python3
"""Balanced MeDAL GPT-2-Large MIA re-analysis from completed inference CSVs.

No torch / transformers / new model inference or dataset downloads.

Usage (Windows cmd, inside the project directory):
 python rebalance_medal_gpt2_mia.py --input mia_gpt2_medal_10000_local --output mia_gpt2_medal_10000_balanced_report --bootstrap 300

Requires: pandas numpy scipy scikit-learn matplotlib.
Uses matched sample IDs across LoRA/DP-LoRA/FIBNA and ALL eight attacks,
then balances each calibration/test partition independently by class.
For ROC-AUC and TPR, score direction and all thresholds are fitted using ONLY
calibration data. Paired bootstrap comparisons use the SAME resampled test IDs.
"""
from __future__ import annotations
import argparse
import json
import warnings
from pathlib import Path
import numpy as np
import pandas as pd

ATTACKS={
    "PPL":"score_ppl", "Min-K%":"score_mink", "Min-K%++":"score_minkpp",
    "Neighborhood":"score_neighbor", "EZ-MIA":"score_ez",
    "Reference-ratio":"score_reference", "ZLIB":"score_zlib",
    "Entropy":"score_entropy"
}
MODELS=("LoRA","DP-LoRA","FIBNA")
COLORS={"LoRA":"#2B6CB0","DP-LoRA":"#D97706","FIBNA":"#059669"}
METRICS={
 "f1":("F1-score",None,"f1"),
 "tpr_at_1pct_fpr":("TPR at 1% target FPR",.01,"tpr_at_1pct_fpr"),
 "tpr_at_10pct_fpr":("TPR at 10% target FPR",.10,"tpr_at_10pct_fpr"),
 "roc_auc_calibrated":("Calibrated ROC-AUC",.50,"auc"),
 "precision":("Precision",None,None),
 "recall":("Recall",None,None),
 "test_fpr_at_1pct_target":("Observed test FPR at 1% target",.01,None),
 "test_fpr_at_10pct_target":("Observed test FPR at 10% target",.10,None),
}

def args_parse():
    p=argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--input",type=Path,default=Path("mia_gpt2_medal_10000_local"),help="Existing MIA inference output folder with scores_*.csv")
    p.add_argument("--output",type=Path,default=Path("mia_gpt2_medal_10000_balanced_report"),help="NEW folder, separate from original data")
    p.add_argument("--bootstrap",type=int,default=300,help="Stratified paired bootstrap replicates for test CIs (0 disables)")
    p.add_argument("--seed",type=int,default=42)
    p.add_argument("--scope",choices=["all-attacks","per-attack"],default="all-attacks",
                   help="all-attacks: identical samples for all attacks; per-attack: identical only across models")
    return p.parse_args()

def load_inputs(folder):
    manifest_path=folder/"sample_manifest.csv"
    if manifest_path.exists():
        manifest=pd.read_csv(manifest_path,dtype={"sample_id":str})
        needed={"sample_id","label","split"}
        if not needed.issubset(manifest.columns):
            raise ValueError(f"{manifest_path} missing {sorted(needed-set(manifest.columns))}")
        manifest=manifest[["sample_id","label","split"]].copy()
    else:
        warnings.warn("sample_manifest.csv absent; taking labels/splits from scores_LoRA.csv, cross-checking against other models")
        manifest=None
    models={}
    for name in MODELS:
        path=folder/f"scores_{name}.csv"
        if not path.is_file():
            raise FileNotFoundError(f"Missing {path}; the inference run must finish before reanalysis")
        df=pd.read_csv(path,dtype={"sample_id":str})
        mandatory={"sample_id","label","split",*ATTACKS.values()}
        if not mandatory.issubset(df.columns):
            raise ValueError(f"{path} missing {sorted(mandatory-set(df.columns))}")
        if df.sample_id.isna().any() or df.sample_id.duplicated().any():
            raise ValueError(f"Duplicate or null sample IDs in {path}")
        if manifest is None:
            manifest=df[["sample_id","label","split"]].copy()
        expected=manifest.set_index("sample_id")
        aligned=df.set_index("sample_id")
        common=expected.index.intersection(aligned.index)
        a=expected.loc[common,["label","split"]]
        b=aligned.loc[common,["label","split"]]
        if not a.equals(b):
            raise RuntimeError(f"Member labels or cal/test splits disagree with manifest in {name}")
        models[name]=aligned
    if manifest.sample_id.duplicated().any():
        raise ValueError("Duplicate sample IDs in manifest")
    if not set(manifest["split"].unique()).issubset({"cal","test"}):
        raise ValueError("Expected split values 'cal' and 'test'")
    if not set(manifest["label"].unique()).issubset({0,1}):
        raise ValueError("Expected membership labels 0 and 1")
    return manifest.set_index("sample_id"),models

def candidates_for_attack(manifest,model_frames,attack):
    col=ATTACKS[attack]
    valid=manifest.index
    for model in MODELS:
        df=model_frames[model]
        values=pd.to_numeric(df[col],errors="coerce")
        valid=valid.intersection(values.index[np.isfinite(values)])
        if attack=="Neighborhood" and "n_neighbors" in df:
            neighbor_count=pd.to_numeric(df.n_neighbors,errors="coerce")
            valid=valid.intersection(neighbor_count.index[neighbor_count>=1])
    return set(valid)

def balance_ids(manifest, ids, seed):
    # Crucial: equal classes in BOTH calibration and held-out test partitions.
    frame=manifest.loc[manifest.index.isin(ids)]
    rng=np.random.default_rng(seed)
    chosen=[]
    details=[]
    for split in ("cal","test"):
        candidates={label:frame.index[(frame.split==split)&(frame.label==label)].to_numpy(dtype=str) for label in (0,1)}
        k=min(len(candidates[0]),len(candidates[1]))
        if k<10:
            raise ValueError(f"Too few examples to evaluate split={split}: counts={dict((z,len(candidates[z])) for z in (0,1))}")
        for label in (0,1):
            keep=np.sort(rng.choice(candidates[label],size=k,replace=False))
            chosen.extend(keep.tolist())
            details.append({"split":split,"label":label,"eligible":len(candidates[label]),"selected":k,"excluded_to_balance":len(candidates[label])-k})
    return chosen,details

def f1_threshold(scores,labels):
    from sklearn.metrics import precision_recall_curve
    precision,recall,thresholds=precision_recall_curve(labels,scores)
    if not len(thresholds):return np.inf
    f1=2*precision[:-1]*recall[:-1]/(precision[:-1]+recall[:-1]+1e-12)
    return float(thresholds[np.argmax(f1)])

def fpr_threshold(neg,rate):
    # Reproduce original benchmark. Ties are excluded with > threshold.
    try:return float(np.quantile(neg,1-rate,method="higher"))
    except TypeError:return float(np.quantile(neg,1-rate,interpolation="higher"))

def assess_ids(frame, labels, split, model,attack,bootstrap,rng):
    from sklearn.metrics import roc_auc_score,f1_score,precision_score,recall_score,confusion_matrix
    cal=split=="cal"; test=split=="test"
    yc=labels[cal]; yt=labels[test]
    raw_c=frame[cal];raw_t=frame[test]
    direction=1 if roc_auc_score(yc,raw_c)>=.5 else -1
    sc=direction*raw_c;st=direction*raw_t
    thresh_f1=f1_threshold(sc,yc)
    thresh_1=fpr_threshold(sc[yc==0],.01)
    thresh_10=fpr_threshold(sc[yc==0],.10)
    pred=(st>=thresh_f1).astype(int)
    tn,fp,fn,tp=confusion_matrix(yt,pred,labels=[0,1]).ravel()
    row={"model":model,"attack":attack,
         "n_cal_members":int(sum(yc==1)),"n_cal_nonmembers":int(sum(yc==0)),
         "n_test_members":int(sum(yt==1)),"n_test_nonmembers":int(sum(yt==0)),
         "direction_from_calibration":direction,"calibration_raw_auc":float(roc_auc_score(yc,raw_c)),
         "f1":float(f1_score(yt,pred,zero_division=0)),"precision":float(precision_score(yt,pred,zero_division=0)),
         "recall":float(recall_score(yt,pred,zero_division=0)),"roc_auc_calibrated":float(roc_auc_score(yt,st)),
         "tpr_at_1pct_fpr":float(np.mean(st[yt==1]>thresh_1)),
         "test_fpr_at_1pct_target":float(np.mean(st[yt==0]>thresh_1)),
         "tpr_at_10pct_fpr":float(np.mean(st[yt==1]>thresh_10)),
         "test_fpr_at_10pct_target":float(np.mean(st[yt==0]>thresh_10)),
         "f1_threshold_calibrated":thresh_f1,"threshold_1pct_calibrated":thresh_1,"threshold_10pct_calibrated":thresh_10,
         "tp":int(tp),"tn":int(tn),"fp":int(fp),"fn":int(fn),
         "all_member_f1_baseline":float(2*sum(yt==1)/(2*sum(yt==1)+sum(yt==0))),
         "status":"computed_balanced",}
    if bootstrap>0:
        group_pos=np.flatnonzero(yt==1);group_neg=np.flatnonzero(yt==0)
        arr=np.zeros((bootstrap,4))
        for b in range(bootstrap):
            idx=np.r_[rng.choice(group_pos,len(group_pos),replace=True),rng.choice(group_neg,len(group_neg),replace=True)]
            y=yt[idx];s=st[idx]
            arr[b]=[roc_auc_score(y,s),f1_score(y,s>=thresh_f1,zero_division=0),np.mean(s[y==1]>thresh_1),np.mean(s[y==1]>thresh_10)]
        for col,pos in [("auc",0),("f1",1),("tpr_at_1pct_fpr",2),("tpr_at_10pct_fpr",3)]:
            row[f"{col}_ci95_low"],row[f"{col}_ci95_high"]=np.quantile(arr[:,pos],[.025,.975])
    return row,{"score":st,"label":yt,"direction":direction,"thresholds":(thresh_1,thresh_10)}

def paired_ci(res, bootstrap, seed):
    from sklearn.metrics import roc_auc_score
    # res maps method -> oriented scores on SAME ordered held-out examples, labels identical.
    a=res["LoRA"]; f=res["FIBNA"];d=res["DP-LoRA"]
    yy=a["label"]
    rng=np.random.default_rng(seed)
    pos=np.flatnonzero(yy==1);neg=np.flatnonzero(yy==0)
    pairs=[("LoRA","FIBNA"),("DP-LoRA","FIBNA"),("LoRA","DP-LoRA")]
    metrics=("roc_auc_calibrated","tpr_at_1pct_fpr","tpr_at_10pct_fpr")
    out=[]
    for left,right in pairs:
        l=res[left];r=res[right];
        def measures(z,inds):
            s=z["score"][inds];y=yy[inds]
            return (float(roc_auc_score(y,s)),float(np.mean(s[y==1]>z["thresholds"][0])),float(np.mean(s[y==1]>z["thresholds"][1])))
        idx=np.arange(len(yy));p=np.asarray(measures(l,idx))-np.asarray(measures(r,idx))
        draws=np.empty((bootstrap,3),dtype=float)
        for i in range(bootstrap):
            idx=np.r_[rng.choice(pos,len(pos),replace=True),rng.choice(neg,len(neg),replace=True)]
            draws[i]=np.asarray(measures(l,idx))-np.asarray(measures(r,idx))
        for j,metric in enumerate(metrics):
            lo,hi=np.quantile(draws[:,j],[.025,.975])
            out.append({"comparison":f"{left} - {right}","metric":metric,"mean_difference":p[j],
                        "ci95_low":lo,"ci95_high":hi,"bootstrap_replicates":bootstrap})
    return out

def make_plots(summary,out):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    root=out/"comparison_graphs";root.mkdir(exist_ok=True,parents=True)
    xs=np.arange(len(ATTACKS)); w=.25
    for metric,(label,baseline,ci) in METRICS.items():
        fig,ax=plt.subplots(figsize=(13,5.9))
        for j,model in enumerate(MODELS):
            z=summary[summary.model==model].set_index("attack").reindex(ATTACKS)
            values=z[metric].to_numpy(dtype=float)
            yerr=None
            if ci is not None and f"{ci}_ci95_low" in z and f"{ci}_ci95_high" in z:
                # auc CI output in original uses auc_, all others use full names
                low=z[f"{ci}_ci95_low"].to_numpy(dtype=float); high=z[f"{ci}_ci95_high"].to_numpy(dtype=float)
                if np.isfinite(low).all() and np.isfinite(high).all():
                    yerr=np.array([np.maximum(values-low,0),np.maximum(high-values,0)])
            ax.bar(xs+(j-1)*w,values,w,label=model,color=COLORS[model],edgecolor="white",linewidth=.5,yerr=yerr,capsize=2 if yerr is not None else 0,zorder=2)
        if baseline is not None:
            ax.axhline(baseline,color="slategray",ls="--",lw=1.3,label=f"Reference = {baseline:g}")
        elif metric=="f1":
            ax.axhline(2/3,color="slategray",ls="--",lw=1.2,label="All-member baseline F1 = 2/3")
        ax.set_xticks(xs);ax.set_xticklabels(ATTACKS.keys(),rotation=28,ha="right")
        ax.set_ylabel(label);ax.set_title(f"MeDAL | GPT-2-Large | balanced membership inference evaluation\n{label}",fontweight="bold")
        ax.grid(axis="y",linestyle=":",alpha=.25);ax.set_axisbelow(True)
        ax.legend(loc="upper left",ncol=4,fontsize=9);fig.tight_layout()
        basename=root/f"medal_balanced_{metric}"
        fig.savefig(str(basename)+".png",dpi=300,bbox_inches="tight")
        fig.savefig(str(basename)+".pdf",bbox_inches="tight")
        fig.savefig(str(basename)+".svg",bbox_inches="tight")
        plt.close(fig)
    fig,ax=plt.subplots(figsize=(13,5.7))
    for j,model in enumerate(MODELS):
        z=summary[summary.model==model].set_index("attack").reindex(ATTACKS)
        values=z.roc_auc_calibrated.to_numpy(float)
        lows=z.auc_ci95_low.to_numpy(float);highs=z.auc_ci95_high.to_numpy(float)
        ax.errorbar(xs+(j-1)*.15,values,yerr=[np.maximum(values-lows,0),np.maximum(highs-values,0)],
                    fmt="o",capsize=3,lw=1.4,color=COLORS[model],label=model)
    ax.axhline(.5,ls="--",color="slategray",lw=1.3,label="Chance AUC = 0.5")
    ax.set_xticks(xs);ax.set_xticklabels(ATTACKS.keys(),rotation=28,ha="right")
    ax.set_ylabel("Calibrated ROC-AUC");ax.set_title("MeDAL | GPT-2-Large | balanced ROC-AUC (95% bootstrap intervals)")
    ax.grid(axis="y",ls=":",alpha=.2);ax.legend(ncol=4);fig.tight_layout()
    for suffix in ("png","pdf","svg"):
        fig.savefig(root/f"medal_balanced_roc_auc_detail.{suffix}",dpi=300,bbox_inches="tight")
    plt.close(fig)
    print("Figures saved to",root.resolve())

def main():
    args=args_parse()
    if args.bootstrap<0:raise ValueError("--bootstrap must be nonnegative")
    out=args.output.expanduser().resolve();inp=args.input.expanduser().resolve()
    if out==inp:raise ValueError("--output must differ from --input (don't overwrite original MIA scores)")
    out.mkdir(exist_ok=True,parents=True)
    manifest,frames=load_inputs(inp)
    print("Original manifest cal/test by class:\n",manifest.groupby(["split","label"]).size().to_string())
    candidates={attack:candidates_for_attack(manifest,frames,attack) for attack in ATTACKS}
    inter=set(manifest.index)
    for ids in candidates.values():inter &= ids
    print("Common valid across all eight attacks and three models:",len(inter),"/",len(manifest))
    rng=np.random.default_rng(args.seed)
    all_rows=[];coverage=[];selected=[];paired=[];groups={}
    for j,(attack,col) in enumerate(ATTACKS.items()):
        valid=inter if args.scope=="all-attacks" else candidates[attack]
        chosen,audit=balance_ids(manifest,valid,args.seed+j*997 if args.scope=="per-attack" else args.seed)
        for rec in audit:coverage.append({"attack":attack,"n_valid_before_balance":len(valid),**rec})
        for sample in chosen:
            rec=manifest.loc[sample]
            selected.append({"attack":attack,"sample_id":sample,"label":int(rec.label),"split":rec.split})
        ordered=manifest.loc[chosen]
        y=ordered.label.to_numpy(int);split=ordered.split.to_numpy(str)
        models_res={}
        for k,model in enumerate(MODELS):
            frame=frames[model]
            s=pd.to_numeric(frame.loc[chosen,col],errors="raise").to_numpy(float)
            a,meta=assess_ids(s,y,split,model,attack,args.bootstrap,np.random.default_rng(args.seed+100*j+k))
            all_rows.append(a);models_res[model]=meta
        if args.bootstrap>0:
            for rec in paired_ci(models_res,args.bootstrap,args.seed+j*131):
                paired.append({"attack":attack,**rec})
    summary=pd.DataFrame(all_rows)
    summary.to_csv(out/"mia_summary_balanced.csv",index=False)
    pd.DataFrame(coverage).to_csv(out/"balance_audit.csv",index=False)
    pd.DataFrame(selected).to_csv(out/"balanced_sample_manifest.csv",index=False)
    if paired:pd.DataFrame(paired).to_csv(out/"paired_bootstrap_differences.csv",index=False)
    cols=["attack","model","n_cal_members","n_cal_nonmembers","n_test_members","n_test_nonmembers","f1","tpr_at_1pct_fpr","tpr_at_10pct_fpr","roc_auc_calibrated","test_fpr_at_1pct_target","test_fpr_at_10pct_target"]
    summary[cols].to_csv(out/"table_for_manuscript_balanced.csv",index=False)
    for metric in METRICS:
        summary.pivot(index="attack",columns="model",values=metric).reindex(index=ATTACKS.keys(),columns=MODELS).to_csv(out/f"metric_{metric}.csv")
    print("\nBalanced counts after intersection and selection:")
    print(pd.DataFrame(selected).groupby(["attack","split","label"]).size().to_string())
    print("\nSummary:")
    print(summary[["model","attack","roc_auc_calibrated","tpr_at_1pct_fpr","tpr_at_10pct_fpr","f1"]].to_string(index=False,float_format=lambda v:f"{v:.5f}"))
    if args.bootstrap>0: make_plots(summary,out)
    else: print("Pass --bootstrap 300 (or higher) to enable CI plots")
    (out/"run_metadata.json").write_text(json.dumps({"input":str(inp),"output":str(out),"seed":args.seed,"scope":args.scope,"bootstrap":args.bootstrap,"calibrated_on":"cal only","test_used_for_threshold":False,"note":"Scores reused from prior model inference; no model retraining/inference"},indent=2),encoding="utf-8")
    print("All CSV results saved to",out)

if __name__=="__main__":main()
