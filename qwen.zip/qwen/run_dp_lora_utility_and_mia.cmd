@echo off
setlocal
REM Run from the demia_multitask directory after: conda activate gpu_env
REM Uses existing frozen 5-epoch DP-LoRA checkpoint. No training performed.
if not exist "agnews_dp_lora_qwen15_5ep\adapter\adapter_config.json" (
    echo ERROR: Missing DP-LoRA checkpoint adapter_config.json. Train the 5-epoch DP-LoRA target first.
    exit /b 2
)
if not exist "agnews_dp_lora_qwen15_5ep\overhead_summary.json" (
    echo ERROR: Missing DP-LoRA overhead_summary.json.
    exit /b 2
)
python evaluate_agnews_qwen_dplora_test.py --stage audit || goto fail
python evaluate_agnews_qwen_dplora_test.py --stage evaluate --bootstrap 1000 || goto fail
python test_dp_attack_math.py || goto fail
python run_three_mia_agnews_dplora.py --stage audit || goto fail
python run_three_mia_agnews_dplora.py --stage score-target || goto fail
python run_three_mia_agnews_dplora.py --stage score-base || goto fail
python run_three_mia_agnews_dplora.py --stage score-icp || goto fail
python run_three_mia_agnews_dplora.py --stage report --bootstrap 1000 || goto fail
python report_dp_lora_results.py || goto fail
echo PASS: DP-LoRA held-out classification and all three MIA attack reports created.
exit /b 0
:fail
echo ERROR: A step failed. Review traceback and rerun the failed stage. Scoring resumes when provenance matches.
exit /b 1
