#!/usr/bin/env python3
"""Build immutable, disjoint AG News member/nonmember manifests for Qwen PEFT + DeMIA.

The resulting target members, attack candidates and held-out utility samples are
identical across LoRA, DP-LoRA and FIBNA.  This is an original controlled study,
not a reconstruction of DeMIA authors' AGNews10k split.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import sys
import unicodedata
from pathlib import Path

import numpy as np
import pandas as pd

LABELS = {0: "World", 1: "Sports", 2: "Business", 3: "Sci/Tech"}
INSTRUCTION = (
    "Classify the following news article into exactly one of these categories: "
    "World, Sports, Business, Sci/Tech.\n\nArticle:\n"
)


def text_key(s: str) -> str:
    s = unicodedata.normalize("NFKC", str(s))
    s = " ".join(s.split()).casefold()
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def as_frame(records, where: str) -> pd.DataFrame:
    df = pd.DataFrame(records)
    if not {"text", "label"}.issubset(df.columns):
        raise ValueError(f"{where} must have text and label columns; found {list(df)}")
    df = df[["text", "label"]].copy()
    df["text"] = df["text"].fillna("").astype(str)
    if df["text"].str.strip().eq("").any():
        raise ValueError(f"{where} contains empty text")
    try:
        df["label_id"] = pd.to_numeric(df["label"], errors="raise").astype(int)
    except Exception as e:
        raise ValueError(f"{where}: labels must be integers 0,1,2,3") from e
    if not df["label_id"].isin(LABELS).all():
        raise ValueError(f"{where}: labels must be 0,1,2,3")
    df["text_hash"] = df["text"].map(text_key)
    collisions = df.groupby("text_hash")["label_id"].nunique()
    n_conflict = int((collisions > 1).sum())
    # Duplicate texts, even when conflicting labels, must not cross membership splits.
    # Keep deterministic first occurrence, record the count for research transparency.
    df = df.drop_duplicates("text_hash", keep="first").reset_index(drop=True)
    df["sample_id"] = df["text_hash"].map(lambda x: "ag_" + x[:24])
    if df.sample_id.duplicated().any():
        raise RuntimeError("Sample-id hash prefix collision; increase prefix length")
    df["label_name"] = df.label_id.map(LABELS)
    df["prompt"] = df.text.map(lambda t: INSTRUCTION + t + "\n\nCategory:")
    df["completion"] = " " + df["label_name"]
    df["training_text"] = df.prompt + df.completion
    return df.drop(columns=["label"]), n_conflict


def take_balanced(df: pd.DataFrame, n: int, rng: np.random.Generator, title: str):
    if n % len(LABELS):
        raise ValueError(f"{title} count {n} must be divisible by {len(LABELS)}")
    index = []
    for label in LABELS:
        ids = np.flatnonzero(df.label_id.to_numpy() == label)
        required = n // len(LABELS)
        if len(ids) < required:
            raise RuntimeError(f"{title}: label {label} only has {len(ids)}; need {required}")
        index.extend(rng.choice(ids, size=required, replace=False).tolist())
    selected = df.iloc[index].copy()
    selected = selected.iloc[rng.permutation(len(selected))].reset_index(drop=True)
    rest = df.drop(index=df.index[index]).reset_index(drop=True)
    assert len(selected) == n and selected.text_hash.is_unique
    return selected, rest


def write_csv(data: pd.DataFrame, path: Path):
    data.to_csv(path, index=False, encoding="utf-8")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--out", default="agnews_demia_qwen15")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--dataset", default="fancyzhx/ag_news")
    ap.add_argument("--train-csv", help="Optional local CSV with text,label for an offline/custom test")
    ap.add_argument("--test-csv", help="Optional local CSV with text,label for an offline/custom test")
    ap.add_argument("--target-size", type=int, default=10000)
    ap.add_argument("--val-size", type=int, default=1000)
    ap.add_argument("--utility-test-size", type=int, default=2000)
    ap.add_argument("--attack-train-per-class", type=int, default=250,
                    help="Members AND nonmembers per class for supervised attack training")
    ap.add_argument("--attack-cal-per-class", type=int, default=125)
    ap.add_argument("--attack-test-per-class", type=int, default=250)
    a = ap.parse_args()
    if bool(a.train_csv) != bool(a.test_csv):
        ap.error("--train-csv and --test-csv must be given together")
    if min(a.target_size, a.val_size, a.utility_test_size) <= 0:
        ap.error("Dataset sizes must be positive")
    if min(a.attack_train_per_class, a.attack_cal_per_class, a.attack_test_per_class) <= 0:
        ap.error("Attack split per-class sizes must be positive")
    out = Path(a.out)
    if out.exists() and any(out.iterdir()):
        raise FileExistsError(f"Refusing to overwrite existing experiment directory: {out}")
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(a.seed)
    if a.train_csv:
        raw_train = pd.read_csv(a.train_csv, keep_default_na=False)
        raw_test = pd.read_csv(a.test_csv, keep_default_na=False)
        source = {"kind": "local_csv", "train": str(Path(a.train_csv).resolve()),
                  "test": str(Path(a.test_csv).resolve())}
    else:
        from datasets import load_dataset
        ds = load_dataset(a.dataset)
        raw_train = ds["train"].to_pandas()
        raw_test = ds["test"].to_pandas()
        source = {"kind": "huggingface_dataset", "dataset": a.dataset,
                  "train_fingerprint": getattr(ds["train"], "_fingerprint", None),
                  "test_fingerprint": getattr(ds["test"], "_fingerprint", None)}
    train, tr_conflicts = as_frame(raw_train, "train")
    test, te_conflicts = as_frame(raw_test, "test")
    overlap = set(train.text_hash) & set(test.text_hash)
    if overlap:
        test = test.loc[~test.text_hash.isin(overlap)].reset_index(drop=True)
    target, available = take_balanced(train, a.target_size, rng, "target train")
    requested = {
        "attack_train": a.attack_train_per_class * len(LABELS),
        "attack_calibration": a.attack_cal_per_class * len(LABELS),
        "attack_test": a.attack_test_per_class * len(LABELS),
    }
    member_pool = target.copy()
    nonmember_pool = available.copy()
    attacks = []
    for part, n_per_role in requested.items():
        members, member_pool = take_balanced(member_pool, n_per_role, rng, f"{part} members")
        nonmembers, nonmember_pool = take_balanced(nonmember_pool, n_per_role, rng, f"{part} nonmembers")
        members["membership"] = 1
        nonmembers["membership"] = 0
        joined = pd.concat([members, nonmembers], ignore_index=True)
        joined["attack_split"] = part
        joined = joined.iloc[rng.permutation(len(joined))].reset_index(drop=True)
        write_csv(joined, out / f"{part}.csv")
        attacks.append(joined)
    val, nonmember_pool = take_balanced(nonmember_pool, a.val_size, rng, "utility validation")
    utility_test, _ = take_balanced(test, a.utility_test_size, rng, "utility test")
    attack_all = pd.concat(attacks, ignore_index=True)
    target_set, val_set, util_set = set(target.text_hash), set(val.text_hash), set(utility_test.text_hash)
    attack_set = set(attack_all.text_hash)
    assert attack_all.text_hash.is_unique, "Candidate reuse across attack partitions"
    assert not val_set.intersection(target_set | attack_set)
    assert not util_set.intersection(target_set | attack_set | val_set)
    members = attack_all.loc[attack_all.membership == 1]
    nonmembers = attack_all.loc[attack_all.membership == 0]
    assert set(members.text_hash) <= target_set
    assert not set(nonmembers.text_hash).intersection(target_set)
    assert len(attack_all) == sum(requested.values()) * 2
    write_csv(target, out / "target_train.csv")
    write_csv(val, out / "utility_val.csv")
    write_csv(utility_test, out / "utility_test.csv")
    write_csv(attack_all, out / "attack_all.csv")
    config = {
        "purpose": "Original controlled LoRA/DP-LoRA/FIBNA vs DeMIA task-classification study",
        "not_exact_DeMIA_paper_AGNews10k_split": True,
        "seed": a.seed, "source": source,
        "base_model": "Qwen/Qwen2.5-1.5B",
        "labels": LABELS,
        "format": {"prompt_prefix": INSTRUCTION, "completion": " leading-space label_name", "eos": "handled by trainer"},
        "training_members": len(target),
        "utility_validation": len(val), "utility_test": len(utility_test),
        "attack_counts": {p: {"members": n, "nonmembers": n} for p, n in requested.items()},
        "distinct_train_texts": len(train), "distinct_test_texts_after_overlap_filter": len(test),
        "duplicate_conflicting_labels_within_train": tr_conflicts,
        "duplicate_conflicting_labels_within_test": te_conflicts,
        "train_test_hash_overlap_excluded_from_test": len(overlap),
        "hash_normalization": "Unicode NFKC, collapse whitespace, casefold, SHA256",
        "notes": [
            "All target methods must train on exactly target_train.csv with identical selected records.",
            "Text-level membership: repeat normalized texts never cross IN and OUT groups.",
            "The DeMIA feature extractor/scoring protocol must be matched to the training_text representation.",
            "Calibration examples are disjoint from attack training and final test examples.",
            "Attack train/cal/test include members drawn from target training and nonmembers from unused official train.",
            "No MIA result can be claimed until real target scoring and held-out DeMIA training/testing."
        ]
    }
    (out / "split_manifest.json").write_text(json.dumps(config, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    for fn in ["target_train.csv", "utility_val.csv", "utility_test.csv", "attack_train.csv",
               "attack_calibration.csv", "attack_test.csv", "attack_all.csv"]:
        digest = hashlib.sha256((out / fn).read_bytes()).hexdigest()
        config.setdefault("file_sha256", {})[fn] = digest
    (out / "split_manifest.json").write_text(json.dumps(config, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print("PASS: AG News membership/utility split created; no cross-partition normalized-text overlaps")
    print(f"  Target training: {len(target):,} | Utility validation: {len(val):,} | Utility test: {len(utility_test):,}")
    for partition, n in requested.items():
        print(f"  {partition}: {n} members + {n} nonmembers = {2*n}")
    print(f"  Original train/test duplicate conflicts (unique texts): {tr_conflicts} / {te_conflicts}")
    print(f"  Files saved to: {out.resolve()}")


if __name__ == "__main__":
    main()
