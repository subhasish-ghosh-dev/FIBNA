#!/usr/bin/env python
"""XSum membership evaluation: EZ-MIA, Min-K%++, and similarity-reference ICP-MIA variant.

NOTE: Published attack equations are adapted to summary-only supervised tuning.
This is NOT an unmodified execution of authors' code. In addition to full-sequence
scores, completion-only sensitivity scores are reported, using a frozen attack set.
"""
from __future__ import annotations
import argparse,csv,hashlib,json,time,shutil
from pathlib import Path
import numpy as np
import pandas as pd
from xsum_common import BASE,XSumCodec,audit,get_base,load_target,sha_file,tokenizer_model
from mia_math import token_statistics,ez_score,metrics_for_score


def fingerprint(run,method):
    from eval_xsum import fingerprint as fp
    return fp(run,method)


def provenance(path,record):
    if path.exists():
        if json.loads(path.read_text(encoding='utf8'))!=record:
            raise RuntimeError('Cached scores generated with different checkpoint/protocol: '+str(path))
    else:
        path.parent.mkdir(exist_ok=True,parents=True)
        path.write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')


def start_csv(path,fields):
    if path.is_file():
        with path.open('r',encoding='utf8',newline='') as f:
            header=next(csv.reader(f),None)
        if header!=fields:raise RuntimeError('Wrong cache columns: '+str(path))
        df=pd.read_csv(path,keep_default_na=False,dtype={'sample_id':str})
        if df.sample_id.duplicated().any():raise RuntimeError('Duplicate cached sample IDs')
        return set(df.sample_id)
    with path.open('w',encoding='utf8',newline='') as f:csv.writer(f).writerow(fields)
    return set()


def data_all(root):
    _,tbl=audit(root)
    data=tbl['attack_all.csv'].copy()
    data['sample_id']=data.sample_id.astype(str)
    data['membership']=data.membership.astype(int)
    if len(data)!=5000 or data.sample_id.duplicated().any():raise RuntimeError('Expected frozen 5000 attack candidates')
    return data,tbl


def load_for_scoring(a,which):
    import torch
    if not torch.cuda.is_available():raise RuntimeError('CUDA required')
    tok=tokenizer_model(BASE)
    if which=='target':
        model,meta=load_target(a.method,a.checkpoint,BASE,a.dtype)
    else:
        model=get_base(BASE,{'bf16':torch.bfloat16,'fp16':torch.float16,'fp32':torch.float32}[a.dtype])
        model.to('cuda:0').eval();model.config.use_cache=False
    return model,tok,torch


def score_tokens(a,data,which):
    run=Path(a.checkpoint);out=Path(a.out);out.mkdir(exist_ok=True,parents=True)
    fingerprint_meta=fingerprint(run,a.method) if which=='target' else 'pretrained Qwen base'
    provenance(out/(which+'_tokens.provenance.json'),{
        'stage':which,'model':BASE,'method':a.method,'checkpoint':fingerprint_meta,
        'manifest_sha256':sha_file(Path(a.data)/'split_manifest.json'),
        'max_length':a.max_length,'max_target_tokens':a.max_target_tokens,'dtype':a.dtype,
        'ratio':a.min_k_ratio,'version':'xsum-summary-completion-v1'})
    fields=['sample_id','attack_split','membership','ids_sha256','n_tokens','logp_json']
    if which=='target':fields.extend(['n_completion_tokens','error_json','min_k_pp_full',
                                  'min_k_pp_completion','n_error_full','n_error_completion'])
    csvfile=out/(which+'_tokens.csv')
    # Reuse the exact same pretrained-base likelihoods for all three methods;
    # this saves two redundant 5,000-example base-model scoring passes.
    if which=='base' and a.method!='lora' and not csvfile.exists():
        source=Path('xsum_lora_qwen15_5ep/three_mia/base_tokens.csv')
        source_meta=source.parent/'base_tokens.provenance.json'
        if source.is_file() and source_meta.is_file():
            src=json.loads(source_meta.read_text(encoding='utf8'))
            if (src.get('manifest_sha256')==sha_file(Path(a.data)/'split_manifest.json')
                and src.get('max_length')==a.max_length
                and src.get('max_target_tokens')==a.max_target_tokens
                and src.get('dtype')==a.dtype and src.get('ratio')==a.min_k_ratio):
                existing=pd.read_csv(source,dtype={'sample_id':str})
                if len(existing)==len(data) and set(existing.sample_id)==set(data.sample_id) and not existing.sample_id.duplicated().any():
                    if list(existing.columns)==fields:
                        shutil.copyfile(source,csvfile)
                        print('Reused verified pretrained Qwen base scores from LoRA run:',source,flush=True)
    finished=start_csv(csvfile,fields)
    if not finished.issubset(set(data.sample_id)):raise RuntimeError('Foreign scored IDs')
    todo=data.loc[~data.sample_id.isin(finished)]
    if a.limit:todo=todo.iloc[:a.limit]
    print(which,len(todo),'remaining /',len(data),flush=True)
    if todo.empty:return
    model,tok,torch=load_for_scoring(a,which);codec=XSumCodec(tok,a.max_length,a.max_target_tokens)
    with csvfile.open('a',encoding='utf8',newline='') as f:
        writer=csv.DictWriter(f,fields)
        for i,row in enumerate(todo.itertuples(index=False),1):
            example=codec.example(row.document,row.summary)
            ids=example['input_ids'];targets=example['labels']
            cmask=np.asarray(targets[1:],dtype=np.int64)!=-100
            x=torch.tensor([ids],dtype=torch.long,device='cuda:0')
            with torch.inference_mode():
                logits=model(input_ids=x,attention_mask=torch.ones_like(x),use_cache=False).logits[0,:-1,:]
                stat=token_statistics(logits,x[0,1:],cmask,which=='target',chunk_size=a.vocab_chunk,ratio=a.min_k_ratio)
            rec={'sample_id':row.sample_id,'attack_split':row.attack_split,'membership':int(row.membership),
                 'ids_sha256':hashlib.sha256(np.asarray(ids,dtype=np.int32).tobytes()).hexdigest(),
                 'n_tokens':len(ids)-1,'logp_json':json.dumps(stat['logp'].tolist(),separators=(',',':'))}
            if which=='target':
                rec.update({'n_completion_tokens':int(cmask.sum()),
                            'error_json':json.dumps(stat['errors'].astype(int).tolist(),separators=(',',':')),
                            'min_k_pp_full':stat['min_k_pp_full'],
                            'min_k_pp_completion':stat['min_k_pp_completion'],
                            'n_error_full':stat['n_error_full'],'n_error_completion':stat['n_error_completion']})
            writer.writerow(rec)
            if i%25==0:
                f.flush();print(f'{which}: {i}/{len(todo)}',flush=True)
        f.flush()
    print('Wrote',csvfile)


def retrieve(a,data,pool):
    out=Path(a.out);path=out/'icp_retrieval.csv'
    provenance(out/'icp_retrieval.provenance.json',{
        'manifest_sha256':sha_file(Path(a.data)/'split_manifest.json'),
        'pool_sha256':sha_file(Path(a.data)/'reference_pool.csv'),
        'encoder':a.icp_encoder,'candidates':a.icp_candidates,
        'query':'first 512 chars of source document'})
    if path.is_file():
        cache=pd.read_csv(path,keep_default_na=False,dtype={'sample_id':str})
        if set(cache.sample_id)!=set(data.sample_id):raise RuntimeError('Incomplete ICP retrieval cache')
        return {r.sample_id:json.loads(r.indices_json) for r in cache.itertuples(index=False)}
    from sentence_transformers import SentenceTransformer
    encoder=SentenceTransformer(a.icp_encoder,device='cpu')
    docs=pool.document.astype(str).str.slice(0,512).tolist()
    queries=data.document.astype(str).str.slice(0,512).tolist()
    ep=np.asarray(encoder.encode(docs,batch_size=32,normalize_embeddings=True,show_progress_bar=True),dtype=np.float32)
    eq=np.asarray(encoder.encode(queries,batch_size=32,normalize_embeddings=True,show_progress_bar=True),dtype=np.float32)
    dots=eq@ep.T
    outrows=[]
    for ix,row in enumerate(data.itertuples(index=False)):
        picks=[]
        for j in np.argsort(-dots[ix]):
            j=int(j)
            if pool.iloc[j].text_hash==row.text_hash:continue
            picks.append(j)
            if len(picks)==a.icp_candidates:break
        if len(picks)!=a.icp_candidates:raise RuntimeError('Not enough ICP reference candidates')
        outrows.append({'sample_id':row.sample_id,'indices_json':json.dumps(picks)})
    pd.DataFrame(outrows).to_csv(path,index=False)
    return {r['sample_id']:json.loads(r['indices_json']) for r in outrows}


def completion_ll(model,codec,document,summary,prefix,context_budget,torch):
    ex=codec.example(document,summary);x0=ex['input_ids'];nlabels=sum(int(q!=-100) for q in ex['labels'])
    prefix=prefix or []
    seq=prefix+x0
    if len(seq)>context_budget:return None
    xx=torch.tensor([seq],dtype=torch.long,device='cuda:0')
    with torch.inference_mode():
        logits=model(input_ids=xx,attention_mask=torch.ones_like(xx),use_cache=False).logits[0]
        start=len(seq)-nlabels
        pos=torch.arange(start-1,len(seq)-1,device=xx.device)
        sel=logits[pos].float().log_softmax(-1).gather(1,xx[0,pos+1,None]).squeeze(1)
        return float(sel.mean().item())


def score_icp(a,data,pool):
    out=Path(a.out);out.mkdir(exist_ok=True,parents=True)
    provenance(out/'icp.provenance.json',{
        'method':'similarity-based reference-data ICP, adapted for XSum summary completion',
        'manifest_sha256':sha_file(Path(a.data)/'split_manifest.json'),
        'pool_sha256':sha_file(Path(a.data)/'reference_pool.csv'),
        'checkpoint':fingerprint(a.checkpoint,a.method),'dtype':a.dtype,
        'max_length':a.max_length,'max_target_tokens':a.max_target_tokens,
        'icp_max_length':a.icp_max_length,'encoder':a.icp_encoder,
        'candidates':a.icp_candidates,'aggregation':'best likelihood of reference demonstrations'})
    fields=['sample_id','attack_split','membership','icp_score','plain_ll','best_demo_ll','selected_pool_row']
    csvfile=out/'icp_scores.csv';finished=start_csv(csvfile,fields)
    if not finished.issubset(set(data.sample_id)):raise RuntimeError('Foreign cached ICP IDs')
    pending=data.loc[~data.sample_id.isin(finished)]
    if a.limit:pending=pending.iloc[:a.limit]
    if pending.empty:return
    if set(pool.text_hash)&set(data.text_hash):raise RuntimeError('ICP reference corpus contains attack candidates')
    indices=retrieve(a,data,pool)
    model,tok,torch=load_for_scoring(a,'target');codec=XSumCodec(tok,a.max_length,a.max_target_tokens)
    with csvfile.open('a',encoding='utf8',newline='') as f:
        writer=csv.DictWriter(f,fields)
        for i,row in enumerate(pending.itertuples(index=False),1):
            plain=completion_ll(model,codec,row.document,row.summary,None,a.icp_max_length,torch)
            if plain is None:raise RuntimeError('ICP query exceeds context budget')
            candidates=[]
            for j in indices[str(row.sample_id)]:
                demo=pool.iloc[int(j)]
                prefix=codec.example(demo.document,demo.summary)['input_ids']
                v=completion_ll(model,codec,row.document,row.summary,prefix,a.icp_max_length,torch)
                if v is not None:candidates.append((v,j))
            if not candidates:raise RuntimeError('All ICP demos excluded by context budget')
            best,j=max(candidates)
            writer.writerow({'sample_id':row.sample_id,'attack_split':row.attack_split,
                             'membership':int(row.membership),'icp_score':plain-best,
                             'plain_ll':plain,'best_demo_ll':best,'selected_pool_row':j})
            if i%25==0:f.flush();print('ICP',i,'/',len(pending),flush=True)
        f.flush()


def report(a,data):
    out=Path(a.out)
    required=[out/'target_tokens.csv',out/'base_tokens.csv',out/'icp_scores.csv']
    for f in required:
        if not f.is_file():raise FileNotFoundError(f)
    # Verify the cached scores belong to exactly this checkpoint and manifest.
    for name,stage in (('target_tokens','target'),('base_tokens','base'),('icp','icp')):
        meta=json.loads((out/(name+'.provenance.json')).read_text(encoding='utf8'))
        if meta['manifest_sha256']!=sha_file(Path(a.data)/'split_manifest.json'):
            raise RuntimeError(name+' cached scores are from another dataset')
        if stage=='target' and meta['checkpoint']!=fingerprint(a.checkpoint,a.method):
            raise RuntimeError('Wrong cached target scores')
        if stage=='icp' and meta['checkpoint']!=fingerprint(a.checkpoint,a.method):
            raise RuntimeError('Wrong cached ICP scores')
    t=pd.read_csv(required[0],keep_default_na=False,dtype={'sample_id':str})
    b=pd.read_csv(required[1],keep_default_na=False,dtype={'sample_id':str})
    c=pd.read_csv(required[2],keep_default_na=False,dtype={'sample_id':str})
    expected=set(data.sample_id)
    for kind,df in (('target',t),('base',b),('ICP',c)):
        if len(df)!=len(expected) or set(df.sample_id)!=expected or df.sample_id.duplicated().any():
            raise RuntimeError(kind+' scoring incomplete or foreign')
    merged=data[['sample_id','attack_split','membership']].merge(t,on='sample_id',suffixes=('','_t'),validate='one_to_one')
    merged=merged.merge(b,on='sample_id',suffixes=('','_base'),validate='one_to_one')
    merged=merged.merge(c[['sample_id','icp_score']],on='sample_id',validate='one_to_one')
    if not (merged.ids_sha256==merged.ids_sha256_base).all():raise RuntimeError('Base and target tokenization changed')
    if not (merged.n_tokens==merged.n_tokens_base).all():raise RuntimeError('Base/target scoring lengths differ')
    scores=[]
    for row in merged.itertuples(index=False):
        tl=np.asarray(json.loads(row.logp_json),dtype=float)
        bl=np.asarray(json.loads(row.logp_json_base),dtype=float)
        err=np.asarray(json.loads(row.error_json),dtype=bool)
        if len(tl)!=int(row.n_tokens) or len(bl)!=len(tl) or len(err)!=len(tl):
            raise RuntimeError('Malformed attack token statistics')
        cm=np.zeros(len(tl),dtype=bool);cm[-int(row.n_completion_tokens):]=True
        scores.append({'sample_id':row.sample_id,'attack_split':row.attack_split,'membership':int(row.membership),
                       'ez_mia_full':ez_score(tl,bl,err,np.ones(len(tl),dtype=bool)),
                       'ez_mia_completion':ez_score(tl,bl,err,cm),
                       'min_k_pp_full':float(row.min_k_pp_full),
                       'min_k_pp_completion':float(row.min_k_pp_completion),
                       'icp_mia_reference':float(row.icp_score),'n_tokens':int(row.n_tokens),
                       'n_error_full':int(row.n_error_full),'n_error_completion':int(row.n_error_completion)})
    df=pd.DataFrame(scores);df.to_csv(out/'per_example_attack_scores.csv',index=False)
    res=[]
    for key in ['ez_mia_full','icp_mia_reference','min_k_pp_full','ez_mia_completion','min_k_pp_completion']:
        stat=metrics_for_score(df,df[key],bootstrap=a.bootstrap,seed=a.seed)
        res.append({'attack':key,'method':a.method,'dataset':'XSum',**stat})
    pd.DataFrame(res).to_csv(out/'attack_results.csv',index=False)
    (out/'attack_results.json').write_text(json.dumps(res,indent=2,allow_nan=False)+'\n',encoding='utf8')
    lines=[r'\begin{tabular}{lrrrr}',r'\hline',
           'Attack & ROC-AUC & TPR@1\\%FPR (\\%) & Observed FPR (\\%) & Coverage (\\%) '+r'\\',r'\hline']
    for r in res:
        if r.get('roc_auc') is None:
            cols=[r['attack'],'--','--','--',f"{r['coverage']*100:.1f}"]
        else:
            cols=[r['attack'],f"{r['roc_auc']:.4f}",f"{r['tpr_at_1pct_fpr']*100:.2f}",
                  f"{r['observed_fpr']*100:.2f}",f"{r['coverage']*100:.1f}"]
        lines.append(' & '.join(cols)+r' \\')
    lines.extend([r'\hline',r'\end{tabular}'])
    (out/'attack_results_table.tex').write_text('\n'.join(lines)+'\n',encoding='utf8')
    print(pd.DataFrame(res)[['attack','roc_auc','tpr_at_1pct_fpr','observed_fpr','coverage']].to_string(index=False))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--stage',required=True,choices=('audit','score-target','score-base','score-icp','report'))
    p.add_argument('--method',required=True,choices=('lora','dp-lora','fibna'))
    p.add_argument('--data',default='xsum_qwen15_data')
    p.add_argument('--checkpoint',default=None)
    p.add_argument('--out',default=None)
    p.add_argument('--max-length',type=int,default=512)
    p.add_argument('--max-target-tokens',type=int,default=64)
    p.add_argument('--dtype',choices=('bf16','fp16','fp32'),default='bf16')
    p.add_argument('--min-k-ratio',type=float,default=.2)
    p.add_argument('--vocab-chunk',type=int,default=16)
    p.add_argument('--icp-encoder',default='sentence-transformers/all-MiniLM-L6-v2')
    p.add_argument('--icp-candidates',type=int,default=3)
    p.add_argument('--icp-max-length',type=int,default=1200)
    p.add_argument('--limit',type=int,default=0)
    p.add_argument('--bootstrap',type=int,default=1000)
    p.add_argument('--seed',type=int,default=42)
    a=p.parse_args()
    a.checkpoint=a.checkpoint or ('xsum_'+a.method.replace('-','_')+'_qwen15_5ep')
    a.out=a.out or str(Path(a.checkpoint)/'three_mia')
    data,tbl=data_all(a.data)
    meta=json.loads((Path(a.checkpoint)/'run_summary.json').read_text(encoding='utf8'))
    if meta.get('target_train_csv_sha256')!=sha_file(Path(a.data)/'target_train.csv'):
        raise RuntimeError('MIA checkpoint trained on different XSum data')
    if meta.get('max_length')!=a.max_length or meta.get('max_target_tokens')!=a.max_target_tokens:
        raise RuntimeError('MIA scoring codec differs from training')
    if meta.get('method')!=a.method or meta.get('is_pilot') or not meta.get('training_finished'):
        raise RuntimeError('Invalid or incomplete MIA target')
    if a.stage=='audit':
        print('PASS: complete checkpoint/immutable MIA data',a.method,'5,000 candidates');fingerprint(a.checkpoint,a.method);return
    if a.stage=='score-target':score_tokens(a,data,'target')
    elif a.stage=='score-base':score_tokens(a,data,'base')
    elif a.stage=='score-icp':score_icp(a,data,tbl['reference_pool.csv'])
    elif a.stage=='report':report(a,data)
if __name__=='__main__':main()
