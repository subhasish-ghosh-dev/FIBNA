@echo off
setlocal EnableExtensions
cd /d "%~dp0"
call conda activate gpu_env
if errorlevel 1 exit /b 1
python test_protocol.py
if errorlevel 1 exit /b 1
python prepare_xsum.py --stage prepare --out xsum_qwen15_data
if errorlevel 1 exit /b 1
python train_xsum.py --method lora --epochs 1 --max-train-records 16 --max-length 256 --max-target-tokens 32 --batch-size 1 --grad-accum 4 --out xsum_lora_smoke --log-every 2
if errorlevel 1 exit /b 1
python train_xsum.py --method dp-lora --epochs 1 --max-train-records 32 --max-length 256 --max-target-tokens 32 --logical-batch-size 4 --noise-multiplier 1.5 --out xsum_dp_lora_smoke --log-every 2
if errorlevel 1 exit /b 1
python train_xsum.py --method fibna --epochs 1 --max-train-records 16 --max-length 256 --max-target-tokens 32 --batch-size 1 --grad-accum 4 --shap-samples 24 --shap-every-steps 1 --out xsum_fibna_smoke --log-every 2
if errorlevel 1 exit /b 1
echo PASS: three-method smoke training complete.
exit /b 0
