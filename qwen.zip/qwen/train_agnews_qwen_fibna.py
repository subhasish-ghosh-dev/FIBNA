#!/usr/bin/env python3
"""Qwen2.5-1.5B AG News FIBNA: KernelSHAP WLS, LM-head perturbations, LoRA.

This is a documented Qwen/classification *adaptation* of the FIBNA method;
not the historical GPT-2 checkpoint code and NOT differentially private.

Uses the immutable Step-2 AG News CSVs and the identical class-completion
loss/LoRA settings as train_agnews_qwen_lora_5epoch.py.

Attribution is full-vocabulary weighted-least-squares KernelSHAP on grouped
article tokens with a fixed-token masking baseline. Attribution is refreshed
at a configurable optimizer-step interval and reused between refreshes.
At each requested noise step, additive Gaussian noise with
 std[v,h] = kappa * sum_j abs(phi[j,v]) * abs(W[v,h])/||W[v,:]||_2
is injected into the FP32, frozen, untied output head. Noise is *not*
applied to per-example gradients, and epsilon_code/delta_code are FIBNA scale
constants, not a privacy budget. Trainable LoRA adapters remain the only
optimizer-updated parameters.

IMPORTANT: adapter weights alone cannot reconstruct the FIBNA model. Use
load_agnews_qwen_fibna.py and BOTH adapter/ and lm_head_delta.safetensors.
"""
from __future__ import annotations
import argparse, contextlib, hashlib, json, math, os, random, sys, time
from pathlib import Path
import numpy as np
import pandas as pd
from agnews_qwen_common import AGNewsCodec, LABELS, sha_file


def check_data(root, cap=0):
    manifest_file = root/'split_manifest.json'
    if not manifest_file.exists():
        raise FileNotFoundError(manifest_file)
    meta = json.loads(manifest_file.read_text(encoding='utf8'))
    for n in ('target_train.csv','utility_val.csv','utility_test.csv',
              'attack_train.csv','attack_calibration.csv','attack_test.csv','attack_all.csv'):
        file = root/n
        if not file.exists() or sha_file(file) != meta.get('file_sha256',{}).get(n):
            raise RuntimeError(f'Immutable dataset checksum mismatch: {file}')
    train = pd.read_csv(root/'target_train.csv', keep_default_na=False)
    val = pd.read_csv(root/'utility_val.csv', keep_default_na=False)
    required = {'sample_id','text','label_id','text_hash','completion'}
    for name, df in [('training',train),('validation',val)]:
        if not required.issubset(df):
            raise KeyError(f'{name} lacks columns {required-set(df)}')
        if df.sample_id.duplicated().any() or df.text_hash.duplicated().any():
            raise ValueError(f'Duplicates in immutable {name} set')
        if not set(df.label_id.astype(int)).issubset(LABELS):
            raise ValueError('Unknown label')
        expect = df.label_id.astype(int).map(LABELS).map(lambda c:' '+c)
        if not (expect == df.completion.astype(str)).all():
            raise ValueError('Label/completion mismatch')
    if not set(train.text_hash).isdisjoint(set(val.text_hash)):
        raise ValueError('Training/validation text overlap')
    if len(train) != meta['training_members'] or len(val) != meta['utility_validation']:
        raise RuntimeError('Dataset counts differ from manifest')
    if meta.get('base_model') != 'Qwen/Qwen2.5-1.5B':
        raise RuntimeError('Not the fixed Qwen2.5-1.5B dataset')
    if cap:
        if not 0 < cap <= len(train):
            raise ValueError('Invalid training cap')
        train=train.iloc[:cap].copy()
    return meta, train, val


def auto_dtype(torch, mode):
    if mode=='auto':mode='bf16' if torch.cuda.is_bf16_supported() else 'fp16'
    return mode,{'bf16':torch.bfloat16,'fp16':torch.float16,'fp32':torch.float32}[mode]


def amp_context(torch, mode):
    if mode=='fp32':return contextlib.nullcontext()
    return torch.autocast(device_type='cuda',dtype={'bf16':torch.bfloat16,'fp16':torch.float16}[mode])


def shapley_kernel_weight(features, subset_size):
    if subset_size in (0,features):return 1000.0
    return (features-1)/(math.comb(features,subset_size)*subset_size*(features-subset_size))


def coalition_matrix(F, M, rng):
    """Always include empty, full, singleton and leave-one-out masks."""
    if F<2:raise ValueError('Need >=2 attribution features')
    if M<2*F+2:
        raise ValueError(f'Need at least {2*F+2} coalition samples for F={F}')
    max_m = 2**F
    M = min(M,max_m)
    masks={tuple([0]*F),tuple([1]*F)}
    for j in range(F):
        a=[0]*F;a[j]=1;masks.add(tuple(a))
        b=[1]*F;b[j]=0;masks.add(tuple(b))
    sizes=np.arange(1,F)
    weights=np.array([(F-1)/(math.comb(F,int(j))*j*(F-j)) for j in sizes],dtype=np.float64)
    weights/=weights.sum()
    while len(masks)<M:
        s=int(rng.choice(sizes,p=weights))
        chosen=rng.choice(F,size=s,replace=False)
        arr=[0]*F
        for j in chosen:arr[int(j)]=1
        masks.add(tuple(arr))
    return np.asarray(sorted(masks),dtype=np.float64)


def kernelshap_wls(masks, values, ridge=1e-7):
    """Weighted Shapley-kernel least-squares; returns F x V signed attributions.

    Accepts numpy matrices so the mathematical self-test runs on CPU and the
    full-vocabulary scorer can use the same deterministic implementation.
    """
    masks=np.asarray(masks,dtype=np.float64)
    values=np.asarray(values,dtype=np.float64)
    if masks.ndim!=2 or values.ndim!=2 or len(masks)!=len(values):
        raise ValueError('Invalid KernelSHAP matrix shapes')
    N,F=masks.shape
    X=np.concatenate([np.ones((N,1)),masks],axis=1)
    w=np.array([shapley_kernel_weight(F,int(row.sum())) for row in masks])
    gram=X.T@(w[:,None]*X)
    gram+=ridge*np.eye(F+1)
    gram[0,0]-=ridge
    rhs=X.T@(w[:,None]*values)
    beta=np.linalg.solve(gram,rhs)
    return beta[1:,:]


def get_article_groups(codec, prompt_len, count):
    beg=len(codec.pre)
    end=prompt_len-len(codec.tail)
    if end<=beg:
        raise RuntimeError('No article tokens to attribute')
    raw=np.array_split(np.arange(beg,end,dtype=np.int64),min(count,end-beg))
    return [t.tolist() for t in raw if len(t)]


def compute_shap_psi(model, batch, codec, torch, dtype, device, features, samples, seed,
                     forward_batch=1, max_prompt_tokens=0):
    """Full-vocabulary KernelSHAP from final-position logits of masked prompts.

    The fixed classification instruction and category suffix remain visible;
    contiguous article groups are toggled by replacing absent token IDs with
    EOS while keeping attention at 1 (position preserving masking convention).
    """
    labels=batch['labels'][0]
    valid=(labels!=-100).nonzero(as_tuple=False).reshape(-1)
    if valid.numel()==0:raise RuntimeError('No completion labels to locate prompt')
    prompt_len=int(valid[0].item())
    prompt=batch['input_ids'][0,:prompt_len].detach().clone().to(device)
    if max_prompt_tokens and prompt_len>max_prompt_tokens:
        # Keep suffix and the newest article tokens for feature evaluation.
        keep_pre=min(len(codec.pre), max_prompt_tokens//3)
        keep_tail=min(max_prompt_tokens-keep_pre, prompt_len-keep_pre)
        prompt=torch.cat([prompt[:keep_pre],prompt[-keep_tail:]],dim=0)
        # codec groups then need adjusted prefix/suffix sizes.
        raise RuntimeError('For publication, set --shap-max-prompt 0 to explain the full fixed prompt')
    groups=get_article_groups(codec,prompt_len,features)
    F=len(groups)
    if F<2:raise RuntimeError('Too few article tokens for KernelSHAP')
    masks=coalition_matrix(F,samples,np.random.default_rng(seed))
    baseline=int(codec.tok.eos_token_id)
    model.eval()
    predictions=[]
    with torch.inference_mode():
        for st in range(0,len(masks),forward_batch):
            ids=[]
            for mask in masks[st:st+forward_batch]:
                x=prompt.clone()
                for j,positions in enumerate(groups):
                    if mask[j]==0:x[positions]=baseline
                ids.append(x)
            inp=torch.stack(ids,dim=0)
            attn=torch.ones_like(inp)
            with amp_context(torch,dtype):
                logits=model(input_ids=inp,attention_mask=attn,use_cache=False).logits[:,-1,:]
            predictions.append(logits.detach().float().cpu().numpy())
    pred=np.concatenate(predictions,axis=0)
    phi=kernelshap_wls(masks,pred)
    psi=np.abs(phi).sum(axis=0).astype(np.float32)
    if not np.isfinite(psi).all() or np.any(psi<0):
        raise FloatingPointError('Invalid KernelSHAP attribution')
    return torch.from_numpy(psi).to(device=device),{
        'coalitions':int(len(masks)),'feature_groups':int(F),
        'psi_mean':float(psi.mean()),'psi_max':float(psi.max()),
        'psi_nonzero':int(np.count_nonzero(psi)),
        'explanation_prompt_tokens':int(prompt_len)}


def add_fibna_noise(head_weight, psi, coefficient, generator, chunk_rows=1024):
    """Apply feature-dependent Gaussian noise in FP32 row chunks to head only.

    Can be exercised on CPU for mathematical tests. The base input embedding
    matrix is *not* modified; output weight tying is broken deliberately.
    """
    import torch
    if head_weight.dtype!=torch.float32:
        raise TypeError('FP32 head required to preserve small FIBNA perturbations')
    V,H=head_weight.shape
    if psi.shape!=(V,):raise ValueError(f'Expected vocabulary SHAP vector {(V,)}, got {tuple(psi.shape)}')
    if not bool(torch.isfinite(psi).all().item()):raise ValueError('Non-finite SHAP vector')
    total_sigma2=0.0
    total_noise2=0.0
    with torch.no_grad():
        for st in range(0,V,chunk_rows):
            w=head_weight[st:st+chunk_rows]
            # row-wise normalized pretrained+perturbed LM-head weights
            norms=torch.linalg.vector_norm(w,ord=2,dim=1,keepdim=True).clamp_min(1e-5)
            sigma=(coefficient*psi[st:st+chunk_rows,None])*(w.abs()/norms)
            rnd=torch.randn(w.shape,device=w.device,dtype=torch.float32,generator=generator)
            noise=rnd*sigma
            total_sigma2+=float(sigma.square().sum().item())
            total_noise2+=float(noise.square().sum().item())
            w.add_(noise)
    return {'sigma_rms':math.sqrt(total_sigma2/(V*H)),
            'noise_rms':math.sqrt(total_noise2/(V*H)),
            'head_elements':V*H}


def score_labels(model, codec, text, torch, dtype, device):
    options=codec.choices(text)
    maxlen=max(len(ids) for _,ids,_,_ in options)
    input_ids=torch.tensor([ids+[codec.tok.pad_token_id]*(maxlen-len(ids)) for _,ids,_,_ in options],
                           dtype=torch.long,device=device)
    attention=torch.tensor([[1]*len(ids)+[0]*(maxlen-len(ids)) for _,ids,_,_ in options],
                           dtype=torch.long,device=device)
    with torch.inference_mode(),amp_context(torch,dtype):
        logits=model(input_ids=input_ids,attention_mask=attention,use_cache=False).logits
    scores={}
    for i,(cls,ids,p_len,nlab) in enumerate(options):
        pos=torch.arange(p_len-1,p_len+nlab-1,device=device)
        targets=input_ids[i,p_len:p_len+nlab]
        log_probs=torch.log_softmax(logits[i,pos,:].float(),dim=-1)
        scores[cls]=float(log_probs.gather(1,targets[:,None]).mean().item())
    return max(scores,key=scores.get)


def evaluate(model, codec, val_df, torch, dtype, device, cap=0):
    from sklearn.metrics import accuracy_score, f1_score
    model.eval()
    df=val_df.iloc[:cap] if cap else val_df
    preds=[]
    t0=time.perf_counter()
    for i,txt in enumerate(df.text,1):
        preds.append(int(score_labels(model,codec,txt,torch,dtype,device)))
        if i%100==0:print(f'Validation {i}/{len(df)}',flush=True)
    torch.cuda.synchronize(device)
    return {'n':int(len(df)),'accuracy':float(accuracy_score(df.label_id.astype(int),preds)),
            'macro_f1':float(f1_score(df.label_id.astype(int),preds,labels=list(LABELS),average='macro',zero_division=0)),
            'wall_seconds':round(time.perf_counter()-t0,4)},preds


def self_test():
    # Exact additive-game attribution of both vocabulary outputs, even with
    # dependent input-group coalition sampling.
    rng=np.random.default_rng(7)
    masks=coalition_matrix(4,36,rng)
    slopes=np.array([[2.,-1.,.5],[3.,4.,-2.],[0.1,1.,2.],[4.,-5.,3.]])
    yy=masks@slopes+np.array([5.,7.,-1.])
    phi=kernelshap_wls(masks,yy)
    np.testing.assert_allclose(phi,slopes,rtol=1e-5,atol=1e-5)
    import torch
    weight=torch.tensor([[3.,4.,0.],[0.,0.,5.]],dtype=torch.float32)
    attr=torch.tensor([1.,2.],dtype=torch.float32)
    gen=torch.Generator(device='cpu').manual_seed(77)
    stats=add_fibna_noise(weight,attr,0.01,gen,chunk_rows=1)
    assert stats['noise_rms']>0
    assert stats['head_elements']==6
    print('PASS: KernelSHAP additive-game recovery; FP32 feature-aware head perturbation; no DP guarantee.')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage',choices=('self-test','audit','train'),default='audit')
    parser.add_argument('--data',default='agnews_demia_qwen15')
    parser.add_argument('--out',default='agnews_fibna_qwen15_5ep')
    parser.add_argument('--base',default='Qwen/Qwen2.5-1.5B')
    parser.add_argument('--seed',type=int,default=42)
    parser.add_argument('--epochs',type=int,default=5)
    parser.add_argument('--max-length',type=int,default=256)
    parser.add_argument('--batch-size',type=int,default=2)
    parser.add_argument('--grad-accum',type=int,default=8)
    parser.add_argument('--lr',type=float,default=1e-4)
    parser.add_argument('--weight-decay',type=float,default=.01)
    parser.add_argument('--warmup-ratio',type=float,default=.03)
    parser.add_argument('--rank',type=int,default=8)
    parser.add_argument('--alpha',type=int,default=16)
    parser.add_argument('--dropout',type=float,default=.05)
    parser.add_argument('--dtype',choices=('auto','bf16','fp16','fp32'),default='auto')
    parser.add_argument('--shap-features',type=int,default=8)
    parser.add_argument('--shap-samples',type=int,default=100)
    parser.add_argument('--shap-every-steps',type=int,default=125,
                        help='KernelSHAP refresh every N optimizer steps; >1 is budgeted Qwen adaptation')
    parser.add_argument('--shap-forward-batch',type=int,default=1)
    parser.add_argument('--shap-max-prompt',type=int,default=0,
                        help='Reserved; 0=full available prompt with classification suffix preserved')
    parser.add_argument('--noise-every-steps',type=int,default=1)
    parser.add_argument('--noise-multiplier',type=float,default=1e-4)
    parser.add_argument('--epsilon-code',type=float,default=10.)
    parser.add_argument('--delta-code',type=float,default=1e-5)
    parser.add_argument('--noise-chunk-rows',type=int,default=1024)
    parser.add_argument('--no-gradient-checkpointing',action='store_true')
    parser.add_argument('--eval-last-only',action='store_true')
    parser.add_argument('--eval-max',type=int,default=0)
    parser.add_argument('--max-train-records',type=int,default=0)
    parser.add_argument('--log-every',type=int,default=25)
    a=parser.parse_args()
    if a.stage=='self-test':self_test();return
    root=Path(a.data)
    meta,train,val=check_data(root,a.max_train_records)
    if a.stage=='audit':
        print('PASS: same immutable 10,000-member AG News training set and 1,000 validation records')
        print('train SHA256:',sha_file(root/'target_train.csv'))
        print('split SHA256:',sha_file(root/'split_manifest.json'))
        return
    if a.base!=meta['base_model']:raise ValueError('Base model mismatch')
    if not (a.epochs>=1 and a.batch_size>=1 and a.grad_accum>=1 and a.max_length>=64):
        raise ValueError('Invalid epoch/batch/length')
    if not (a.shap_features>=2 and a.shap_samples>=2*a.shap_features+2 and a.shap_every_steps>=1):
        raise ValueError('Invalid SHAP coalition/refresh settings')
    if not (a.shap_forward_batch>=1 and a.noise_every_steps>=1 and a.noise_multiplier>0):
        raise ValueError('Invalid forward/noise settings')
    if not (a.epsilon_code>0 and 0<a.delta_code<1 and a.noise_chunk_rows>=1):
        raise ValueError('Invalid coefficient settings')
    if a.shap_max_prompt!=0:raise ValueError('Only full-prompt explanations are supported; use --shap-max-prompt 0')
    out=Path(a.out)
    if out.exists() and any(out.iterdir()):raise FileExistsError(f'Output directory not empty: {out}')
    out.mkdir(parents=True,exist_ok=True)

    import torch
    import torch.nn as nn
    from torch.utils.data import DataLoader
    from transformers import AutoTokenizer,AutoModelForCausalLM,get_linear_schedule_with_warmup
    from peft import LoraConfig,get_peft_model
    from safetensors.torch import save_file

    if not torch.cuda.is_available():raise RuntimeError('CUDA GPU required')
    device=torch.device('cuda:0')
    setup_start=time.perf_counter()
    random.seed(a.seed);np.random.seed(a.seed);torch.manual_seed(a.seed);torch.cuda.manual_seed_all(a.seed)
    dtype,weight_dtype=auto_dtype(torch,a.dtype)
    tok=AutoTokenizer.from_pretrained(a.base,use_fast=True)
    if tok.pad_token is None:tok.pad_token=tok.eos_token
    tok.padding_side='right'
    codec=AGNewsCodec(tok,a.max_length)
    examples=[codec.example(t,l) for t,l in zip(train.text,train.label_id)]
    loader=DataLoader(examples,batch_size=a.batch_size,shuffle=True,
                      generator=torch.Generator().manual_seed(a.seed),
                      collate_fn=codec.collate,num_workers=0,pin_memory=True)
    try:
        base=AutoModelForCausalLM.from_pretrained(a.base,torch_dtype=weight_dtype)
    except TypeError:
        base=AutoModelForCausalLM.from_pretrained(a.base,dtype=weight_dtype)
    base.config.use_cache=False
    # Qwen2.5-1.5B ties input token embeddings and LM-head weights. FIBNA
    # injects noise into the LM head alone. Untie *only* the output head so
    # (1) input token embeddings stay frozen, (2) precision stays FP32 and
    # tiny Gaussian changes are not silently quantized away in bf16.
    class FP32OutputHead(nn.Module):
        def __init__(self,original):
            super().__init__()
            self.weight=nn.Parameter(original.weight.detach().float().clone(),requires_grad=False)
        def forward(self,hidden):
            with torch.autocast(device_type='cuda',enabled=False):
                return torch.nn.functional.linear(hidden.float(),self.weight)
    if base.get_output_embeddings().weight.data_ptr()!=base.get_input_embeddings().weight.data_ptr():
        raise RuntimeError('Qwen tie_word_embeddings differs from verified reference; audit model')
    fp_head=FP32OutputHead(base.get_output_embeddings())
    base.set_output_embeddings(fp_head)
    if base.get_output_embeddings().weight.data_ptr()==base.get_input_embeddings().weight.data_ptr():
        raise RuntimeError('FIBNA FP32 output head was not untied')
    cfg=LoraConfig(r=a.rank,lora_alpha=a.alpha,lora_dropout=a.dropout,
                   target_modules=['q_proj','v_proj'],bias='none',task_type='CAUSAL_LM')
    model=get_peft_model(base,cfg)
    if not a.no_gradient_checkpointing:
        model.gradient_checkpointing_enable()
        if hasattr(model,'enable_input_require_grads'):model.enable_input_require_grads()
    model.to(device)
    head=model.get_output_embeddings()
    if head.weight.dtype!=torch.float32:raise RuntimeError('FP32 output head unexpectedly cast to lower precision')
    if head.weight.data_ptr()==model.get_input_embeddings().weight.data_ptr():
        raise RuntimeError('Output and input weights were re-tied')
    # Compute head delta relative to the exact BF16 base weights actually loaded.
    initial_head_cpu=head.weight.detach().cpu().clone()
    params=[x for x in model.parameters() if x.requires_grad]
    n_trainable=sum(x.numel() for x in params)
    if n_trainable==0:raise RuntimeError('No LoRA parameters require gradients')
    if len(params)>0 and any(p is head.weight for p in params):
        raise RuntimeError('Head must not receive optimizer updates')
    optim=torch.optim.AdamW(params,lr=a.lr,weight_decay=a.weight_decay)
    steps_epoch=math.ceil(len(loader)/a.grad_accum)
    total_steps=steps_epoch*a.epochs
    warmup=int(round(total_steps*a.warmup_ratio))
    scheduler=get_linear_schedule_with_warmup(optim,num_warmup_steps=warmup,num_training_steps=total_steps)
    scaler=torch.amp.GradScaler('cuda',enabled=dtype=='fp16')
    noise_gen=torch.Generator(device=device).manual_seed(a.seed+7600)
    kappa=a.noise_multiplier/a.epsilon_code * math.sqrt(2*math.log(1.25/a.delta_code))
    print(f'FIBNA | base={a.base} epochs={a.epochs} train={len(train)} '
          f'optimizer_steps={total_steps} LoRA_params={n_trainable} '
          f'FP32_head={tuple(head.weight.shape)} SHAP={a.shap_samples} coalitions '
          f'every {a.shap_every_steps} updates, noise every {a.noise_every_steps} updates '
          f'kappa={kappa:.9g} (NOT DP)',flush=True)
    torch.cuda.synchronize(device)
    setup_secs=time.perf_counter()-setup_start
    global_start=time.perf_counter()
    logs=[];epoch_overhead=[];shap_events=[];noise_events=[]
    opt_steps=0;cache_psi=None;shap_seconds=0.;noise_seconds=0.;train_seconds=0.;val_seconds=0.
    peak_alloc=0.;peak_reserved=0.
    for epoch in range(a.epochs):
        torch.cuda.reset_peak_memory_stats(device)
        torch.cuda.synchronize(device)
        epoch_start=time.perf_counter()
        epoch_shap_before=shap_seconds;epoch_noise_before=noise_seconds
        epoch_start_steps=opt_steps
        model.train();optim.zero_grad(set_to_none=True)
        total_loss_weighted=0.;supervised_tokens=0;micro=0
        for i,batch in enumerate(loader):
            if micro==0:  # never alter head while gradients from earlier microbatches are live
                if cache_psi is None or opt_steps%a.shap_every_steps==0:
                    torch.cuda.synchronize(device)
                    t=time.perf_counter()
                    cache_psi,info=compute_shap_psi(model,batch,codec,torch,dtype,device,
                                                     a.shap_features,a.shap_samples,
                                                     seed=a.seed+opt_steps*37,
                                                     forward_batch=a.shap_forward_batch,
                                                     max_prompt_tokens=a.shap_max_prompt)
                    torch.cuda.synchronize(device)
                    duration=time.perf_counter()-t
                    shap_seconds+=duration
                    shap_events.append({'epoch':epoch+1,'optimizer_step':opt_steps,
                                        'wall_seconds':round(duration,4),**info})
                    print(f'  KernelSHAP refresh step {opt_steps} | outputs={len(cache_psi)} '
                          f'coalitions={info["coalitions"]} wall={duration:.2f}s',flush=True)
                    model.train()
                if opt_steps%a.noise_every_steps==0:
                    torch.cuda.synchronize(device)
                    t=time.perf_counter()
                    result=add_fibna_noise(head.weight,cache_psi,kappa,noise_gen,
                                           chunk_rows=a.noise_chunk_rows)
                    torch.cuda.synchronize(device)
                    elapsed=time.perf_counter()-t
                    noise_seconds+=elapsed
                    noise_events.append({'epoch':epoch+1,'optimizer_step':opt_steps,
                                         'wall_seconds':round(elapsed,4),**result})
            batch={k:v.to(device,non_blocking=True) for k,v in batch.items()}
            ntokens=int((batch['labels'][:,1:]!=-100).sum().item())
            if ntokens==0:raise RuntimeError('Batch has no supervised label completion tokens')
            with amp_context(torch,dtype):loss=model(**batch).loss
            if not torch.isfinite(loss):raise FloatingPointError(f'Non-finite loss epoch={epoch+1} batch={i+1}')
            total_loss_weighted+=float(loss.detach().float().item())*ntokens
            supervised_tokens+=ntokens
            group_size=min(a.grad_accum,len(loader)-(i//a.grad_accum)*a.grad_accum)
            scaler.scale(loss/group_size).backward()
            micro+=1
            if micro==a.grad_accum or i+1==len(loader):
                scaler.unscale_(optim)
                torch.nn.utils.clip_grad_norm_(params,1.)
                scaler.step(optim);scaler.update();scheduler.step()
                optim.zero_grad(set_to_none=True)
                opt_steps+=1;micro=0
            if a.log_every and (i+1)%a.log_every==0:
                print(f'epoch {epoch+1}/{a.epochs} microbatch {i+1}/{len(loader)} '
                      f'optstep {opt_steps}/{total_steps} maskedNLL {float(loss.detach().float().item()):.4f}',flush=True)
        torch.cuda.synchronize(device)
        ep_time=time.perf_counter()-epoch_start
        train_seconds+=ep_time
        pa=torch.cuda.max_memory_allocated(device)/2**30
        pr=torch.cuda.max_memory_reserved(device)/2**30
        peak_alloc=max(peak_alloc,pa);peak_reserved=max(peak_reserved,pr)
        epoch_loss=total_loss_weighted/supervised_tokens
        print(f'Epoch {epoch+1}: loss={epoch_loss:.5f} wall={ep_time:.2f}s '
              f'peak_alloc={pa:.3f}GiB peak_reserved={pr:.3f}GiB',flush=True)
        val_metrics=None;val_time=0.0
        if not a.eval_last_only or epoch==a.epochs-1:
            torch.cuda.synchronize(device);t=time.perf_counter()
            val_metrics,predictions=evaluate(model,codec,val,torch,dtype,device,cap=a.eval_max)
            torch.cuda.synchronize(device)
            val_time=time.perf_counter()-t
            val_seconds+=val_time
            pd.DataFrame({'sample_id':val.sample_id[:len(predictions)],
                          'true_label':val.label_id[:len(predictions)],
                          'pred_label':predictions}).to_csv(out/f'validation_predictions_epoch_{epoch+1}.csv',index=False)
            print(f'  Validation: accuracy={val_metrics["accuracy"]:.4f}, '
                  f'macro_f1={val_metrics["macro_f1"]:.4f}',flush=True)
        epoch_overhead.append({'epoch':epoch+1,'examples_seen':len(train),'microbatches':len(loader),
            'optimizer_steps':opt_steps-epoch_start_steps,'training_wall_seconds':round(ep_time,4),
            'kernelshap_wall_seconds':round(shap_seconds-epoch_shap_before,4),
            'noise_wall_seconds':round(noise_seconds-epoch_noise_before,4),
            'validation_wall_seconds':round(val_time,4),
            'peak_gpu_training_allocated_gib':round(pa,4),
            'peak_gpu_training_reserved_gib':round(pr,4),
            'masked_token_nll':float(epoch_loss)})
        logs.append({'epoch':epoch+1,'masked_token_nll':float(epoch_loss),
                     'validation':val_metrics,'optimizer_steps_cumulative':opt_steps})
        pd.DataFrame(epoch_overhead).to_csv(out/'epoch_overhead.csv',index=False)
        pd.DataFrame(shap_events).to_csv(out/'shap_events.csv',index=False)
        # Prevent very large noise log from loss on interruption; ~3125 records.
        pd.DataFrame(noise_events).to_csv(out/'noise_events.csv',index=False)
    torch.cuda.synchronize(device)
    save_start=time.perf_counter()
    model.eval()
    model.save_pretrained(out/'adapter',safe_serialization=True,save_embedding_layers=False)
    tok.save_pretrained(out/'adapter')
    head_delta=(head.weight.detach().cpu()-initial_head_cpu).contiguous()
    # Dense FP32 delta is necessary for exact FIBNA reconstruction at evaluation.
    save_file({'lm_head_delta':head_delta},str(out/'lm_head_delta.safetensors'))
    torch.cuda.synchronize(device)
    save_secs=time.perf_counter()-save_start
    elapsed=time.perf_counter()-global_start
    ck={'base':a.base,'method':'FIBNA_Qwen_AGNews_KernelSHAP_WLS',
        'adapter_dir':'adapter','head_delta_file':'lm_head_delta.safetensors',
        'untie_lm_head':True,'head_dtype':'float32',
        'head_is_optimizer_trainable':False,
        'training_model_tie_original':True,
        'original_train_csv_sha256':sha_file(root/'target_train.csv'),
        'split_manifest_sha256':sha_file(root/'split_manifest.json'),
        'noise_coefficient_kappa':kappa,'shap_features':a.shap_features,
        'shap_samples':a.shap_samples,'shap_refresh_steps':a.shap_every_steps,
        'noise_every_steps':a.noise_every_steps,
        'model_adaptation':'full-vocabulary KernelSHAP-WLS on grouped article tokens; sparse refresh schedule; output-head-only FP32 Gaussian additive perturbations',
        'formal_DP':False}
    (out/'fibna_checkpoint.json').write_text(json.dumps(ck,indent=2),encoding='utf8')
    overhead={
        'method':'FIBNA','is_pilot':bool(a.max_train_records or a.eval_max),
        'measurement_protocol':'CUDA-synchronized training epochs include SHAP + weight perturbation; validation and save timed separately',
        'gpu':torch.cuda.get_device_name(device),
        'gpu_total_gib':round(torch.cuda.get_device_properties(device).total_memory/2**30,3),
        'cuda_version':torch.version.cuda,
        'data_sha256':sha_file(root/'target_train.csv'),
        'model':a.base,'seed':a.seed,'dtype':dtype,
        'gradient_checkpointing':not a.no_gradient_checkpointing,
        'train_count':len(train),'epochs':a.epochs,'max_length':a.max_length,
        'microbatch_size':a.batch_size,'gradient_accumulation':a.grad_accum,
        'effective_batch_size':a.batch_size*a.grad_accum,
        'optimizer_steps':opt_steps,
        'training_wall_seconds':round(train_seconds,4),
        'training_wall_hours':round(train_seconds/3600,5),
        'validation_wall_seconds':round(val_seconds,4),
        'checkpoint_save_wall_seconds':round(save_secs,4),
        'setup_wall_seconds':round(setup_secs,4),
        'wall_seconds_after_setup':round(elapsed,4),
        'seconds_per_optimizer_step':round(train_seconds/opt_steps,4),
        'peak_gpu_training_allocated_gib':round(peak_alloc,4),
        'peak_gpu_training_reserved_gib':round(peak_reserved,4),
        'gpu_memory_note':'allocated=PyTorch peak live tensors, reserved=peak CUDA caching allocator; not nvidia-smi',
        'validation_schedule':'final_epoch_only' if a.eval_last_only else 'each_epoch',
        'kernelshap_wall_seconds':round(shap_seconds,4),
        'noise_wall_seconds':round(noise_seconds,4),
        'kernelshap_refreshes':len(shap_events),
        'lm_head_noise_injections':len(noise_events),
        'noise_coefficient_kappa':kappa,
        'head_delta_file_size_bytes':(out/'lm_head_delta.safetensors').stat().st_size,
        'training_finished':True,
        'epoch_overhead':epoch_overhead,
    }
    (out/'overhead_summary.json').write_text(json.dumps(overhead,indent=2),encoding='utf8')
    result={
        'protocol':'AG News causal-LM class-completion masked loss; Qwen FIBNA adaptation',
        'model':a.base,'method':'FIBNA','is_pilot':bool(a.max_train_records or a.eval_max),
        'target_train_csv_sha256':sha_file(root/'target_train.csv'),
        'split_manifest_sha256':sha_file(root/'split_manifest.json'),
        'seed':a.seed,'train_count':len(train),'val_count':len(val),
        'dtype':dtype,'max_length':a.max_length,'epochs':a.epochs,
        'loss_mask':'label completion and EOS tokens only',
        'lora':{'rank':a.rank,'alpha':a.alpha,'dropout':a.dropout,'target_modules':['q_proj','v_proj']},
        'optimizer':{'name':'AdamW','lr':a.lr,'weight_decay':a.weight_decay,
                     'grad_accum':a.grad_accum,'microbatch':a.batch_size,
                     'warmup_steps':warmup,'global_clip':1.0},
        'shap':{'type':'KernelSHAP WLS','features':a.shap_features,
                'nsamples':a.shap_samples,'refresh_every_optimizer_steps':a.shap_every_steps,
                'vocabulary_scope':'all output logits','masking_baseline':'EOS'},
        'noise':{'multiplier_nu':a.noise_multiplier,'epsilon_code':a.epsilon_code,
                 'delta_code':a.delta_code,'kappa':kappa,
                 'injection_every_optimizer_steps':a.noise_every_steps,
                 'location':'FP32 untied LM output head','formal_DP':False},
        'head_delta_file':'lm_head_delta.safetensors',
        'n_trainable_params':n_trainable,
        'optimizer_steps_total':opt_steps,'microbatches_per_epoch':len(loader),
        'training_wall_seconds':round(train_seconds,4),
        'peak_gpu_allocated_gib':round(peak_alloc,3),
        'peak_gpu_reserved_gib':round(peak_reserved,3),
        'validation_schedule':'final_epoch_only' if a.eval_last_only else 'each_epoch',
        'training_log':logs,
        'software':{'python':sys.version.split()[0],
                     'torch':torch.__version__,
                     'transformers':__import__('transformers').__version__,
                     'peft':__import__('peft').__version__}}
    (out/'run_summary.json').write_text(json.dumps(result,indent=2),encoding='utf8')
    print(f'PASS: FIBNA adapter + FP32 LM head delta saved under {out.resolve()}')
    print(f'OVERHEAD training={train_seconds/3600:.3f}h SHAP={shap_seconds:.1f}s '
          f'noise={noise_seconds:.1f}s peakGPU={peak_alloc:.3f}GiB',flush=True)

if __name__=='__main__':main()
