#!/usr/bin/env python3
"""Print ONLY measured DP-LoRA utility, overhead, and attack results in LaTeX.

All input paths must be real completed GPU outputs. No synthetic results are used.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import math
import pandas as pd

LABELS={'ez_mia_full':'EZ-MIA', 'icp_mia_reference':'ICP-MIA (reference)',
        'min_k_pp_full':'Min-K%++',
        'ez_mia_completion':'EZ-MIA (completion)',
        'min_k_pp_completion':'Min-K%++ (completion)'}


def required_json(file):
    if not file.is_file():raise FileNotFoundError(f'Complete the corresponding GPU stage first: {file}')
    return json.loads(file.read_text(encoding='utf-8'))


def safe(x):
    try:
        n=float(x)
        return n if math.isfinite(n) else None
    except (ValueError,TypeError):
        return None


def fmt(x, mult=1, nd=2):
    try:
        v=float(x)
        if not math.isfinite(v):return '--'
        return f'{v*mult:.{nd}f}'
    except (TypeError,ValueError):return '--'


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--dp-root',default='agnews_dp_lora_qwen15_5ep')
    ap.add_argument('--lora-root',default='agnews_lora_qwen15_5ep')
    ap.add_argument('--out',default='',help='Defaults to DP-LoRA root/combined_results')
    a=ap.parse_args()
    dp=Path(a.dp_root); lora=Path(a.lora_root)
    util=required_json(dp/'test_evaluation/test_metrics.json')
    overhead=required_json(dp/'overhead_summary.json')
    summary=required_json(dp/'run_summary.json')
    attack_file=dp/'three_mia/attack_results.csv'
    if not attack_file.is_file():raise FileNotFoundError(f'Finish three MIA stages first: {attack_file}')
    att=pd.read_csv(attack_file)
    if util.get('method')!='DP-LoRA' or util.get('is_pilot') or int(util.get('n',0))!=2000:
        raise RuntimeError('Utility result is not the full 2,000-record DP-LoRA test result')
    if summary.get('method')!='DP-LoRA' or summary.get('is_pilot') or int(summary.get('epochs',0))!=5:
        raise RuntimeError('Target is not a full five-epoch DP-LoRA run')
    if overhead.get('method')!='DP-LoRA' or not overhead.get('training_finished'):
        raise RuntimeError('Invalid DP-LoRA overhead measurements')
    if not {'attack','roc_auc','tpr_at_1pct_fpr','observed_fpr','coverage'}.issubset(att):
        raise RuntimeError('Missing MIA result columns')
    a_names=['ez_mia_full','icp_mia_reference','min_k_pp_full']
    if not set(a_names).issubset(att.attack):raise RuntimeError('One or more required attacks not evaluated')
    lora_attack_file=lora/'three_mia/attack_results.csv'
    baseline=pd.read_csv(lora_attack_file).set_index('attack') if lora_attack_file.exists() else None
    out=Path(a.out) if a.out else dp/'combined_results'
    out.mkdir(parents=True,exist_ok=True)
    rows=[]; tex=[r'\begin{tabular}{lrrrrr}',r'\hline',
       r'Attack & AUC & TPR@1\%FPR (\%) & Observed FPR (\%) & Coverage (\%) & TPR reduction vs LoRA (pp) \\',r'\hline']
    for k in a_names:
        r=att.loc[att.attack==k].iloc[0]
        delta=None
        if baseline is not None and k in baseline.index:
            try:
                lo=float(baseline.loc[k,'tpr_at_1pct_fpr']); dp_t=float(r.tpr_at_1pct_fpr)
                if math.isfinite(lo) and math.isfinite(dp_t):delta=(lo-dp_t)*100
            except (TypeError,ValueError):pass
        rows.append({'attack':LABELS[k],'auc':safe(r.roc_auc),
                     'tpr_at_1pct_fpr':safe(r.tpr_at_1pct_fpr),'observed_fpr':safe(r.observed_fpr),
                     'coverage':safe(r.coverage),'tpr_reduction_vs_lora_pp':delta})
        tex.append(f'{LABELS[k]} & {fmt(r.roc_auc,nd=4)} & {fmt(r.tpr_at_1pct_fpr,100)} & '
                   f'{fmt(r.observed_fpr,100)} & {fmt(r.coverage,100)} & {fmt(delta)} '+r'\\')
    tex.extend([r'\hline',r'\end{tabular}'])
    (out/'dp_lora_mia_table.tex').write_text('\n'.join(tex)+'\n',encoding='utf-8')
    acc=fmt(util['accuracy'],100); f1=fmt(util['macro_f1'],100)
    utility_tex='\n'.join([r'\begin{tabular}{lrrr}',r'\hline',r'Method & Test samples & Accuracy (\%) & Macro-F1 (\%) \\',r'\hline',
                            f'DP-LoRA & {util["n"]} & {acc} & {f1} '+r'\\',r'\hline',r'\end{tabular}'])
    (out/'dp_lora_utility_table.tex').write_text(utility_tex+'\n',encoding='utf-8')
    results={'method':'DP-LoRA','classification':{'accuracy':util['accuracy'],'macro_f1':util['macro_f1'],
             'n_test':util['n']},'mia':rows,'training':{
             'hours':overhead.get('training_wall_hours'),
             'peak_gpu_allocated_gib':overhead.get('peak_gpu_training_allocated_gib'),
             'peak_gpu_reserved_gib':overhead.get('peak_gpu_training_reserved_gib')},
             'privacy':summary.get('privacy',{}),
             'lora_mia_comparison_available':baseline is not None}
    (out/'dp_lora_combined_results.json').write_text(json.dumps(results,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(f'DP-LoRA held-out test: {acc}% accuracy, {f1}% macro F1, n={util["n"]}')
    print(f'DP-LoRA training-only time: {fmt(overhead.get("training_wall_hours"),nd=4)} hours; '
          f'peak GPU allocated: {fmt(overhead.get("peak_gpu_training_allocated_gib"),nd=3)} GiB')
    print(pd.DataFrame(rows).to_string(index=False))
    if baseline is None:print('LoRA attack file not found; TPR mitigation columns shown as -- (not assumed).')
    print('Saved:',out.resolve())

if __name__=='__main__':main()
