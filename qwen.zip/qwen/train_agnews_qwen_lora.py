#!/usr/bin/env python3
"""Qwen2.5-1.5B LoRA AG News classification, based on fixed Step-2 CSVs.

Training targets are CLASS COMPLETION TOKENS ONLY. This is a controlled AG News
study, not an exact reproduction of any DeMIA benchmark data partition.

Stages:
  audit: validate Step-2 manifests without loading Qwen or a GPU.
  train: independently initialize and train the LoRA adapter on target_train.csv.

For subsequent DP-LoRA/FIBNA and DeMIA experiments import AGNewsCodec from
agnews_qwen_common.py to preserve *identical* class-completion tokenization.
"""
from __future__ import annotations
import argparse
import contextlib
import hashlib
import json
import math
import os
import random
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

from agnews_qwen_common import AGNewsCodec, LABELS, sha_file


def check_data(root, train_cap=0):
    meta_path = root / 'split_manifest.json'
    if not meta_path.is_file():
        raise FileNotFoundError(meta_path)
    meta = json.loads(meta_path.read_text(encoding='utf-8'))
    expected = meta.get('file_sha256', {})
    for name in ['target_train.csv', 'utility_val.csv', 'utility_test.csv',
                 'attack_train.csv', 'attack_calibration.csv', 'attack_test.csv', 'attack_all.csv']:
        path = root / name
        if not path.is_file():
            raise FileNotFoundError(path)
        actual = sha_file(path)
        if expected.get(name) != actual:
            raise RuntimeError(f'Immutable split SHA-256 mismatch: {name}; do not use modified data')
    tr = pd.read_csv(root / 'target_train.csv', keep_default_na=False)
    va = pd.read_csv(root / 'utility_val.csv', keep_default_na=False)
    required = {'sample_id', 'text', 'text_hash', 'label_id', 'label_name', 'prompt', 'completion'}
    for df, name in [(tr, 'target_train'), (va, 'utility_val')]:
        missing = required - set(df.columns)
        if missing:
            raise RuntimeError(f'{name}: missing columns {sorted(missing)}')
        if df.sample_id.duplicated().any() or df.text_hash.duplicated().any():
            raise RuntimeError(f'{name}: repeated sample_id/text_hash')
        if not set(df.label_id.astype(int)).issubset(LABELS):
            raise RuntimeError(f'{name}: invalid label IDs')
        expected_completion = df.label_id.astype(int).map(LABELS).map(lambda x: ' ' + x)
        if not (df.completion.astype(str) == expected_completion).all():
            raise RuntimeError(f'{name}: labels and completions are inconsistent')
    if not set(tr.text_hash).isdisjoint(va.text_hash):
        raise RuntimeError('Target training and validation text overlap')
    if len(tr) != meta['training_members'] or len(va) != meta['utility_validation']:
        raise RuntimeError('Dataset length disagrees with Step-2 manifest')
    if meta.get('base_model') != 'Qwen/Qwen2.5-1.5B':
        raise RuntimeError('Unexpected base model in Step-2 manifest')
    if train_cap:
        tr = tr.iloc[:train_cap].copy()
    return meta, tr, va


class NewsDataset:
    def __init__(self, frame, codec):
        self.records = [codec.example(t, l) for t, l in zip(frame.text, frame.label_id)]

    def __len__(self):
        return len(self.records)

    def __getitem__(self, idx):
        return self.records[idx]


def auto_dtype(torch, dtype):
    if dtype == 'auto':
        dtype = 'bf16' if torch.cuda.is_bf16_supported() else 'fp16'
    value = {'bf16': torch.bfloat16, 'fp16': torch.float16, 'fp32': torch.float32}[dtype]
    return dtype, value


def amp_context(torch, dtype):
    if dtype == 'fp32':
        return contextlib.nullcontext()
    return torch.autocast(device_type='cuda', dtype={'bf16': torch.bfloat16, 'fp16': torch.float16}[dtype])


def score_labels(model, codec, text, torch, dtype, device):
    """Mean log likelihood of completion tokens (no EOS), 4 candidates in one pass."""
    options = codec.choices(text)
    maxlen = max(len(ids) for _, ids, _, _ in options)
    data = [ids + [codec.tok.pad_token_id] * (maxlen - len(ids))
            for _, ids, _, _ in options]
    attn = [[1] * len(ids) + [0] * (maxlen - len(ids))
            for _, ids, _, _ in options]
    ids = torch.tensor(data, dtype=torch.long, device=device)
    mask = torch.tensor(attn, dtype=torch.long, device=device)
    with torch.inference_mode(), amp_context(torch, dtype):
        logits = model(input_ids=ids, attention_mask=mask, use_cache=False).logits
    scores = {}
    for row, (k, seq, p_len, n_lab) in enumerate(options):
        # Completion token j is predicted by logits at position p_len + j - 1.
        pos = torch.arange(p_len-1, p_len+n_lab-1, device=device)
        token_ids = ids[row, p_len:p_len+n_lab]
        chosen = logits[row, pos, :].float()
        lp = torch.log_softmax(chosen, dim=-1)
        scores[k] = float(lp.gather(1, token_ids.unsqueeze(1)).mean().item())
    return max(scores, key=scores.get), scores


def evaluate(model, codec, frame, torch, dtype, device, cap=0, show_every=100):
    model.eval()
    if cap:
        frame = frame.iloc[:cap]
    from sklearn.metrics import accuracy_score, f1_score
    truth, prediction, sample_id, scores = [], [], [], []
    start = time.perf_counter()
    for i, row in enumerate(frame.itertuples(index=False), 1):
        pred, cls_scores = score_labels(model, codec, row.text, torch, dtype, device)
        prediction.append(int(pred))
        truth.append(int(row.label_id))
        sample_id.append(row.sample_id)
        scores.append(cls_scores)
        if show_every and i % show_every == 0:
            print(f'  validation {i}/{len(frame)}', flush=True)
    return {'n': len(frame),
            'accuracy': float(accuracy_score(truth, prediction)),
            'macro_f1': float(f1_score(truth, prediction, labels=list(LABELS), average='macro', zero_division=0)),
            'elapsed_seconds': round(time.perf_counter() - start, 2),
            'truth': truth, 'predictions': prediction, 'sample_ids': sample_id,
            'scores': scores}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--stage', choices=['audit', 'train'], default='audit')
    p.add_argument('--data', default='agnews_demia_qwen15')
    p.add_argument('--out', default='agnews_lora_qwen15')
    p.add_argument('--base', default='Qwen/Qwen2.5-1.5B')
    p.add_argument('--seed', type=int, default=42)
    p.add_argument('--max-length', type=int, default=256)
    p.add_argument('--batch-size', type=int, default=2)
    p.add_argument('--grad-accum', type=int, default=8)
    p.add_argument('--epochs', type=int, default=5)
    p.add_argument('--lr', type=float, default=1e-4)
    p.add_argument('--weight-decay', type=float, default=0.01)
    p.add_argument('--warmup-ratio', type=float, default=0.03)
    p.add_argument('--rank', type=int, default=8)
    p.add_argument('--alpha', type=int, default=16)
    p.add_argument('--dropout', type=float, default=0.05)
    p.add_argument('--dtype', choices=['auto', 'bf16', 'fp16', 'fp32'], default='auto')
    p.add_argument('--no-gradient-checkpointing', action='store_true')
    p.add_argument('--eval-max', type=int, default=0,
                   help='0=entire 1000-row validation set; >0 marks exploratory run')
    p.add_argument('--eval-last-only', action='store_true',
                   help='Evaluate full validation set only after the final epoch (keeps training overhead separate).')
    p.add_argument('--max-train-records', type=int, default=0,
                   help='0=all 10000 target examples; >0 smoke test only')
    p.add_argument('--log-every', type=int, default=25)
    a = p.parse_args()
    root = Path(a.data)
    meta, tr, va = check_data(root, a.max_train_records)
    if a.stage == 'audit':
        print('PASS: AG News split files match immutable SHA-256 manifest')
        print(f'  Target records: {len(tr):,} | Validation: {len(va):,}')
        print(f'  Base model: {meta["base_model"]}')
        print('  Model NOT loaded; no GPU training performed.')
        return
    if a.base != meta['base_model']:
        raise RuntimeError('Changing base model invalidates the shared LoRA/DP-LoRA/FIBNA protocol')
    if a.batch_size < 1 or a.grad_accum < 1 or a.epochs < 1 or a.max_length < 64 or a.lr <= 0:
        raise ValueError('Invalid hyperparameter')
    out = Path(a.out)
    if out.exists() and any(out.iterdir()):
        raise FileExistsError(f'Output directory exists and is not empty: {out}')
    out.mkdir(parents=True, exist_ok=True)

    import torch
    from torch.utils.data import DataLoader
    from transformers import AutoModelForCausalLM, AutoTokenizer, get_linear_schedule_with_warmup
    from peft import LoraConfig, get_peft_model

    if not torch.cuda.is_available():
        raise RuntimeError('CUDA GPU required for Qwen2.5-1.5B training')
    stage_start = time.perf_counter()
    random.seed(a.seed); np.random.seed(a.seed); torch.manual_seed(a.seed); torch.cuda.manual_seed_all(a.seed)
    dtype, dvalue = auto_dtype(torch, a.dtype)
    print('Selected dtype:', dtype, '| GPU:', torch.cuda.get_device_name(0), flush=True)
    tokenizer = AutoTokenizer.from_pretrained(a.base, use_fast=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = 'right'
    codec = AGNewsCodec(tokenizer, a.max_length)
    dataset = NewsDataset(tr, codec)
    sampler = torch.Generator().manual_seed(a.seed)
    loader = DataLoader(dataset, batch_size=a.batch_size, shuffle=True, generator=sampler,
                        collate_fn=codec.collate, num_workers=0, pin_memory=True)

    try:
        model = AutoModelForCausalLM.from_pretrained(a.base, torch_dtype=dvalue)
    except TypeError:
        model = AutoModelForCausalLM.from_pretrained(a.base, dtype=dvalue)
    model.config.use_cache = False
    lora_cfg = LoraConfig(r=a.rank, lora_alpha=a.alpha, lora_dropout=a.dropout,
                          target_modules=['q_proj', 'v_proj'], bias='none', task_type='CAUSAL_LM')
    model = get_peft_model(model, lora_cfg)
    if not a.no_gradient_checkpointing:
        model.gradient_checkpointing_enable()
        if hasattr(model, 'enable_input_require_grads'):
            model.enable_input_require_grads()
    device = torch.device('cuda:0')
    model.to(device)
    model.print_trainable_parameters()
    parameters = [x for x in model.parameters() if x.requires_grad]
    n_trainable = sum(x.numel() for x in parameters)
    if n_trainable == 0:
        raise RuntimeError('No trainable LoRA parameters!')
    optim = torch.optim.AdamW(parameters, lr=a.lr, weight_decay=a.weight_decay)
    steps_per_epoch = math.ceil(len(loader) / a.grad_accum)
    total_steps = steps_per_epoch * a.epochs
    warmup_steps = int(round(total_steps * a.warmup_ratio))
    sched = get_linear_schedule_with_warmup(optim, num_warmup_steps=warmup_steps,
                                            num_training_steps=total_steps)
    scaler = torch.amp.GradScaler('cuda', enabled=(dtype == 'fp16'))
    print(f'Training {len(dataset)} examples for {a.epochs} epoch(s); '
          f'{len(loader)} microbatches/epoch; {steps_per_epoch} optimizer steps/epoch; '
          f'gradient accumulation={a.grad_accum}.', flush=True)
    # Benchmark boundaries are CUDA-synchronized; initialization, training,
    # validation, and checkpoint saving are timed separately for transparency.
    torch.cuda.synchronize(device)
    t0 = time.perf_counter()
    setup_seconds = t0 - stage_start
    logs = []
    epoch_overhead = []
    opt_steps = 0
    train_seconds_total = 0.0
    validation_seconds_total = 0.0
    training_peak_allocated = 0.0
    training_peak_reserved = 0.0
    for epoch in range(a.epochs):
        torch.cuda.synchronize(device)
        torch.cuda.reset_peak_memory_stats(device)
        epoch_start = time.perf_counter()
        epoch_steps_start = opt_steps
        model.train()
        optim.zero_grad(set_to_none=True)
        total_loss_weighted, supervised_tokens, micro = 0.0, 0, 0
        for batch_idx, batch in enumerate(loader):
            batch = {k: v.to(device, non_blocking=True) for k, v in batch.items()}
            batch_sup_tokens = int((batch['labels'][:, 1:] != -100).sum().item())
            if batch_sup_tokens == 0:
                raise RuntimeError('Batch contains no supervised completion tokens')
            with amp_context(torch, dtype):
                loss = model(**batch).loss
            if not torch.isfinite(loss):
                raise FloatingPointError(f'Nonfinite training loss at epoch={epoch} batch={batch_idx}')
            total_loss_weighted += float(loss.detach().float().item()) * batch_sup_tokens
            supervised_tokens += batch_sup_tokens
            group_size = min(a.grad_accum, len(loader) - (batch_idx // a.grad_accum) * a.grad_accum)
            scaler.scale(loss / group_size).backward()
            micro += 1
            should_step = micro == a.grad_accum or batch_idx + 1 == len(loader)
            if should_step:
                scaler.unscale_(optim)
                torch.nn.utils.clip_grad_norm_(parameters, 1.0)
                scaler.step(optim)
                scaler.update()
                sched.step()
                optim.zero_grad(set_to_none=True)
                opt_steps += 1
                micro = 0
            if a.log_every and (batch_idx + 1) % a.log_every == 0:
                elapsed = time.perf_counter() - t0
                print(f'epoch {epoch+1}/{a.epochs} | batch {batch_idx+1}/{len(loader)} | '
                      f'opt-step {opt_steps}/{total_steps} | '
                      f'loss {float(loss.detach().float().item()):.4f} | elapsed {elapsed:.0f}s', flush=True)
        torch.cuda.synchronize(device)
        epoch_train_seconds = time.perf_counter() - epoch_start
        epoch_allocated_gib = torch.cuda.max_memory_allocated(device) / 2**30
        epoch_reserved_gib = torch.cuda.max_memory_reserved(device) / 2**30
        training_peak_allocated = max(training_peak_allocated, epoch_allocated_gib)
        training_peak_reserved = max(training_peak_reserved, epoch_reserved_gib)
        train_seconds_total += epoch_train_seconds
        epoch_loss = total_loss_weighted / supervised_tokens
        print(f'Epoch {epoch+1} complete: masked-token NLL={epoch_loss:.5f}; '
              f'train wall={epoch_train_seconds:.2f}s; '
              f'peak allocated={epoch_allocated_gib:.3f} GiB; '
              f'peak reserved={epoch_reserved_gib:.3f} GiB', flush=True)
        validation = None
        epoch_validation_seconds = 0.0
        if not a.eval_last_only or epoch + 1 == a.epochs:
            torch.cuda.synchronize(device)
            val_start = time.perf_counter()
            validation = evaluate(model, codec, va, torch, dtype, device, cap=a.eval_max, show_every=100)
            torch.cuda.synchronize(device)
            epoch_validation_seconds = time.perf_counter() - val_start
            validation_seconds_total += epoch_validation_seconds
            print(f'Validation accuracy={validation["accuracy"]:.4f} | '
                  f'macro-F1={validation["macro_f1"]:.4f} | n={validation["n"]} | '
                  f'wall={epoch_validation_seconds:.2f}s', flush=True)
            pred_path = out / f'validation_predictions_epoch_{epoch+1}.csv'
            pd.DataFrame({'sample_id': validation.pop('sample_ids'),
                          'true_label': validation.pop('truth'),
                          'pred_label': validation.pop('predictions')}).to_csv(pred_path, index=False)
            validation.pop('scores')
        logs.append({'epoch': epoch+1, 'masked_token_nll': epoch_loss,
                     'validation': validation, 'optimizer_steps_cumulative': opt_steps})
        epoch_overhead.append({
            'epoch': epoch + 1,
            'examples_seen': len(dataset),
            'microbatches': len(loader),
            'optimizer_steps': opt_steps - epoch_steps_start,
            'training_wall_seconds': round(epoch_train_seconds, 4),
            'validation_wall_seconds': round(epoch_validation_seconds, 4),
            'peak_gpu_training_allocated_gib': round(epoch_allocated_gib, 4),
            'peak_gpu_training_reserved_gib': round(epoch_reserved_gib, 4),
            'masked_token_nll': float(epoch_loss),
        })
        # Write an epoch-wise log even if a later epoch is interrupted.
        pd.DataFrame(epoch_overhead).to_csv(out / 'epoch_overhead.csv', index=False)

    torch.cuda.synchronize(device)
    save_start = time.perf_counter()
    model.eval()
    model.save_pretrained(out / 'adapter', safe_serialization=True)
    tokenizer.save_pretrained(out / 'adapter')
    torch.cuda.synchronize(device)
    save_seconds = time.perf_counter() - save_start
    active_seconds = time.perf_counter() - t0
    overhead = {
        'method': 'LoRA', 'is_pilot': bool(a.max_train_records or a.eval_max),
        'measurement_protocol': 'time.perf_counter with CUDA synchronization before/after each training epoch and validation; PyTorch CUDA allocator peak reset each training epoch',
        'gpu': torch.cuda.get_device_name(device),
        'gpu_total_gib': round(torch.cuda.get_device_properties(device).total_memory / 2**30, 3),
        'cuda_version': torch.version.cuda,
        'data_sha256': sha_file(root / 'target_train.csv'),
        'model': a.base,
        'seed': a.seed, 'dtype': dtype,
        'gradient_checkpointing': not a.no_gradient_checkpointing,
        'train_count': len(dataset), 'epochs': a.epochs, 'max_length': a.max_length,
        'microbatch_size': a.batch_size, 'gradient_accumulation': a.grad_accum,
        'effective_batch_size': a.batch_size * a.grad_accum,
        'optimizer_steps': opt_steps,
        'training_wall_seconds': round(train_seconds_total, 4),
        'training_wall_hours': round(train_seconds_total / 3600, 5),
        'validation_wall_seconds': round(validation_seconds_total, 4),
        'checkpoint_save_wall_seconds': round(save_seconds, 4),
        'setup_wall_seconds': round(setup_seconds, 4),
        'wall_seconds_after_setup': round(active_seconds, 4),
        'wall_seconds_per_1000_training_examples': round(train_seconds_total * 1000 / (len(dataset) * a.epochs), 4),
        'seconds_per_optimizer_step': round(train_seconds_total / opt_steps, 4),
        'peak_gpu_training_allocated_gib': round(training_peak_allocated, 4),
        'peak_gpu_training_reserved_gib': round(training_peak_reserved, 4),
        'gpu_memory_note': 'allocated=peak live tensors managed by PyTorch; reserved=peak CUDA caching allocator reservation, not full-device nvidia-smi memory',
        'validation_schedule': 'final_epoch_only' if a.eval_last_only else 'each_epoch',
        'epoch_overhead': epoch_overhead,
        'training_finished': True,
    }
    (out / 'overhead_summary.json').write_text(json.dumps(overhead, indent=2), encoding='utf-8')
    print(f'OVERHEAD | training={train_seconds_total:.2f}s '
          f'({train_seconds_total / 3600:.3f}h) | validation={validation_seconds_total:.2f}s | '
          f'peak GPU allocated={training_peak_allocated:.3f} GiB | '
          f'peak GPU reserved={training_peak_reserved:.3f} GiB', flush=True)
    result = {
        'protocol': 'AG News causal-LM class-completion masked loss, original controlled DeMIA study',
        'is_pilot': bool(a.max_train_records or a.eval_max),
        'model': a.base, 'method': 'LoRA', 'target_train_csv_sha256': sha_file(root / 'target_train.csv'),
        'split_manifest_sha256': sha_file(root / 'split_manifest.json'),
        'seed': a.seed, 'train_count': len(dataset), 'val_count': len(va),
        'tokenizer_vocab_size': len(tokenizer), 'dtype': dtype,
        'max_length': a.max_length, 'article_truncation': 'first N tokens after fixed instruction; class suffix preserved',
        'tokenization': 'segment-wise (instruction + article + suffix + completion)',
        'loss_mask': 'label completion and EOS tokens only',
        'lora': {'rank': a.rank, 'alpha': a.alpha, 'dropout': a.dropout, 'target_modules': ['q_proj', 'v_proj']},
        'optimizer': {'name': 'AdamW', 'lr': a.lr, 'weight_decay': a.weight_decay,
                      'grad_accum': a.grad_accum, 'microbatch': a.batch_size,
                      'warmup_steps': warmup_steps, 'global_clip': 1.0},
        'n_trainable_params': n_trainable, 'epochs': a.epochs,
        'microbatches_per_epoch': len(loader), 'optimizer_steps_total': opt_steps,
        'elapsed_seconds': round(active_seconds, 2),
        'peak_gpu_allocated_gib': round(training_peak_allocated, 3),
        'peak_gpu_reserved_gib': round(training_peak_reserved, 3),
        'training_wall_seconds': round(train_seconds_total, 4),
        'validation_wall_seconds': round(validation_seconds_total, 4),
        'checkpoint_save_wall_seconds': round(save_seconds, 4),
        'overhead_summary_file': 'overhead_summary.json',
        'validation_schedule': 'final_epoch_only' if a.eval_last_only else 'each_epoch',
        'training_log': logs,
        'software': {'python': sys.version.split()[0], 'torch': torch.__version__,
                     'transformers': __import__('transformers').__version__,
                     'peft': __import__('peft').__version__}
    }
    (out / 'run_summary.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print('PASS: LoRA trained and adapter saved:', (out / 'adapter').resolve(), flush=True)
    print('Summary:', (out / 'run_summary.json').resolve(), flush=True)


if __name__ == '__main__':
    main()
