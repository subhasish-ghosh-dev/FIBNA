# XSum summarization — full Qwen2.5-1.5B pipeline

**Purpose:** A controlled five-epoch comparison of LoRA, record-level DP-LoRA, and FIBNA on **one-sentence abstractive summarization (XSum)**, with ROUGE and three membership inference attack scores. This is a **new summarization experiment**, independent of previously completed AG News classification runs.

## Launch with one Windows CMD file

Extract this ZIP directly into a new folder under:

`D:\Subhasish\projects\med_text_gan\demia_multitask\xsum_qwen_pipeline`

Open **Anaconda Prompt**, then:

```bat
conda activate gpu_env
cd /d D:\Subhasish\projects\med_text_gan\demia_multitask\xsum_qwen_pipeline
run_xsum_all.cmd
```

You can also double-click `run_xsum_all.cmd` from an Anaconda-configured shell. The script activates `gpu_env` itself, but `conda` must be available on PATH.

**This does not run instantly**. It downloads XSum and the pretrained model if not cached, trains three models for five epochs, produces summaries for 1,000 validation + 2,000 test articles per model, and scores 5,000 attack candidates against base/target checkpoints with ICP probing. Total workload may be substantial on a 16-GB GPU; no wall-clock estimate is implied.

Before launching everything, recommended **optional** GPU smoke training:

```bat
run_xsum_smoke.cmd
```

The smoke run saves to separate `_smoke` directories and will not be treated as final results. The main launcher runs `test_protocol.py` and `test_report_synthetic.py` automatically.

## Dependencies

Uses your installed Python 3.11 / CUDA `gpu_env`. The scripts import `torch`, `transformers`, `peft`, `opacus`, `datasets`, `pandas`, `numpy`, `scikit-learn`, `sentence-transformers`, `rouge-score`, `safetensors`, and `tqdm`. If needed, install a missing package into **gpu_env**; e.g. `python -m pip install rouge-score` for ROUGE or `python -m pip install sentence-transformers` for ICP retrieval. Do not reinstall PyTorch unless your environment actually needs it.

XSum source: [EdinburghNLP/xsum on Hugging Face](https://huggingface.co/datasets/EdinburghNLP/xsum). Official splits are **204,045 train / 11,332 validation / 11,334 test**, with `document`, `summary`, and `id` fields. This pipeline uses an immutable deterministic subset, not the entire original train split.

## Fixed dataset protocol

`prepare_xsum.py` creates `xsum_qwen15_data/` with SHA-256 manifest and these datasets:

| File | Use | Count |
| --- | --- | ---: |
| `target_train.csv` | Fine-tune every method | 10,000 |
| `utility_val.csv` | Validation ROUGE | 1,000 |
| `utility_test.csv` | Final test ROUGE | 2,000 |
| `reference_pool.csv` | Independent ICP reference demonstrations (official validation) | 1,000 |
| `attack_train.csv` | Reserved attack-training set (not used by the training-free attacks) | 1,000 members + 1,000 nonmembers |
| `attack_calibration.csv` | Calibrate attack thresholds | 500 members + 500 nonmembers |
| `attack_test.csv` | Held-out attack reporting | 1,000 members + 1,000 nonmembers |

Members come only from the fine-tuning target set. **Nonmembers are sampled from unused examples in the original XSum training split**, not from XSum test, reducing a split-origin confound. The preprocessor removes whitespace-normalized duplicate documents across train/validation/test. Original official validation/test stay held out from training. Dataset bytes are SHA-256 checked by every downstream script. Do not move files from one experiment into another.

## Training hyperparameters

| Setting | LoRA | DP-LoRA | FIBNA |
| --- | --- | --- | --- |
| Base | Qwen/Qwen2.5-1.5B | same | same |
| Seed | 42 | 42 | 42 |
| Epochs | **5** | **5** | **5** |
| Max training tokens | 512 | 512 | 512 |
| Max reference-summary tokens | 64 (+ EOS) | same | same |
| Supervised objective | Summary completion + EOS only | same | same |
| LoRA rank/alpha/dropout | 8 / 16 / .05 | same | same |
| Modules | q_proj / v_proj | same | same |
| Optimizer | AdamW lr=1e-4, wd=.01 | same | same |
| Microbatch / accumulation | 2 / 8 | per-example gradients | 2 / 8 |
| Logical batch | 16 | expected 16, Poisson | 16 |
| DP | none | target ε=10, δ=1e-5, C=1, PRV | **none** |
| SHAP attribution | none | none | 8 grouped article features, 100 coalitions, WLS every **125** optimizer steps |
| Noise | none | Gaussian on per-example clipped LoRA gradients | Feature-dependent Gaussian on separate FP32 LM output head each optimizer step |

For 10,000 records, 2×8 logical batch, and 5 epochs: **625 optimizer updates per epoch, 3,125 total updates**. DP-LoRA uses Poisson sampling with the same expected number of updates. The DP implementation clips each record's gradient across *all trainable LoRA parameters*, then adds independent Gaussian noise to the sum and divides by expected batch size. Opacus PRV is used to calibrate/account noise; the RNG is **not cryptographic**. FIBNA is not differential privacy; `epsilon_code` is only a regularization scaling constant.

**FIBNA-specific reproducibility note:** A full-vocabulary KernelSHAP weighted least-squares explanation of grouped article-token features is refreshed every 125 updates. This is a **budgeted Qwen adaptation**, not per-minibatch Kernel SHAP. The FP32 LM head is untied/frozen and receives noise; its dense delta (`lm_head_delta.safetensors`) is saved **in addition** to the PEFT adapter. This architecture and precision differ from the ordinary LoRA/DP-LoRA controls and must be documented in publications. All full-checkpoint evaluation routines load the delta; adapter-only FIBNA evaluation is forbidden.

## Summarization utility

`eval_xsum.py` generates with deterministic four-beam decoding, `max_new_tokens=64`, no sampling. Reports **ROUGE-1, ROUGE-2, ROUGE-L**, Porter stemmer, as the mean of per-example F1 scores multiplied by 100. Each split's predictions and a 1,000-bootstrap 95% CI are saved. These values are not necessarily numerically interchangeable with every ROUGE implementation/aggregation protocol; always report the setting.

Outputs:

```
xsum_lora_qwen15_5ep/
  adapter/
  run_summary.json
  overhead_summary.json
  epoch_overhead.csv
  utility_val/{predictions.csv,test_metrics.json,...}
  utility_test/{predictions.csv,test_metrics.json,test_results_table.tex}
  three_mia/{target_tokens.csv,base_tokens.csv,icp_scores.csv,attack_results.csv,...}
xsum_dp_lora_qwen15_5ep/
  ...
  privacy_progress.json
xsum_fibna_qwen15_5ep/
  adapter/
  lm_head_delta.safetensors
  fibna_checkpoint.json
  shap_events.csv
  noise_events.csv
  ...
xsum_qwen15_manuscript_results/
  xsum_utility_overhead.csv
  xsum_mia_results.csv
  xsum_utility_table.tex
  xsum_mia_table.tex
```

## Membership inference

Three attacks are evaluated **on the same frozen per-method membership candidates**:

- **EZ-MIA:** positive/negative fine-tuning log-likelihood movement on **target-model error-zone positions**, with a declared `1e-12` zero-denominator convention.
- **Min-K%++:** bottom-20% normalized token log-probability; normalization uses the target-model *categorical* distribution of log-probabilities (not vocabulary-uniform statistics).
- **ICP-MIA:** a **similarity-based reference-pool probing adaptation**. Sentence-transformer embeddings retrieve three similar **independent validation** documents and their gold summaries as demonstrations; the score is plain true-summary completion mean log-likelihood minus the maximum demonstrated likelihood.

EZ-MIA and Min-K%++ include **full-sequence** primary statistics and **summary-completion-only** sensitivity versions. Note that the model is trained only on the summary completion; the full-sequence score may mix in article/instruction-token difficulty. The 1% target-FPR threshold is selected using only the **500 nonmembers from `attack_calibration.csv`**, then evaluated on the disjoint held-out 1,000-member/1,000-nonmember test set. The report includes **observed FPR**, ROC-AUC, TPR, score coverage and bootstrap CIs. Calibration is not confused with observed FPR.

**Paper-alignment warning:** These are original, task-adapted implementations of the defining statistics, **not a verified byte-for-byte reproduction** of the official EZ-MIA or ICP-MIA repositories. The ICP reference demonstration scheme and zero-denominator convention are explicit adaptations. Do not claim the unmodified official baselines ran without checking authors' exact implementation. The summarization task uses the same methodology *for all three fine-tuning methods*.

Official references:

- [EZ-MIA code](https://github.com/JetBrains-Research/ez-mia)
- [ICP-MIA code](https://github.com/RPI-DSPlab/ICP-MIA)
- [Min-K%++ (ICLR 2025)](https://openreview.net/) (consult actual paper for formal citation)

## Recovery after interruption

**Dataset preparation:** If `split_manifest.json` and all CSVs exist, rerunning prep validates hashes and reuses them. It does **not** resample.

**Training:** A completed checkpoint matching all hyperparameters is safely skipped. An **interrupted training directory cannot currently be resumed mid-epoch**: the trainer intentionally stops instead of accidentally treating partial weights as a finished experiment. Move/delete **only that incomplete method's output** and restart that method. Reproducible final statistics require a completed five-epoch run.

**Utility generation / MIA scoring:** Already processed records are saved in CSV and stages resume **when checkpoint and protocol hashes match**. An error in the scoring protocol aborts rather than silently mixing cached values. Do not delete `*.provenance.json` just to suppress a mismatch.

**Final report:** Strictly refuses missing methods/utility or attack scores, pilot results, modified data, or incomplete five-epoch checkpoints. Synthetic tests produce temporary files only and **are never copied into user-results folders**.

## GPU memory note

Peak GPU **allocated** and **reserved** memory and synchronized training time are recorded. The FIBNA FP32 head can increase activation/weight memory considerably, especially for 512-token sequences. On a 16 GiB GPU, run `run_xsum_smoke.cmd` first. If out of memory, reduce `--batch-size` from 2 to 1 and increase `--grad-accum` from 8 to 16 **consistently for LoRA and FIBNA**; preserve a logical batch of 16. That is a *new measured configuration* and should be reported as such. Incomplete outputs must be moved before a restart.
