#!/usr/bin/env python3
"""GPT-2-Large MeDAL membership-inference audit for LoRA, DP-LoRA and FIBNA.

Native attacks implemented in this file:
  PPL/loss, Min-K%, Min-K%++, Neighborhood (T5 infilling variant),
  EZ-MIA (base-reference version), reference log-likelihood ratio,
  zlib-normalized log-likelihood, and entropy/confidence attack.

SPV-MIA, DF-MIA and LiRA are NOT implemented by the above substitutes.
Their published methods require reference-model training or shadow-model
statistics. Add scores obtained with faithful independent implementations
using --external-scores; those rows are then evaluated identically.

The output is an *empirical fine-tuning membership audit*, not a DP proof.
"""
from __future__ import annotations

import argparse
import csv
import gc
import hashlib
import json
import math
import os
import shutil
import urllib.request
import zipfile
import re
import sys
import warnings
import zlib
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

BASE_NAME = "gpt2-large"
METHODS = ("LoRA", "DP-LoRA", "FIBNA")
CORE_ATTACKS = [
    "PPL", "Min-K%", "Min-K%++", "Neighborhood", "EZ-MIA",
    "Reference-ratio", "ZLIB", "Entropy",
]
EXTERNAL_ATTACKS = ["SPV-MIA", "DF-MIA", "LiRA"]
ALL_ATTACKS = CORE_ATTACKS + EXTERNAL_ATTACKS
SCORE_MAP = {
    "PPL": "score_ppl", "Min-K%": "score_mink", "Min-K%++": "score_minkpp",
    "Neighborhood": "score_neighbor", "EZ-MIA": "score_ez",
    "Reference-ratio": "score_reference", "ZLIB": "score_zlib",
    "Entropy": "score_entropy",
}
SCORE_FIELDS = [
    "sample_id", "label", "split", "n_tokens", "score_ppl", "score_mink",
    "score_minkpp", "score_neighbor", "score_ez", "score_reference",
    "score_zlib", "score_entropy", "n_neighbors",
]
REF_FIELDS = ["sample_id", "ref_mean_logp", "ref_token_logps_json"]
NEIGH_FIELDS = ["sample_id", "neighbor_idx", "neighbor_text"]
INVALID_NEIGH_FIELDS = ["sample_id", "neighbor_idx", "reason"]


def get_args():
    ap = argparse.ArgumentParser(
        description="Resumable MIA evaluation on already fine-tuned GPT-2-Large checkpoints."
    )
    ap.add_argument("--dataset", default="McGill-NLP/medal", help="Hugging Face dataset ID")
    ap.add_argument("--hf-revision", default=None, help="Optional fixed HF dataset revision")
    ap.add_argument("--hf-loader", choices=["hf-zip", "zenodo-csv", "auto", "legacy", "parquet", "local-csv"], default="hf-zip",
                    help="hf-zip downloads the original HF ZIP and extracts CSVs; zenodo-csv downloads split CSVs individually from Zenodo; local-csv reads existing files; legacy requires datasets<4")
    ap.add_argument("--local-data-dir", default=None,
                    help="Directory containing MeDAL train.csv/test.csv/valid.csv for local-csv, or destination for hf-zip extraction. Default for hf-zip is ./medal_original_splits.")
    ap.add_argument("--train-size", type=int, default=53000,
                    help="Exact first N training records AFTER Hugging Face shuffle(seed=42)")
    ap.add_argument("--test-size", type=int, default=1000,
                    help="Exact first N test records AFTER shuffle(seed=42)")
    ap.add_argument("--extra-validation-nonmembers", type=int, default=0,
                    help="Additional shuffled validation records for stronger low-FPR estimation; verify none used in fine-tuning")
    ap.add_argument("--train-shuffle-seed", type=int, default=42)
    ap.add_argument("--test-shuffle-seed", type=int, default=42)
    ap.add_argument("--population", choices=["balanced","all"], default="balanced",
                    help="balanced draws equal numbers from both classes; all keeps all eligible records")
    ap.add_argument("--prepare-only", action="store_true", help="Download/select data, audit overlap, save sample manifest; no inference")
    ap.add_argument("--lora", default="./lora_medal_gpt2")
    ap.add_argument("--dp-lora", default="lora_dp_medal_gpt2.pth")
    ap.add_argument("--fibna", default="fi_lora_dp_high_medal_gpt.pth")
    ap.add_argument("--dp-alpha", type=int, default=32)
    ap.add_argument("--fibna-alpha", type=int, default=32)
    ap.add_argument("--dp-dropout", type=float, default=0.1)
    ap.add_argument("--fibna-dropout", type=float, default=0.1)
    ap.add_argument("--target-modules", default="c_attn,c_proj")
    ap.add_argument("--output", default="mia_gpt2_medal_results")
    ap.add_argument("--max-per-class", type=int, default=0,
                    help="Max examples per class after filtering; 0 means all available within chosen --population.")
    ap.add_argument("--require-per-class", type=int, default=0,
                    help="Fail before inference unless exactly this many unique eligible members AND nonmembers are selected; 0 disables check.")
    ap.add_argument("--min-tokens", type=int, default=32)
    ap.add_argument("--max-tokens", type=int, default=128)
    ap.add_argument("--min-cal-neg", type=int, default=100,
                    help="Minimum independent nonmember calibration sequences.")
    ap.add_argument("--calibration-fraction", type=float, default=0.40)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--k-percent", type=float, default=20.0)
    ap.add_argument("--neighbors", type=int, default=5,
                    help="Number of T5-infilled neighbors; 0 skips Neighborhood attack.")
    ap.add_argument("--mask-model", default="t5-small")
    ap.add_argument("--mask-span-words", type=int, default=2)
    ap.add_argument("--save-every", type=int, default=25)
    ap.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda"])
    ap.add_argument("--bootstrap", type=int, default=300)
    ap.add_argument("--external-scores", default=None,
                    help="Optional CSV: sample_id,model,attack,score (faithful SPV/DF/LiRA).")
    ap.add_argument("--report-only", action="store_true",
                    help="Only load saved CSVs, compute metrics/plots; no transformers/torch.")
    ap.add_argument("--no-plot", action="store_true")
    ap.add_argument("--no-auto-report", action="store_true",
                    help="Disable automatic child-process report after inference.")
    ap.add_argument("--overlap-policy", choices=["exclude-nonmembers", "error"],
                    default="exclude-nonmembers",
                    help="For duplicate train/test texts (including same truncated token sequence), exclude ambiguous nonmember candidates and audit them; or raise an error.")
    ap.add_argument("--trust-membership", action="store_true",
                    help="Affirm all 3 checkpoints used first 53k training rows after shuffle(seed=42); held-out test/validation untouched.")
    return ap.parse_args()


def sha_text(s):
    normalized = re.sub(r"\s+", " ", s).strip().casefold()
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()


def write_metadata(args, out):
    conf = dict(vars(args))
    (out / "run_config.json").write_text(json.dumps(conf, indent=2), encoding="utf-8")


IMMUTABLE_FLAGS = [
    "dataset", "hf_revision", "hf_loader", "local_data_dir", "train_size", "test_size", "extra_validation_nonmembers",
    "train_shuffle_seed", "test_shuffle_seed", "population", "max_per_class", "require_per_class", "min_tokens", "max_tokens",
    "calibration_fraction", "seed", "k_percent", "neighbors", "mask_model", "mask_span_words",
    "lora", "dp_lora", "fibna", "dp_alpha", "fibna_alpha", "target_modules",
]


def verify_run_config(args, out):
    conf_path = out / "run_config.json"
    current = vars(args)
    if conf_path.exists():
        previous = json.loads(conf_path.read_text(encoding="utf-8"))
        changed = {k: (previous.get(k), current.get(k)) for k in IMMUTABLE_FLAGS
                   if previous.get(k) != current.get(k)}
        if changed:
            raise RuntimeError(f"Resume configuration changed: {changed}. Use a NEW --output folder.")
    else:
        write_metadata(args, out)


def read_medal_rows(args, out):
    """Cache exact training-era shuffle selections, not the full train split.

    The cache is replayed on resume, so new HF dataset library versions or
    dataset revisions cannot silently change membership candidates.
    """
    cache = out / "hf_selected_records.csv"
    if cache.exists():
        df = pd.read_csv(cache, dtype={"text": str}, keep_default_na=False)
        needed = {"source_split", "shuffled_position", "text"}
        if not needed.issubset(df):
            raise RuntimeError(f"{cache} missing columns {needed-set(df.columns)}")
        members = df.loc[df.source_split == "train", "text"].tolist()
        nonmembers = df.loc[df.source_split.isin(["test", "validation"]), "text"].tolist()
        if len(members)!=args.train_size or sum(df.source_split.eq("test"))!=args.test_size or sum(df.source_split.eq("validation"))!=args.extra_validation_nonmembers:
            raise RuntimeError("Cached source counts do not match --train-size/--test-size/--extra-validation-nonmembers")
        print(f"Reusing saved HF selection: {cache} ({len(members)} members, {len(nonmembers)} nonmembers)")
        return members, nonmembers

    try:
        from datasets import load_dataset
    except ImportError as e:
        raise RuntimeError("Install datasets and pyarrow: pip install datasets pyarrow") from e

    def get_split(name):
        # Original MeDAL archive is hosted in the HF dataset repository itself.
        # The legacy medal.py builder used precisely this ZIP, so reading its CSV
        # entries avoids executing the unsupported builder script in datasets>=4.
        if args.hf_loader == "zenodo-csv":
            root = Path(args.local_data_dir).expanduser() if args.local_data_dir else Path("medal_original_splits")
            root.mkdir(parents=True, exist_ok=True)
            filename = {"train": "train.csv", "test": "test.csv", "validation": "valid.csv"}[name]
            target = root / filename
            # Original authors' published individual CSV files (Zenodo v4).
            # Expected sizes and MD5 hashes from official repository metadata.
            official = {
                "train.csv": (3541556520, "28d5c3e0b4d80f95b7e20cebfc783379"),
                "test.csv": (1180152075, "7ba9fd2e9fa5b4069370bafa42418a85"),
                "valid.csv": (1180795804, "28e450e8c5d5542c6b3ba98876adf621"),
            }
            expected_len, expected_md5 = official[filename]
            partial = target.with_suffix(target.suffix + ".partial")
            if target.is_file() and target.stat().st_size == expected_len:
                print(f"Reusing {target} ({expected_len:,} bytes)")
            else:
                if target.exists():
                    raise RuntimeError(f"Existing {target} has unexpected size; move it before redownloading.")
                source_url = f"https://zenodo.org/records/4482922/files/{filename}?download=1"
                offset = partial.stat().st_size if partial.exists() else 0
                if offset > expected_len:
                    raise RuntimeError(f"Partial {filename} exceeds published file size")
                headers = {"User-Agent": "MeDAL-research-evaluation/1.0"}
                if offset:
                    headers["Range"] = f"bytes={offset}-"
                print(f"Downloading original {filename} individually from Zenodo (resume offset {offset:,} bytes)")
                req = urllib.request.Request(source_url, headers=headers)
                with urllib.request.urlopen(req, timeout=90) as src:
                    code = src.getcode()
                    if offset and code != 206:
                        print("Server did not honor HTTP range; restarting this CSV download")
                        offset = 0
                    if offset and code == 206:
                        content_range = src.headers.get("Content-Range", "")
                        if not content_range.startswith(f"bytes {offset}-"):
                            raise RuntimeError(f"Unexpected Content-Range: {content_range!r}")
                    with partial.open("ab" if offset else "wb") as dst:
                        total = offset
                        next_log = ((total // (256 * 1024**2)) + 1) * (256 * 1024**2)
                        while True:
                            chunk = src.read(4 * 1024 * 1024)
                            if not chunk:
                                break
                            dst.write(chunk)
                            total += len(chunk)
                            if total >= next_log:
                                print(f"  {filename}: {total / 1024**3:.2f}/{expected_len / 1024**3:.2f} GiB")
                                next_log += 256 * 1024**2
                if partial.stat().st_size != expected_len:
                    raise RuntimeError(f"Incomplete {filename}: {partial.stat().st_size:,}/{expected_len:,} bytes. Rerun to resume.")
                digest = hashlib.md5()
                with partial.open("rb") as src:
                    for chunk in iter(lambda: src.read(8 * 1024 * 1024), b""):
                        digest.update(chunk)
                if digest.hexdigest().lower() != expected_md5:
                    raise RuntimeError(f"Checksum mismatch for {filename}. Do not use this file; check Zenodo version.")
                os.replace(partial, target)
                print(f"Verified original Zenodo CSV checksum: {filename}")
            return load_dataset("csv", data_files={name: str(target.resolve())}, split=name)
        if args.hf_loader == "hf-zip":
            try:
                from huggingface_hub import hf_hub_download
            except ImportError as exc:
                raise RuntimeError("Install huggingface_hub: python -m pip install huggingface_hub") from exc
            root = Path(args.local_data_dir).expanduser() if args.local_data_dir else Path("medal_original_splits")
            root.mkdir(parents=True, exist_ok=True)
            filename = {"train": "train.csv", "test": "test.csv", "validation": "valid.csv"}[name]
            target = root / filename
            # Using the same original pretrain archive as the historic HF medal.py loader.
            print("Obtaining original MeDAL pretrain_subset.zip from Hugging Face cache ...")
            archive_path = hf_hub_download(
                repo_id=args.dataset, repo_type="dataset",
                filename="data/pretrain_subset.zip",
                revision=args.hf_revision or "main",
            )
            with zipfile.ZipFile(archive_path, "r") as archive:
                matches = [e for e in archive.infolist()
                           if not e.is_dir() and Path(e.filename).name == filename]
                if len(matches) != 1:
                    raise RuntimeError(f"Expected one {filename} in original MeDAL ZIP, found {len(matches)}")
                entry = matches[0]
                if target.is_file() and target.stat().st_size == entry.file_size:
                    print(f"Reusing original MeDAL split: {target} ({entry.file_size:,} bytes)")
                else:
                    if target.exists():
                        raise RuntimeError(
                            f"Existing CSV {target} has size {target.stat().st_size:,} bytes, "
                            f"but archive contains {entry.file_size:,}. Move the existing file "
                            "or select another --local-data-dir; it will not be overwritten."
                        )
                    partial = target.with_suffix(target.suffix + ".partial")
                    try:
                        print(f"Extracting original {filename} ({entry.file_size / (1024 ** 3):.2f} GiB) to {target}")
                        with archive.open(entry, "r") as src, partial.open("wb") as dst:
                            shutil.copyfileobj(src, dst, length=4 * 1024 * 1024)
                        if partial.stat().st_size != entry.file_size:
                            raise RuntimeError(f"Incomplete extraction for {filename}")
                        os.replace(partial, target)
                    finally:
                        if partial.exists():
                            partial.unlink()
            # Use the supported built-in CSV builder. File ordering and split
            # membership match the original archive; the shuffle seed is applied
            # below exactly as in the fine-tuning code.
            print(f"Loading original MeDAL CSV split: {target}")
            return load_dataset("csv", data_files={name: str(target.resolve())}, split=name)
        # Use the ORIGINAL HF dataset builder whenever possible. Converting to
        # Parquet/CSV may change ordering and therefore which shuffled rows
        # count as members of the already-trained target checkpoints.
        if args.hf_loader == "local-csv":
            if not args.local_data_dir:
                raise ValueError("With --hf-loader local-csv, supply --local-data-dir pointing to train.csv, test.csv and valid.csv")
            filename = {"train": "train.csv", "test": "test.csv", "validation": "valid.csv"}[name]
            source = Path(args.local_data_dir).expanduser() / filename
            if not source.is_file():
                raise FileNotFoundError(f"Original MeDAL split file not found: {source}")
            print(f"Loading original MeDAL CSV: {source}")
            # A CSV builder cannot execute removed HF remote Python scripts.
            # The official MeDAL builder reads the same CSV rows in file order.
            return load_dataset("csv", data_files={name: str(source.resolve())}, split=name)

        common = dict(path=args.dataset, split=name)
        if args.hf_revision:
            common["revision"] = args.hf_revision
        try:
            import datasets as hf_datasets
            major = int(str(hf_datasets.__version__).split(".")[0])
        except (ImportError, ValueError):
            major = 0
        if args.hf_loader in ("auto", "legacy"):
            if major >= 4 and args.hf_loader == "legacy":
                raise RuntimeError(
                    "MeDAL uses medal.py, which datasets >=4 cannot load. "
                    "To reproduce your original training selection, run: "
                    "python -m pip install 'datasets==3.6.0'  "
                    "and rerun the SAME command. Alternatively, download the original "
                    "train.csv/test.csv/valid.csv files and use --hf-loader local-csv "
                    "--local-data-dir YOUR_DATA_DIRECTORY (with a new --output folder)."
                )
            if major < 4:
                try:
                    return load_dataset(**common, trust_remote_code=True)
                except Exception as exc:
                    if args.hf_loader == "legacy":
                        raise
                    warnings.warn(
                        f"Original MeDAL loader failed for {name}: {str(exc)[:250]}; "
                        "trying the alternate Parquet revision, which must be "
                        "audited against the exact training membership selection."
                    )
            else:
                warnings.warn(
                    "datasets>=4 does not support medal.py; trying the alternate "
                    "HF Parquet revision. If no Parquet revision exists, install "
                    "datasets==3.6.0 or use --hf-loader local-csv."
                )
        # Parquet export may not be available for all dataset repositories.
        common["revision"] = args.hf_revision or "refs/convert/parquet"
        try:
            return load_dataset(**common)
        except Exception as exc:
            raise RuntimeError(
                f"Could not load MeDAL {name} via the HF Parquet revision. "
                "For faithful training membership use datasets==3.6.0 "
                "with --hf-loader legacy; or the original CSVs with "
                "--hf-loader local-csv --local-data-dir PATH. "
                f"Original error: {type(exc).__name__}: {exc}"
            ) from exc

    selections = [("train", args.train_size, args.train_shuffle_seed),
                  ("test", args.test_size, args.test_shuffle_seed)]
    if args.extra_validation_nonmembers:
        selections.append(("validation", args.extra_validation_nonmembers, args.test_shuffle_seed))
    records=[]
    for split,n,seed in selections:
        print(f"Loading MeDAL {split}; using shuffle(seed={seed}).select(range({n}))")
        ds = get_split(split)
        # The original MeDAL CSVs use uppercase headers:
        # ABSTRACT_ID,TEXT,LOCATION,LABEL.  The published medal.py loader
        # maps CSV column 1 (TEXT) directly to its lowercase feature 'text'.
        # Preserve each original text verbatim and the source row ordering.
        if "text" not in ds.column_names:
            text_columns = [c for c in ds.column_names
                            if isinstance(c, str) and c.strip().casefold() == "text"]
            if len(text_columns) != 1:
                raise ValueError(
                    f"MeDAL split {split}: cannot uniquely locate TEXT/text "
                    f"column in {ds.column_names}. Expected original MeDAL "
                    "pretrain_subset.zip CSV files with ABSTRACT_ID,TEXT,LOCATION,LABEL."
                )
            original_col = text_columns[0]
            ds = ds.rename_column(original_col, "text")
            print(f"  Normalized original MeDAL column {original_col!r} -> 'text' "
                  "(same text mapping as medal.py; no text transformation)")
        # Only text is used for MIA; exclude irrelevant metadata without
        # changing the dataset order or the deterministic shuffle.
        ds = ds.select_columns(["text"])
        if n > len(ds):
            raise ValueError(f"Requested {n} rows from {split}, only {len(ds)} available")
        selected = ds.shuffle(seed=seed).select(range(n))
        texts = selected["text"]
        records.extend({"source_split": split, "shuffled_position": i,
                        "text": (value if isinstance(value,str) else "")}
                       for i,value in enumerate(texts))
        del selected,ds
    # Atomic replace prevents a partial CSV from being reused after interruption.
    temp = cache.with_suffix(".partial.csv")
    pd.DataFrame(records,columns=["source_split","shuffled_position","text"]).to_csv(temp,index=False)
    os.replace(temp,cache)
    members=[r["text"] for r in records if r["source_split"]=="train"]
    nonmembers=[r["text"] for r in records if r["source_split"]!="train"]
    print(f"Cached exact selections to {cache}.")
    return members,nonmembers


def choose_data(args, out, tokenizer):
    """Create a reproducible, leakage-audited source manifest.

    Non-member candidates that duplicate any training member are *excluded*,
    never re-labelled. Duplicates within each source are also removed.
    Truncated-token duplicates are excluded because attacks score the same
    first `max_tokens` tokens and should not see identical inputs with opposite
    membership labels. Audit files contain hashes/row numbers, not raw text.
    """
    members, nonmembers = read_medal_rows(args, out)
    audit = []
    stats = {"member_source_rows": len(members),
             "nonmember_source_rows": len(nonmembers)}

    def distinct(collection, label):
        unique = {}
        for row_no, original in enumerate(collection):
            sig = sha_text(original)
            if sig in unique:
                audit.append({"source": "member" if label == 1 else "nonmember",
                              "source_nonempty_row": row_no, "hash": sig,
                              "reason": "duplicate_within_source"})
                continue
            unique[sig] = (row_no, original)
        return unique

    member_unique = distinct(members, 1)
    nonmember_unique = distinct(nonmembers, 0)
    overlaps = set(member_unique) & set(nonmember_unique)
    stats.update({"unique_member_texts": len(member_unique),
                  "unique_nonmember_texts": len(nonmember_unique),
                  "cross_split_normalized_overlap": len(overlaps)})

    for sig in sorted(overlaps):
        row_no, _ = nonmember_unique[sig]
        audit.append({"source": "nonmember", "source_nonempty_row": row_no,
                      "hash": sig, "reason": "also_present_in_member_source"})

    if overlaps and args.overlap_policy == "error":
        pd.DataFrame(audit, columns=["source", "source_nonempty_row", "hash", "reason"]).to_csv(
            out / "candidate_exclusion_audit.csv", index=False)
        raise ValueError(
            f"{len(overlaps)} normalized train/test text overlaps detected. "
            f"See {out / 'candidate_exclusion_audit.csv'}; rerun with "
            "--overlap-policy exclude-nonmembers to exclude ambiguous nonmembers."
        )

    # Eligibility is based on the precise truncated token sequence scored by
    # each attack. Cross-split prefix collisions must also be excluded.
    all_rows = []
    member_token_hashes = set()
    for sig, (row_no, item) in member_unique.items():
        toks = tokenizer.encode(item, add_special_tokens=False, truncation=True,
                                max_length=args.max_tokens)
        if len(toks) < args.min_tokens:
            audit.append({"source": "member", "source_nonempty_row": row_no,
                          "hash": sig, "reason": "fewer_than_min_tokens"})
            continue
        token_sig = hashlib.sha256(json.dumps(toks, separators=(",", ":")).encode()).hexdigest()
        if token_sig in member_token_hashes:
            audit.append({"source": "member", "source_nonempty_row": row_no,
                          "hash": sig, "reason": "duplicate_scored_tokens_within_source"})
            continue
        member_token_hashes.add(token_sig)
        all_rows.append({"sample_id": sig[:24], "hash": sig, "label": 1,
                         "text": item, "token_ids": toks})

    excluded_token_prefixes = 0
    nonmember_token_hashes = set()
    for sig, (row_no, item) in nonmember_unique.items():
        if sig in overlaps:
            continue
        toks = tokenizer.encode(item, add_special_tokens=False, truncation=True,
                                max_length=args.max_tokens)
        if len(toks) < args.min_tokens:
            audit.append({"source": "nonmember", "source_nonempty_row": row_no,
                          "hash": sig, "reason": "fewer_than_min_tokens"})
            continue
        token_sig = hashlib.sha256(json.dumps(toks, separators=(",", ":")).encode()).hexdigest()
        if token_sig in member_token_hashes:
            audit.append({"source": "nonmember", "source_nonempty_row": row_no,
                          "hash": sig, "reason": "identical_scored_tokens_to_member"})
            excluded_token_prefixes += 1
            continue
        if token_sig in nonmember_token_hashes:
            audit.append({"source": "nonmember", "source_nonempty_row": row_no,
                          "hash": sig, "reason": "duplicate_scored_tokens_within_source"})
            continue
        nonmember_token_hashes.add(token_sig)
        all_rows.append({"sample_id": sig[:24], "hash": sig, "label": 0,
                         "text": item, "token_ids": toks})

    # A 96-bit prefix is ample for hashes at this scale, but check rather than
    # silently treating any accidental collision as the same candidate.
    ids = [r["sample_id"] for r in all_rows]
    if len(set(ids)) != len(ids):
        raise RuntimeError("Truncated sample_id hash collision; increase sample_id hash length.")

    audit_path = out / "candidate_exclusion_audit.csv"
    pd.DataFrame(audit, columns=["source", "source_nonempty_row", "hash", "reason"]).to_csv(
        audit_path, index=False)
    stats["cross_split_token_prefix_collisions"] = excluded_token_prefixes
    stats["eligible_members"] = sum(r["label"] == 1 for r in all_rows)
    stats["eligible_nonmembers"] = sum(r["label"] == 0 for r in all_rows)
    (out / "candidate_selection_summary.json").write_text(json.dumps(stats, indent=2), encoding="utf-8")
    print("\nMembership candidate audit:")
    for name, value in stats.items():
        print(f"  {name}: {value}")
    print("Saved candidate exclusion audit:", audit_path)
    if overlaps or excluded_token_prefixes:
        warnings.warn(
            f"Excluded {len(overlaps)} normalized text matches and "
            f"{excluded_token_prefixes} additional matching token prefixes from nonmembers. "
            "Do not relabel them as members without verifying actual training membership. "
            "Inspect the audit and verify that the remaining test set was never used in fine-tuning."
        )

    by = {k: [v for v in all_rows if v["label"] == k] for k in (0, 1)}
    if args.require_per_class > 0:
        shortage = {"members": len(by[1]), "nonmembers": len(by[0])}
        if any(count < args.require_per_class for count in shortage.values()):
            raise ValueError(
                f"Requested exactly {args.require_per_class:,} examples PER class but "
                f"only {shortage['members']:,} eligible member examples and "
                f"{shortage['nonmembers']:,} eligible nonmember examples remain after "
                "deduplication and overlap filtering. Increase the verified held-out "
                "nonmember candidate pool if necessary, and rerun with a new --output "
                "directory; never relabel training records as nonmembers. "
                "NO model inference has started."
            )
    if args.population == "balanced":
        n_common = min(len(by[0]), len(by[1]))
        print(f"Balanced candidate population: {n_common:,} members and {n_common:,} nonmembers.")
    else:
        n_common = None
        warnings.warn("Using imbalanced population; F1 strongly depends on membership prevalence. "
                      "The manuscript should report the all-member F1 baseline.")
    rng = np.random.default_rng(args.seed)
    picked = []
    for label in (0, 1):
        arr = by[label]
        rng.shuffle(arr)
        if args.population == "balanced":
            arr = arr[:n_common]
        if args.max_per_class > 0:
            arr = arr[:args.max_per_class]
        if len(arr) < 50:
            raise ValueError(f"Only {len(arr)} eligible label={label} samples after cleaning. Need more.")
        cutoff = max(1, min(len(arr)-1, round(len(arr)*args.calibration_fraction)))
        for idx, rec in enumerate(arr):
            rec["split"] = "cal" if idx < cutoff else "test"
            picked.append(rec)
    rng.shuffle(picked)
    selected_counts = {label: sum(r["label"] == label for r in picked) for label in (0, 1)}
    if args.require_per_class > 0 and any(
        count != args.require_per_class for count in selected_counts.values()
    ):
        raise ValueError(
            f"Selected {selected_counts[1]:,} members and {selected_counts[0]:,} "
            f"nonmembers, but --require-per-class={args.require_per_class:,}. "
            "Use --max-per-class equal to --require-per-class and the default "
            "--population balanced; choose a fresh --output folder. "
            "NO model inference has started."
        )
    new_manifest = pd.DataFrame([{
        "sample_id": r["sample_id"], "hash": r["hash"], "label": r["label"],
        "split": r["split"], "n_tokens": len(r["token_ids"])
    } for r in picked]).sort_values("sample_id").reset_index(drop=True)
    dest = out / "sample_manifest.csv"
    if dest.exists():
        old = pd.read_csv(dest, dtype={"sample_id":str,"hash":str}).sort_values("sample_id").reset_index(drop=True)
        if not old.equals(new_manifest):
            raise RuntimeError(
                "Existing sample_manifest.csv differs from current dataset/config. "
                "Keep previous inputs unchanged to resume, or use a NEW --output directory."
            )
    else:
        new_manifest.to_csv(dest, index=False)
    print("Membership candidates:", dict(new_manifest.label.value_counts()))
    print("Calibration/test:", new_manifest.groupby(["split","label"]).size().to_dict())
    n_cal_neg = ((new_manifest.split == "cal") & (new_manifest.label == 0)).sum()
    if n_cal_neg < args.min_cal_neg:
        raise ValueError(f"Only {n_cal_neg} calibration nonmembers, need >= {args.min_cal_neg} to attempt low-FPR estimates.")
    if n_cal_neg < 1000:
        warnings.warn(
            f"Only {n_cal_neg} calibration negatives. TPR@1%FPR is discretized; "
            "prefer >= 1000-5000 for a strong low-FPR evaluation."
        )
    return picked


def append_file(path, header, existing=None):
    if not path.exists():
        with path.open("w", encoding="utf-8", newline="") as f:
            csv.writer(f).writerow(header)
    if existing is None:
        return set()
    frame = pd.read_csv(path)
    if frame.empty:
        return set()
    for col in existing:
        if col not in frame:
            raise RuntimeError(f"{path} is missing expected identifier {col}")
    if frame.duplicated(existing).any():
        raise RuntimeError(f"{path} contains repeated primary keys {existing}; resolve before continuing.")
    return set(tuple(row) for row in frame[existing].itertuples(index=False, name=None))


def atomic_append(path, rows, header):
    if not rows:
        return
    with path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=header)
        writer.writerows(rows)
        f.flush()
        os.fsync(f.fileno())


def load_transformers():
    import torch
    from transformers import AutoTokenizer, AutoModelForCausalLM
    from peft import PeftModel, LoraConfig, TaskType, get_peft_model
    return torch, AutoTokenizer, AutoModelForCausalLM, PeftModel, LoraConfig, TaskType, get_peft_model


def torch_device(torch, args):
    if args.device == "auto":
        return torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if args.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA selected but not available")
    return torch.device("cuda:0" if args.device == "cuda" else "cpu")


def load_target(path, method, args, device, deps):
    torch, _, AutoModel, PeftModel, LoraConfig, TaskType, get_peft_model = deps
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(path)
    # If this is an adapter folder, PEFT loads the adapter config as saved.
    if path.is_dir() and (path / "adapter_config.json").exists():
        base = AutoModel.from_pretrained(BASE_NAME)
        model = PeftModel.from_pretrained(base, str(path), is_trainable=False)
        print(f"{method}: loaded PEFT adapter folder")
    elif path.is_dir():
        model = AutoModel.from_pretrained(str(path))
        print(f"{method}: loaded full/merged Hugging Face folder")
    else:
        ckpt = torch.load(str(path), map_location="cpu", weights_only=True)
        state = ckpt.get("model_state_dict", ckpt.get("state_dict", ckpt))
        if not isinstance(state, dict):
            raise TypeError("Unsupported .pth/.pt model_state_dict")
        state = {k.removeprefix("module."): v for k,v in state.items()}
        adapter = [k for k in state if "lora_A" in k or "lora_B" in k]
        base = AutoModel.from_pretrained(BASE_NAME)
        if not adapter:
            base.load_state_dict(state, strict=True)
            model = base
            print(f"{method}: loaded merged/full .pth checkpoint")
        else:
            ranks = {int(v.shape[0]) for k,v in state.items() if ".lora_A" in k}
            if len(ranks) != 1:
                raise ValueError(f"{method}: inconsistent ranks {ranks}")
            ranks = ranks.pop()
            modules = args.target_modules.split(",")
            lm_head_saved_separately = any("lm_head.modules_to_save" in k for k in state)
            alpha = args.fibna_alpha if method=="FIBNA" else args.dp_alpha
            drop = args.fibna_dropout if method=="FIBNA" else args.dp_dropout
            lc = LoraConfig(r=ranks, lora_alpha=alpha, lora_dropout=drop,
                            target_modules=modules, bias="none", task_type=TaskType.CAUSAL_LM,
                            modules_to_save=["lm_head"] if lm_head_saved_separately else None)
            model = get_peft_model(base, lc)
            normalized = {}
            for k,v in state.items():
                kk = k.replace(".lora_A.weight", ".lora_A.default.weight")
                kk = kk.replace(".lora_B.weight", ".lora_B.default.weight")
                normalized[kk] = v
            expected = model.state_dict()
            unexpected = [k for k in normalized if k not in expected]
            missing_adapter = [k for k in expected if "lora_" in k and k not in normalized]
            mismatch = [k for k,v in normalized.items() if k in expected and expected[k].shape!=v.shape]
            if unexpected or missing_adapter or mismatch:
                raise RuntimeError(f"{method} checkpoint incompatibility: unexpected={unexpected[:4]}, missing_adapters={missing_adapter[:4]}, shapes={mismatch[:4]}")
            result = model.load_state_dict(normalized, strict=False)
            if result.unexpected_keys or any("lora_" in k for k in result.missing_keys):
                raise RuntimeError(f"{method}: adapter restore failed: {result}")
            if method == "FIBNA" and not any("lm_head" in k or "wte.weight" in k for k in normalized):
                raise RuntimeError("FIBNA checkpoint does not contain the modified LM head / tied embedding weights")
            if method == "FIBNA":
                h = normalized.get("base_model.model.lm_head.weight")
                w = normalized.get("base_model.model.transformer.wte.weight")
                if h is not None and w is not None and not torch.equal(h, w):
                    raise RuntimeError("FIBNA saved tied wte/lm_head tensors differ. Need original training/checkpoint architecture.")
            print(f"{method}: loaded {len(adapter)} LoRA tensors, r={ranks}, alpha={alpha}, modules={modules}, module_to_save={lc.modules_to_save}")
    model.to(device).eval()
    return model


def score_forward(torch, model, token_ids, device, k_pct, include_features=True):
    import torch.nn.functional as F
    ids = torch.tensor([token_ids], dtype=torch.long, device=device)
    with torch.inference_mode():
        logits = model(input_ids=ids, attention_mask=torch.ones_like(ids)).logits[:, :-1, :][0].float()
        targets = ids[:, 1:][0]
        lp = F.log_softmax(logits, dim=-1)
        token_lp = lp.gather(-1, targets.unsqueeze(-1)).squeeze(-1)
        mean_lp = float(token_lp.mean().item())
        if not include_features:
            return {"mean_logp":mean_lp}
        k = max(1, math.ceil(len(token_lp) * (k_pct / 100)))
        score_mink = float(torch.topk(token_lp, k, largest=False).values.mean().item())
        probs = lp.exp()
        mean_dist_lp = (probs * lp).sum(-1)
        var_dist_lp = ((probs * (lp - mean_dist_lp.unsqueeze(-1)).square()).sum(-1)).clamp_min(1e-12)
        standardized = (token_lp - mean_dist_lp) / torch.sqrt(var_dist_lp)
        score_minkpp = float(torch.topk(standardized, k, largest=False).values.mean().item())
        entropy = -mean_dist_lp.mean().item()
        top1 = torch.argmax(logits, dim=-1)
        mismatches = (top1 != targets).detach().cpu().numpy().astype(bool)
        return {
            "mean_logp":mean_lp,
            "token_logps":token_lp.detach().cpu().numpy().astype(float).tolist(),
            "wrong_mask":mismatches,
            "score_mink":score_mink,
            "score_minkpp":score_minkpp,
            "score_entropy":-float(entropy),
        }


def precompute_base_reference(rows, args, out, tokenizer, deps, device):
    torch, _, AutoModel, *_ = deps
    dest = out / "reference_logprobs.csv"
    completed = append_file(dest, REF_FIELDS, ["sample_id"])
    tasks = [r for r in rows if (r["sample_id"],) not in completed]
    if tasks:
        print(f"Precomputing pretrained reference: {len(tasks)} remaining")
        model = AutoModel.from_pretrained(BASE_NAME).to(device).eval()
        pending = []
        for j,r in enumerate(tasks, 1):
            a = score_forward(torch, model, r["token_ids"], device, args.k_percent)
            pending.append({"sample_id":r["sample_id"],
                            "ref_mean_logp":a["mean_logp"],
                            "ref_token_logps_json":json.dumps(a["token_logps"],separators=(",", ":"))})
            if len(pending)>=args.save_every:
                atomic_append(dest, pending, REF_FIELDS); pending=[]
                print(f"  base reference {j}/{len(tasks)}")
        atomic_append(dest,pending,REF_FIELDS)
        del model; gc.collect()
        if torch.cuda.is_available(): torch.cuda.empty_cache()
    df = pd.read_csv(dest, dtype={"sample_id":str})
    if df.sample_id.duplicated().any(): raise RuntimeError("Duplicate reference sample IDs")
    result = {r["sample_id"]:{"mean_logp":float(r["ref_mean_logp"]),
                               "token_logps":np.array(json.loads(r["ref_token_logps_json"]),dtype=float)}
              for _,r in df.iterrows()}
    if not all(r["sample_id"] in result for r in rows):
        raise RuntimeError("Incomplete base reference cache")
    return result


def generate_t5_neighbors(rows, args, out, deps, device, tokenizer):
    """Cached, reproducible T5-small single-span perturbations.

    Both successes and deterministic failures are saved with primary keys.
    A failed perturbation is never treated as an actual neighbor, and it is
    not regenerated on every restart. Existing CSVs remain the source of truth.
    """
    dest = out / "neighbors.csv"
    invalid_dest = out / "invalid_neighbors.csv"
    append_file(dest, NEIGH_FIELDS, ["sample_id","neighbor_idx"])
    append_file(invalid_dest, INVALID_NEIGH_FIELDS, ["sample_id","neighbor_idx"])
    if args.neighbors == 0:
        return {}
    ndf = pd.read_csv(dest, dtype={"sample_id":str})
    idf = pd.read_csv(invalid_dest, dtype={"sample_id":str})
    done_valid = set(zip(ndf.sample_id,ndf.neighbor_idx)) if len(ndf) else set()
    done_invalid = set(zip(idf.sample_id,idf.neighbor_idx)) if len(idf) else set()
    if done_valid & done_invalid:
        raise RuntimeError("A neighbor ID is present in both valid and invalid neighbor files")
    known = done_valid | done_invalid
    needed = [(r,j) for r in rows for j in range(args.neighbors)
              if (r["sample_id"],j) not in known]
    print(f"T5 neighborhoods: {len(done_valid)} saved valid, {len(done_invalid)} saved invalid; "
          f"{len(needed)} still to attempt")
    if needed:
        torch, AutoTokenizer, _, *_ = deps
        from transformers import AutoModelForSeq2SeqLM
        mask_tok = AutoTokenizer.from_pretrained(args.mask_model)
        mask_model = AutoModelForSeq2SeqLM.from_pretrained(args.mask_model).to(device).eval()
        valid_batch=[];invalid_batch=[]
        for i,(r,j) in enumerate(needed,1):
            short = tokenizer.decode(r["token_ids"],skip_special_tokens=True)
            words = short.split()
            reason=None;neighbor=None
            if len(words)<8:
                reason="too_few_words"
            else:
                span = min(args.mask_span_words, max(1,len(words)//5))
                seed = int(hashlib.sha256(f'{r["sample_id"]}|{j}|{args.seed}'.encode()).hexdigest()[:12],16)
                local_rng = np.random.default_rng(seed)
                start = int(local_rng.integers(1,max(2,len(words)-span)))
                masked = " ".join(words[:start]+["<extra_id_0>"]+words[start+span:])
                inp = mask_tok(masked,return_tensors="pt",truncation=True,max_length=512).to(device)
                with torch.inference_mode():
                    out_ids = mask_model.generate(**inp,max_new_tokens=32,num_beams=1,do_sample=False)
                infilled = mask_tok.decode(out_ids[0],skip_special_tokens=False)
                match = re.search(r"<extra_id_0>\s*(.*?)\s*(?:<extra_id_1>|</s>|$)",infilled)
                replacement = match.group(1).strip() if match else ""
                replacement = replacement.replace("<pad>","").replace("</s>","").strip()
                if not replacement:
                    reason="empty_infill"
                else:
                    neighbor = " ".join(words[:start]+[replacement]+words[start+span:])
                    if not neighbor.strip() or neighbor==short:
                        reason="unchanged_or_empty_neighbor"
            if reason:
                invalid_batch.append({"sample_id":r["sample_id"],"neighbor_idx":j,"reason":reason})
            else:
                valid_batch.append({"sample_id":r["sample_id"],"neighbor_idx":j,"neighbor_text":neighbor})
            # Flush both files at regular ATTEMPT counts, irrespective of success.
            if i%args.save_every == 0:
                atomic_append(dest,valid_batch,NEIGH_FIELDS)
                atomic_append(invalid_dest,invalid_batch,INVALID_NEIGH_FIELDS)
                valid_batch=[];invalid_batch=[]
                print(f"  T5 neighbor attempts {i}/{len(needed)} saved")
        atomic_append(dest,valid_batch,NEIGH_FIELDS)
        atomic_append(invalid_dest,invalid_batch,INVALID_NEIGH_FIELDS)
        del mask_model; gc.collect()
        if torch.cuda.is_available():torch.cuda.empty_cache()
    ndf = pd.read_csv(dest,dtype={"sample_id":str})
    neighbors = defaultdict(list)
    for _,r in ndf.iterrows():
        neighbors[r["sample_id"]].append(str(r["neighbor_text"]))
    print("Neighborhood score coverage:", sum(bool(neighbors[x["sample_id"]]) for x in rows),"/",len(rows))
    return neighbors


def ez_mia_score(target_logps, ref_logps, wrong_mask):
    # Matches the error-zone P/N implementation's central statistic.
    # Need >=2 error-zone tokens; zero if no negative denominator.
    # Match original EZ-MIA implementation: ignore first shifted-token position.
    wrong_mask = np.array(wrong_mask, dtype=bool).copy()
    if len(wrong_mask): wrong_mask[0] = False
    wrong = np.flatnonzero(wrong_mask)
    if len(wrong)<2: return 0.0
    if len(target_logps)!=len(ref_logps):
        raise RuntimeError("Reference and target tokenizer/alignment mismatch")
    d = np.asarray(target_logps,dtype=float)[wrong] - np.asarray(ref_logps,dtype=float)[wrong]
    positive = d[d>0].sum()
    negative = -d[d<0].sum()
    if negative<=0: return 0.0
    val = float(positive/(negative+1e-12))
    return val if np.isfinite(val) and val>=0 else 0.0


def evaluate_model(rows, args, out, deps, device, tokenizer, ref, neighbors, method, path):
    torch = deps[0]
    dest = out / f"scores_{method}.csv"
    completed = append_file(dest,SCORE_FIELDS,["sample_id"])
    pending_tasks = [r for r in rows if (r["sample_id"],) not in completed]
    print(f"{method}: {len(pending_tasks)} remaining / {len(rows)} total")
    if not pending_tasks:return
    model = load_target(path,method,args,device,deps)
    pending=[]
    for idx,r in enumerate(pending_tasks,1):
        primary = score_forward(torch,model,r["token_ids"],device,args.k_percent)
        lp = np.asarray(primary["token_logps"],dtype=float)
        ref_rec = ref[r["sample_id"]]
        # Neighborhood original-advantage: logP(original)-mean(logP(neighbors)).
        # Here logP = mean observed-token log probability (length-normalized).
        neigh_scores=[]
        for ntext in neighbors.get(r["sample_id"],[]):
            ntok=tokenizer.encode(ntext,add_special_tokens=False,truncation=True,max_length=args.max_tokens)
            if len(ntok)>=2:
                neigh_scores.append(score_forward(torch,model,ntok,device,args.k_percent,include_features=False)["mean_logp"])
        neigh_score=(primary["mean_logp"]-float(np.mean(neigh_scores))) if neigh_scores else float("nan")
        txt = tokenizer.decode(r["token_ids"],skip_special_tokens=True)
        zlib_bytes=max(1,len(zlib.compress(txt.encode("utf-8"))))
        row={
            "sample_id":r["sample_id"],"label":r["label"],"split":r["split"],
            "n_tokens":len(r["token_ids"]),"score_ppl":primary["mean_logp"],
            "score_mink":primary["score_mink"],"score_minkpp":primary["score_minkpp"],
            "score_neighbor":neigh_score,"score_ez":ez_mia_score(lp,ref_rec["token_logps"],primary["wrong_mask"]),
            "score_reference":primary["mean_logp"]-ref_rec["mean_logp"],
            "score_zlib":primary["mean_logp"]*len(lp)/zlib_bytes,
            "score_entropy":primary["score_entropy"],"n_neighbors":len(neigh_scores)
        }
        pending.append(row)
        if len(pending)>=args.save_every:
            atomic_append(dest,pending,SCORE_FIELDS);pending=[]
            print(f"  {method} {idx}/{len(pending_tasks)} completed, saved")
    atomic_append(dest,pending,SCORE_FIELDS)
    del model;gc.collect()
    if torch.cuda.is_available():torch.cuda.empty_cache()


def external_scores(args,manifest):
    if not args.external_scores:
        return pd.DataFrame(columns=["sample_id","model","attack","score"])
    df=pd.read_csv(args.external_scores,dtype={"sample_id":str})
    required={"sample_id","model","attack","score"}
    if not required.issubset(df):raise ValueError(f"--external-scores must have {sorted(required)}")
    if df.duplicated(["sample_id","model","attack"]).any():raise ValueError("Duplicate external per-example attack scores")
    known=set(manifest.sample_id)
    if not set(df.sample_id).issubset(known):raise ValueError("External scores contain unknown IDs")
    if not set(df.model).issubset(METHODS):raise ValueError("Unknown model in external scores")
    if not set(df.attack).issubset(EXTERNAL_ATTACKS):raise ValueError("Only SPV-MIA, DF-MIA, LiRA supported as external attack labels")
    if not np.isfinite(pd.to_numeric(df.score,errors="coerce")).all():raise ValueError("Nonfinite external attack scores")
    return df


def choose_threshold_f1(scores,labels):
    from sklearn.metrics import precision_recall_curve
    precision,recall,thresholds=precision_recall_curve(labels,scores)
    if len(thresholds)==0:return float("inf")
    f1=2*precision[:-1]*recall[:-1]/(precision[:-1]+recall[:-1]+1e-12)
    return float(thresholds[int(np.argmax(f1))])


def low_fpr_threshold(negatives,alpha):
    # Larger scores imply member. Empirical upper tail threshold from calibration
    # nonmembers only. Use a conservative strict > operation for tied scores.
    try:return float(np.quantile(negatives,1-alpha,method="higher"))
    except TypeError:return float(np.quantile(negatives,1-alpha,interpolation="higher"))


def ci_bootstrap(labels, scores, f1_threshold, fpr1_thresh, fpr10_thresh, nboot, seed):
    from sklearn.metrics import roc_auc_score, f1_score
    rng=np.random.default_rng(seed)
    ids1=np.flatnonzero(labels==1);ids0=np.flatnonzero(labels==0)
    metrics=np.zeros((nboot,4),dtype=float)
    for b in range(nboot):
        ii=np.r_[rng.choice(ids1,size=len(ids1),replace=True),rng.choice(ids0,size=len(ids0),replace=True)]
        y=labels[ii]; s=scores[ii]
        metrics[b]=[
            roc_auc_score(y,s),
            f1_score(y,s>=f1_threshold,zero_division=0),
            np.mean(s[y==1]>fpr1_thresh),
            np.mean(s[y==1]>fpr10_thresh),
        ]
    lows=np.percentile(metrics,2.5,axis=0); highs=np.percentile(metrics,97.5,axis=0)
    return dict(zip(["auc","f1","tpr1","tpr10"],zip(lows,highs)))


def assess_one(df, method, attack, args):
    from sklearn.metrics import roc_auc_score,precision_score,recall_score,f1_score,confusion_matrix
    df=df.dropna(subset=["score"]).copy()
    cal=df[df.split=="cal"]
    test=df[df.split=="test"]
    ncal0=(cal.label==0).sum();ncal1=(cal.label==1).sum()
    ntest0=(test.label==0).sum();ntest1=(test.label==1).sum()
    if min(ncal0,ncal1,ntest0,ntest1)<10:
        return None
    sc=cal.score.to_numpy(dtype=float)
    yc=cal.label.to_numpy(dtype=int)
    # Direction chosen ONLY with calibration labels, not final-test labels.
    cal_raw_auc=roc_auc_score(yc,sc)
    direction=1 if cal_raw_auc>=0.5 else -1
    cal_sc=direction*sc
    test_sc=direction*test.score.to_numpy(dtype=float)
    yt=test.label.to_numpy(dtype=int)
    # Precision/recall threshold fitted ONLY on calibration members/nonmembers.
    tf1=choose_threshold_f1(cal_sc,yc)
    # sklearn's curve counts >= threshold; choose thresholds with this convention.
    negcal=cal_sc[yc==0]
    t1=low_fpr_threshold(negcal,0.01)
    t10=low_fpr_threshold(negcal,0.10)
    pred=(test_sc>=tf1).astype(int)
    tn,fp,fn,tp=confusion_matrix(yt,pred,labels=[0,1]).ravel()
    auc=roc_auc_score(yt,test_sc)
    member=test_sc[yt==1]; nonmember=test_sc[yt==0]
    result={
        "model":method,"attack":attack,"n_cal_members":int(ncal1),"n_cal_nonmembers":int(ncal0),
        "n_test_members":int(ntest1),"n_test_nonmembers":int(ntest0),
        "direction_from_calibration":direction,"calibration_raw_auc":float(cal_raw_auc),
        "f1":float(f1_score(yt,pred,zero_division=0)),
        "precision":float(precision_score(yt,pred,zero_division=0)),
        "recall":float(recall_score(yt,pred,zero_division=0)),
        "roc_auc_calibrated":float(auc),
        "tpr_at_1pct_fpr":float(np.mean(member>t1)),
        "test_fpr_at_1pct_target":float(np.mean(nonmember>t1)),
        "tpr_at_10pct_fpr":float(np.mean(member>t10)),
        "test_fpr_at_10pct_target":float(np.mean(nonmember>t10)),
        "f1_threshold_calibrated":tf1,"threshold_1pct_calibrated":t1,
        "threshold_10pct_calibrated":t10,
        "tp":int(tp),"tn":int(tn),"fp":int(fp),"fn":int(fn),
        "status":"computed"
    }
    if args.bootstrap>0:
        c=ci_bootstrap(yt,test_sc,tf1,t1,t10,args.bootstrap,args.seed)
        for short,long_name in [("auc","auc"),("f1","f1"),("tpr1","tpr_at_1pct_fpr"),("tpr10","tpr_at_10pct_fpr")]:
            result[long_name+"_ci95_low"]=float(c[short][0]);result[long_name+"_ci95_high"]=float(c[short][1])
    return result


# Bars are grouped by attack and compare exactly the SAME candidate IDs across models.
PLOT_METRICS = {
    "f1": "F1-score", "tpr_at_1pct_fpr": "TPR at 1% target FPR",
    "tpr_at_10pct_fpr": "TPR at 10% target FPR",
    "roc_auc_calibrated": "Calibrated ROC-AUC",
    "precision": "Precision", "recall": "Recall",
    "test_fpr_at_1pct_target": "Observed test FPR (1% target)",
    "test_fpr_at_10pct_target": "Observed test FPR (10% target)",
}


def draw_grouped_metrics(summary, out, bootstrap):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.ticker import PercentFormatter
    palette={"LoRA":"#2166A4", "DP-LoRA":"#DB842B", "FIBNA":"#17957D"}
    figure_dir=out/"comparison_graphs"
    figure_dir.mkdir(parents=True,exist_ok=True)
    attacks=[a for a in ALL_ATTACKS if a in set(summary.attack)]
    x=np.arange(len(attacks)); width=.26
    for metric,label in PLOT_METRICS.items():
        fig,ax=plt.subplots(figsize=(max(12,1.25*len(attacks)),5.6))
        for i,method in enumerate(METHODS):
            sub=summary.loc[summary.model.eq(method)].set_index("attack").reindex(attacks)
            vals=pd.to_numeric(sub[metric],errors="coerce").to_numpy(dtype=float)
            ci_lo=metric+"_ci95_low";ci_hi=metric+"_ci95_high"
            yerr=None
            if bootstrap and ci_lo in sub and ci_hi in sub:
                lo=pd.to_numeric(sub[ci_lo],errors="coerce").to_numpy(dtype=float)
                hi=pd.to_numeric(sub[ci_hi],errors="coerce").to_numpy(dtype=float)
                if np.all(np.isfinite(lo)) and np.all(np.isfinite(hi)):
                    yerr=np.vstack((np.maximum(vals-lo,0),np.maximum(hi-vals,0)))
            ax.bar(x+(i-1)*width,vals,width,color=palette[method],label=method,
                   edgecolor="white",linewidth=.7,yerr=yerr,capsize=2 if yerr is not None else 0,zorder=3)
        if metric=="roc_auc_calibrated":
            ax.axhline(.5,color="gray",ls="--",lw=1,label="Chance AUC = 0.50")
        if metric=="f1" and "all_member_f1_baseline" in summary:
            ax.axhline(float(summary.all_member_f1_baseline.median()),color="gray",ls="--",lw=1,
                       label="Predict-all-members baseline")
        if metric=="test_fpr_at_1pct_target":ax.axhline(.01,color="gray",ls="--",lw=1)
        if metric=="test_fpr_at_10pct_target":ax.axhline(.10,color="gray",ls="--",lw=1)
        ax.set_xticks(x);ax.set_xticklabels(attacks,rotation=28,ha="right")
        ax.set_ylabel(label);ax.set_xlabel("Membership inference attack")
        ax.set_title(f"GPT-2-Large on MeDAL: {label}")
        if "fpr" in metric or metric.startswith("tpr_"):
            ax.yaxis.set_major_formatter(PercentFormatter(xmax=1,decimals=1))
        ax.set_axisbelow(True);ax.grid(axis="y",alpha=.2)
        ax.legend(ncol=2,fontsize=9)
        fig.tight_layout()
        name=figure_dir/f"mia_comparison_{metric}"
        fig.savefig(str(name)+".png",dpi=300,bbox_inches="tight")
        fig.savefig(str(name)+".svg",bbox_inches="tight")
        plt.close(fig)
    # Detailed point-and-interval figures, useful when all AUCs cluster near 0.5.
    for metric, chart_title, ci_stem in [
        ("roc_auc_calibrated", "Calibrated ROC-AUC", "auc"),
        ("f1", "F1-score", "f1"),
    ]:
        fig, ax = plt.subplots(figsize=(13.2, 5.8))
        offsets = [-0.18, 0, 0.18]
        for offset, method in zip(offsets, METHODS):
            sub = summary.loc[summary.model.eq(method)].set_index("attack").reindex(attacks)
            val = pd.to_numeric(sub[metric], errors="coerce").to_numpy(dtype=float)
            low_col, high_col = ci_stem + "_ci95_low", ci_stem + "_ci95_high"
            if low_col in sub and high_col in sub:
                low = pd.to_numeric(sub[low_col], errors="coerce").to_numpy(dtype=float)
                high = pd.to_numeric(sub[high_col], errors="coerce").to_numpy(dtype=float)
                errs = np.vstack((np.maximum(0, val-low), np.maximum(0, high-val)))
            else:
                errs = np.zeros((2, len(attacks)))
            ax.errorbar(np.arange(len(attacks))+offset, val, yerr=errs,
                        fmt="o", linestyle="none", capsize=3, markersize=5,
                        color=palette[method], label=method, elinewidth=1)
        if metric == "roc_auc_calibrated":
            ax.axhline(0.5, color="#657585", linestyle="--", label="Chance AUC = 0.50")
        ax.set_xticks(np.arange(len(attacks)))
        ax.set_xticklabels(attacks, rotation=28, ha="right")
        ax.set_ylabel(chart_title)
        ax.set_title(f"MeDAL | GPT-2-Large | {chart_title} (95% bootstrap confidence intervals)")
        ax.grid(axis="y", alpha=0.22, linestyle=":")
        ax.legend(ncol=4, fontsize=9)
        fig.tight_layout()
        stem=figure_dir / f"medal_gpt2_mia_{metric}_detail"
        for extension in ("png", "svg", "pdf"):
            fig.savefig(str(stem)+"."+extension, dpi=300, bbox_inches="tight")
        plt.close(fig)
    print(f"Saved grouped per-metric PNG/SVG plots and detailed AUC/F1 figures: {figure_dir}")


def report(args,out,make_plots=True):
    from sklearn.metrics import roc_auc_score
    mf=out/"sample_manifest.csv"
    if not mf.exists():raise FileNotFoundError(f"Missing {mf}")
    manifest=pd.read_csv(mf,dtype={"sample_id":str})
    if manifest.sample_id.duplicated().any():raise RuntimeError("Duplicate IDs in manifest")
    ids=manifest.sample_id.tolist(); required=set(ids)
    by_model={}
    for method in METHODS:
        dest=out/f"scores_{method}.csv"
        if not dest.exists():
            print(f"No model scores yet: {dest}")
            continue
        frame=pd.read_csv(dest,dtype={"sample_id":str})
        if frame.sample_id.duplicated().any():raise RuntimeError(f"Repeated sample_id in {dest}")
        if not set(frame.sample_id).issubset(required):raise RuntimeError(f"Unknown samples in {dest}")
        if not set(SCORE_MAP.values()).issubset(frame.columns):
            raise RuntimeError(f"Missing expected score columns in {dest}")
        merged=frame.set_index("sample_id",verify_integrity=True)
        by_model[method]=merged
    external=external_scores(args,manifest)
    ext_by={(m,a): x.set_index("sample_id") for (m,a),x in external.groupby(["model","attack"])} if not external.empty else {}
    all_results=[];coverage=[];recs=[]; excluded=[]
    for attack in ALL_ATTACKS:
        data={}
        for method in METHODS:
            if attack in SCORE_MAP:
                if method not in by_model:continue
                raw=by_model[method][SCORE_MAP[attack]].apply(pd.to_numeric,errors="coerce")
            else:
                if (method,attack) not in ext_by:continue
                raw=pd.to_numeric(ext_by[method,attack]["score"],errors="coerce")
            data[method]=raw
        if len(data)!=len(METHODS):
            for method in METHODS:
                coverage.append({"model":method,"attack":attack,"status":"PENDING_SCORES"})
            continue
        valid=set(ids)
        for method in METHODS:
            raw=data[method]
            valid &= set(raw.index[np.isfinite(raw)])
            if attack=="Neighborhood" and "n_neighbors" in by_model[method]:
                nn=pd.to_numeric(by_model[method]["n_neighbors"],errors="coerce")
                valid &= set(nn.index[nn>=1])
        matched=[i for i in ids if i in valid]
        missing_ids=[i for i in ids if i not in valid]
        for sample in missing_ids:
            excluded.append({"attack":attack,"sample_id":sample,"reason":"missing/nonfinite score in >=1 model"})
        for method in METHODS:
            coverage.append({"model":method,"attack":attack,"n_expected":len(ids),
                             "n_valid_common":len(matched),"n_excluded":len(missing_ids),
                             "status":"COMPLETE" if not missing_ids else "COMMON_VALID_SUBSET"})
            if not matched:continue
            part=manifest.set_index("sample_id").loc[matched,["label","split"]].copy()
            part["score"]=data[method].loc[matched].to_numpy(dtype=float)
            part=part.reset_index()
            a=assess_one(part,method,attack,args)
            if a is None:continue
            a["n_valid_common"]=len(matched)
            a["n_missing_excluded"]=len(missing_ids)
            a["all_member_f1_baseline"]=float(2*a["n_test_members"]/(2*a["n_test_members"]+a["n_test_nonmembers"]))
            a["status"]="computed" if not missing_ids else "computed_common_valid_subset"
            all_results.append(a)
            per=part.copy();per.rename(columns={"score":"raw_score"},inplace=True)
            per.to_csv(out/f"per_example_{method}_{re.sub(r'[^A-Za-z0-9_-]+','_',attack)}.csv",index=False)
            for r in per.itertuples(index=False):
                recs.append({"sample_id":r.sample_id,"label":r.label,"split":r.split,
                             "model":method,"attack":attack,"raw_score":r.raw_score})
    result=pd.DataFrame(all_results)
    pd.DataFrame(coverage).to_csv(out/"attack_coverage_audit.csv",index=False)
    pd.DataFrame(excluded,columns=["attack","sample_id","reason"]).to_csv(
        out/"excluded_from_attack_metrics.csv",index=False)
    if result.empty:
        print("No complete across-model attack comparisons yet; existing inference CSVs untouched.")
        return result
    result.to_csv(out/"mia_summary.csv",index=False)
    pd.DataFrame(recs).to_csv(out/"all_per_example_attack_scores.csv",index=False)
    cols=["model","attack","n_valid_common","f1","tpr_at_1pct_fpr","tpr_at_10pct_fpr",
          "roc_auc_calibrated","precision","recall","test_fpr_at_1pct_target","test_fpr_at_10pct_target","status"]
    result[cols].to_csv(out/"table_for_manuscript.csv",index=False)
    for model in METHODS:
        result.loc[result.model.eq(model),cols].to_csv(out/f"table_{model}.csv",index=False)
    for metric in PLOT_METRICS:
        table=result.pivot(index="attack",columns="model",values=metric)
        table.reindex(index=ALL_ATTACKS,columns=list(METHODS)).to_csv(out/f"metric_table_{metric}.csv")
    print("\n=== GPT-2-Large MeDAL MIA comparison ===")
    print(result[cols].to_string(index=False,float_format=lambda z:f"{z:.5f}"))
    if make_plots and not args.no_plot:
        draw_grouped_metrics(result,out,args.bootstrap)
    return result


def main():
    args=get_args()
    if args.max_tokens < args.min_tokens or not 0<args.calibration_fraction<1 or not 0<args.k_percent<=100:
        raise ValueError("Check max/min tokens, calibration fraction and k percent")
    if args.require_per_class < 0 or args.max_per_class < 0:
        raise ValueError("--require-per-class and --max-per-class must be nonnegative")
    if args.require_per_class and args.max_per_class != args.require_per_class:
        raise ValueError("For an exact-class-size experiment, set --max-per-class equal to --require-per-class")
    out=Path(args.output).expanduser().resolve()
    out.mkdir(parents=True,exist_ok=True)
    if args.report_only:
        report(args,out)
        return
    if not args.trust_membership:
        raise SystemExit(
            "Membership must be verified: --trust-membership asserts that all three checkpoints "
            "fine-tuned on the same first 53,000 examples after HF shuffle(seed=42), "
            "and that held-out test/validation examples were never fine-tuned."
        )
    verify_run_config(args,out)
    deps=load_transformers()
    torch, AutoTokenizer, *_=deps
    torch.manual_seed(args.seed);np.random.seed(args.seed)
    device=torch_device(torch,args)
    print("Device:",device)
    tokenizer=AutoTokenizer.from_pretrained(BASE_NAME)
    if tokenizer.pad_token is None:tokenizer.pad_token=tokenizer.eos_token
    rows=choose_data(args,out,tokenizer)
    if args.prepare_only:
        print("Data selection audit and sample manifest completed. No GPU inference run.")
        return
    if any(len(r["token_ids"])>1024 for r in rows):raise ValueError("GPT-2 max 1024 positional embeddings")
    reference=precompute_base_reference(rows,args,out,tokenizer,deps,device)
    neighbors=generate_t5_neighbors(rows,args,out,deps,device,tokenizer)
    for method,path in zip(METHODS,[args.lora,args.dp_lora,args.fibna]):
        evaluate_model(rows,args,out,deps,device,tokenizer,reference,neighbors,method,path)
    # Spawn a fresh reporting process: no Qt/Matplotlib imports in the
    # inference process, avoiding the Windows OpenMP/Qt crash observed before.
    import subprocess
    report_cmd=[sys.executable, str(Path(__file__).resolve()), "--report-only",
                "--output", str(out), "--bootstrap", str(args.bootstrap),
                "--seed", str(args.seed)]
    if args.external_scores:
        report_cmd += ["--external-scores", str(args.external_scores)]
    if args.no_plot:
        report_cmd.append("--no-plot")
    if args.no_auto_report:
        print("\nAll inference CSVs saved. Regenerate results separately using:")
        print(" ".join(report_cmd))
    else:
        print("\nAll inference CSVs saved. Starting isolated reporting subprocess.")
        finished=subprocess.run(report_cmd,check=False)
        if finished.returncode != 0:
            print("Reporting failed, but per-example scores were preserved.")
            print("Rerun: " + " ".join(report_cmd))
            raise SystemExit(finished.returncode)



if __name__=="__main__":
    main()
