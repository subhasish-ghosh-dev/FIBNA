#!/usr/bin/env python3
"""Held-out AG News utility-test evaluation for the 5-epoch Qwen LoRA adapter.

Matches train_agnews_qwen_lora_5epoch.py's AGNewsCodec and score_labels exactly.
Never reads attack_train/calibration/test.csv for classification utility.
"""
from __future__ import annotations
import argparse
import contextlib
import hashlib
import json
import math
import os
import platform
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
from agnews_qwen_common import AGNewsCodec, LABELS, sha_file


def check_data(root: Path, train_summary: dict):
    manifest_path = root / 'split_manifest.json'
    if not manifest_path.is_file():
        raise FileNotFoundError(manifest_path)
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    for name, expected in manifest.get('file_sha256', {}).items():
        file = root / name
        if not file.is_file():
            raise FileNotFoundError(file)
        actual = sha_file(file)
        if actual != expected:
            raise RuntimeError(f'Immutable data split hash mismatch: {name}. Expected {expected}, got {actual}')
    test_file = root / 'utility_test.csv'
    if 'utility_test.csv' not in manifest.get('file_sha256', {}):
        raise RuntimeError('Manifest does not hash utility_test.csv')
    if train_summary.get('is_pilot') or int(train_summary.get('epochs', 0)) != 5:
        raise RuntimeError('Checkpoint summary is a pilot or not a five-epoch training run')
    if train_summary.get('model') != manifest.get('base_model'):
        raise RuntimeError('Target checkpoint base model differs from prepared data manifest')
    if train_summary.get('target_train_csv_sha256') != sha_file(root / 'target_train.csv'):
        raise RuntimeError('Trained model data hash disagrees with current target_train.csv')
    if train_summary.get('split_manifest_sha256') != sha_file(manifest_path):
        raise RuntimeError('Trained model split manifest hash disagrees with present split_manifest.json')
    if train_summary.get('method') != 'LoRA':
        raise RuntimeError('Provided training summary is not for LoRA')
    if int(train_summary.get('train_count', -1)) != int(manifest['training_members']):
        raise RuntimeError('Training count disagrees with immutable manifest')
    t = pd.read_csv(test_file, keep_default_na=False, dtype={'sample_id': str, 'text_hash': str})
    required = {'sample_id','text','text_hash','label_id','label_name','completion'}
    if not required.issubset(t):
        raise RuntimeError(f'utility_test.csv lacks columns: {sorted(required - set(t))}')
    if len(t) != int(manifest['utility_test']):
        raise RuntimeError('Utility test length mismatches manifest')
    if t.sample_id.duplicated().any() or t.text_hash.duplicated().any():
        raise RuntimeError('Duplicate test sample IDs or normalized text hashes')
    if not set(t.label_id.astype(int)).issubset(set(LABELS)):
        raise RuntimeError('Unexpected category IDs')
    if not (t.label_name == t.label_id.astype(int).map(LABELS)).all():
        raise RuntimeError('Category ID/name mapping conflict')
    if not (t.completion == t.label_id.astype(int).map(LABELS).map(lambda x: ' ' + x)).all():
        raise RuntimeError('Category completion mismatch')
    train = pd.read_csv(root / 'target_train.csv', usecols=['text_hash'], dtype={'text_hash':str})
    if not set(t.text_hash).isdisjoint(set(train.text_hash)):
        raise RuntimeError('Utility test overlaps target training set')
    return manifest, t


def amp_context(torch, dtype):
    if dtype == 'fp32':
        return contextlib.nullcontext()
    return torch.autocast('cuda', dtype={'bf16':torch.bfloat16, 'fp16':torch.float16}[dtype])


def score_labels(model, codec, text, torch, dtype, device):
    """Exact score_labels definition from the 5-epoch LoRA training code.

    Mean log likelihood of completion tokens (without EOS), 4 candidates in one pass.
    """
    options = codec.choices(text)
    maxlen = max(len(ids) for _, ids, _, _ in options)
    data = [ids + [codec.tok.pad_token_id] * (maxlen - len(ids))
            for _, ids, _, _ in options]
    attn = [[1] * len(ids) + [0] * (maxlen - len(ids))
            for _, ids, _, _ in options]
    ids = torch.tensor(data, dtype=torch.long, device=device)
    mask = torch.tensor(attn, dtype=torch.long, device=device)
    with torch.inference_mode(), amp_context(torch, dtype):
        logits = model(input_ids=ids, attention_mask=mask, use_cache=False).logits
    scores = {}
    for row, (k, seq, p_len, n_lab) in enumerate(options):
        pos = torch.arange(p_len-1, p_len+n_lab-1, device=device)
        token_ids = ids[row, p_len:p_len+n_lab]
        chosen = logits[row, pos, :].float()
        lp = torch.log_softmax(chosen, dim=-1)
        scores[k] = float(lp.gather(1, token_ids.unsqueeze(1)).mean().item())
    return max(scores, key=scores.get), scores


def bootstrap_intervals(y_true, y_pred, classes, iterations, seed):
    from sklearn.metrics import accuracy_score, f1_score
    rng = np.random.default_rng(seed)
    # Stratified by ground-truth class to avoid random class dropout.
    groups = [np.flatnonzero(y_true == k) for k in classes]
    output = np.zeros((iterations, 2), dtype=float)
    for i in range(iterations):
        sample = np.concatenate([rng.choice(g, len(g), replace=True) for g in groups])
        output[i, 0] = accuracy_score(y_true[sample], y_pred[sample])
        output[i, 1] = f1_score(y_true[sample], y_pred[sample], labels=classes,
                                average='macro', zero_division=0)
    return {
        'accuracy_ci95': [float(v) for v in np.quantile(output[:,0], [0.025, 0.975])],
        'macro_f1_ci95': [float(v) for v in np.quantile(output[:,1], [0.025, 0.975])],
        'bootstrap_repetitions': iterations,
        'bootstrap_method': 'stratified-by-true-class resampling with replacement',
    }


def plot_confusion(cm, names, dest):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(7.0, 5.8))
    im = ax.imshow(cm)
    ax.set_xticks(range(len(names)), names, rotation=25, ha='right')
    ax.set_yticks(range(len(names)), names)
    ax.set_xlabel('Predicted class')
    ax.set_ylabel('True class')
    ax.set_title('Qwen2.5-1.5B + LoRA: AG News utility test')
    for (i,j), value in np.ndenumerate(cm):
        ax.text(j, i, str(value), ha='center', va='center',
                color=('white' if im.norm(value) > .52 else 'black'))
    fig.colorbar(im, ax=ax, shrink=.83, label='Number of examples')
    fig.tight_layout()
    fig.savefig(dest, dpi=220, bbox_inches='tight')
    plt.close(fig)


def run(a):
    from sklearn.metrics import (accuracy_score, f1_score, precision_score,
                                 recall_score, classification_report, confusion_matrix)
    root = Path(a.data)
    ckpt = Path(a.checkpoint)
    summary_path = Path(a.train_summary)
    if not summary_path.is_file():
        raise FileNotFoundError(summary_path)
    summary = json.loads(summary_path.read_text(encoding='utf-8'))
    manifest, df = check_data(root, summary)
    if a.max_records > 0:
        df = df.iloc[:a.max_records].copy()
    print(f'PASS: immutable test split and 5-epoch LoRA provenance; test examples={len(df)}',flush=True)
    if a.stage == 'audit':
        return
    if not (ckpt / 'adapter_config.json').is_file():
        raise FileNotFoundError(f'LoRA adapter_config.json missing from {ckpt}')
    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer
    from peft import PeftModel, PeftConfig
    if not torch.cuda.is_available():
        raise RuntimeError('A CUDA GPU is required for evaluation')
    conf = PeftConfig.from_pretrained(str(ckpt))
    if conf.base_model_name_or_path != summary['model']:
        raise RuntimeError('LoRA adapter base model mismatch: ' + str(conf.base_model_name_or_path))
    expected_lora = summary['lora']
    if int(conf.r) != int(expected_lora['rank']) or int(conf.lora_alpha) != int(expected_lora['alpha']):
        raise RuntimeError('Saved LoRA adapter rank/alpha differs from training summary')
    if set(conf.target_modules) != set(expected_lora['target_modules']):
        raise RuntimeError('Saved LoRA adapter target modules differ from training summary')
    if abs(float(conf.lora_dropout) - float(expected_lora['dropout'])) > 1e-9:
        raise RuntimeError('Saved LoRA dropout differs from training summary')
    dtype = a.dtype if a.dtype != 'auto' else summary['dtype']
    if dtype not in ('bf16','fp16','fp32'):
        raise RuntimeError(f'Unsupported recorded dtype {dtype}')
    if dtype == 'bf16' and not torch.cuda.is_bf16_supported():
        raise RuntimeError('Training used BF16, but this GPU does not report BF16 support')
    dvalue = {'bf16':torch.bfloat16,'fp16':torch.float16,'fp32':torch.float32}[dtype]
    tok_src = ckpt if any((ckpt / x).exists() for x in ('tokenizer.json','tokenizer_config.json')) else summary['model']
    tokenizer = AutoTokenizer.from_pretrained(str(tok_src), use_fast=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = 'right'
    if len(tokenizer) != int(summary['tokenizer_vocab_size']):
        raise RuntimeError('Tokenizer vocabulary size differs from target training summary')
    max_length = int(summary['max_length'])
    codec = AGNewsCodec(tokenizer, max_length)
    device = torch.device('cuda:0')
    print('Loading base Qwen model and LoRA adapter ...', flush=True)
    try:
        base = AutoModelForCausalLM.from_pretrained(summary['model'], dtype=dvalue)
    except TypeError:
        base = AutoModelForCausalLM.from_pretrained(summary['model'], torch_dtype=dvalue)
    model = PeftModel.from_pretrained(base, str(ckpt), is_trainable=False)
    model.to(device)
    model.eval()
    model.config.use_cache = False
    for param in model.parameters():
        param.requires_grad_(False)
    out = Path(a.out)
    if out.exists() and any(out.iterdir()) and not a.overwrite:
        raise FileExistsError(f'Results directory already contains files: {out}. Pass --overwrite to rerun.')
    out.mkdir(parents=True, exist_ok=True)
    if torch.cuda.is_available():
        torch.cuda.synchronize(device)
        torch.cuda.reset_peak_memory_stats(device)
    started = time.perf_counter()
    output_rows = []
    for n, row in enumerate(df.itertuples(index=False), 1):
        pred, scores = score_labels(model, codec, row.text, torch, dtype, device)
        output_rows.append({
            'sample_id': str(row.sample_id), 'true_label_id': int(row.label_id),
            'pred_label_id': int(pred), 'true_label': LABELS[int(row.label_id)],
            'pred_label': LABELS[int(pred)], 'correct': int(int(pred)==int(row.label_id)),
            **{f'completion_mean_logp_{LABELS[c]}':scores[c] for c in LABELS},
        })
        if a.log_every and n % a.log_every == 0:
            print(f'Test evaluation {n}/{len(df)}', flush=True)
    torch.cuda.synchronize(device)
    elapsed = time.perf_counter() - started
    ytrue = np.array([int(r['true_label_id']) for r in output_rows],dtype=int)
    ypred = np.array([int(r['pred_label_id']) for r in output_rows],dtype=int)
    classes = list(LABELS)
    acc = float(accuracy_score(ytrue,ypred))
    macro_f1 = float(f1_score(ytrue,ypred,labels=classes,average='macro',zero_division=0))
    cm = confusion_matrix(ytrue,ypred,labels=classes)
    reports = classification_report(ytrue,ypred,labels=classes,target_names=[LABELS[i] for i in classes],
                                    digits=4,zero_division=0,output_dict=True)
    per_class = []
    for label_id, name in LABELS.items():
        cl = reports[name]
        per_class.append({'label_id':label_id,'class_name':name,'precision':cl['precision'],
                          'recall':cl['recall'],'f1':cl['f1-score'],'support':int(cl['support'])})
    score = {
        'protocol':'AG News causal-LM category completion utility evaluation (not membership inference)',
        'model':summary['model'], 'method':'LoRA', 'dataset':'AG News', 'split':'utility_test',
        'n':len(df),'is_pilot':bool(a.max_records),'accuracy':acc,'macro_f1':macro_f1,
        'macro_precision':float(precision_score(ytrue,ypred,labels=classes,average='macro',zero_division=0)),
        'macro_recall':float(recall_score(ytrue,ypred,labels=classes,average='macro',zero_division=0)),
        'weighted_f1':float(f1_score(ytrue,ypred,labels=classes,average='weighted',zero_division=0)),
        'eval_wall_seconds':round(elapsed,4),'peak_gpu_inference_allocated_gib':round(torch.cuda.max_memory_allocated(device)/2**30,4),
        'max_length':max_length,'precision_dtype':dtype,
        'decision_rule':'maximum mean log-likelihood of exact candidate class completion, excluding EOS',
        'label_mapping':{str(k):v for k,v in LABELS.items()},
        'data_manifest_sha256':sha_file(root / 'split_manifest.json'),
        'test_csv_sha256':sha_file(root / 'utility_test.csv'),
        'training_summary_sha256':sha_file(summary_path),
        'adapter_config_sha256':sha_file(ckpt / 'adapter_config.json'),
        'adapter_weights_sha256':sha_file(next((ckpt / name for name in ('adapter_model.safetensors','adapter_model.bin') if (ckpt / name).exists()))),
        'evaluation_script_sha256':sha_file(Path(__file__)),
        'classes':per_class,'confusion_matrix':cm.tolist(),
        'software':{'torch':torch.__version__,'python':platform.python_version(),
                    'transformers':__import__('transformers').__version__,
                    'peft':__import__('peft').__version__},
    }
    if a.bootstrap:
        score.update(bootstrap_intervals(ytrue,ypred,classes,a.bootstrap,a.seed))
    pd.DataFrame(output_rows).to_csv(out / 'test_predictions.csv',index=False)
    pd.DataFrame(per_class).to_csv(out / 'per_class_metrics.csv',index=False)
    pd.DataFrame(cm,index=[LABELS[i] for i in classes],columns=[LABELS[i] for i in classes]).to_csv(out / 'confusion_matrix.csv',index_label='true\\predicted')
    (out / 'test_metrics.json').write_text(json.dumps(score,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    (out / 'classification_report.txt').write_text(
        classification_report(ytrue,ypred,labels=classes,target_names=[LABELS[i] for i in classes],
                              digits=4,zero_division=0) + '\n',encoding='utf-8')
    plot_confusion(cm,[LABELS[i] for i in classes],out / 'confusion_matrix.png')
    # Manuscript-ready single-row results with measured, not estimated, test values.
    a_pct = 100.0 * acc
    f_pct = 100.0 * macro_f1
    latex = (r'\begin{tabular}{lrrr}' + '\n' +
             r'\hline' + '\n' +
             r'Fine-tuning method & Test samples & Accuracy (\%) & Macro-F1 (\%) \\' + '\n' +
             r'\hline' + '\n' +
             f'LoRA & {len(df)} & {a_pct:.2f} & {f_pct:.2f} ' + chr(92)*2 + '\n' +
             r'\hline' + '\n' + r'\end{tabular}' + '\n')
    (out / 'test_results_table.tex').write_text(latex, encoding='utf-8')
    print('PASS: held-out utility test evaluated:',len(df),'examples',flush=True)
    print('Accuracy:',f'{acc:.4%}','| macro-F1:',f'{macro_f1:.4%}',flush=True)
    if a.bootstrap:
        print('95% bootstrap CI accuracy:',score['accuracy_ci95'],
              '| macro-F1:',score['macro_f1_ci95'],flush=True)
    print('Output:',out.resolve(),flush=True)


def parse_args():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--stage',choices=['audit','evaluate'],default='evaluate')
    ap.add_argument('--data',default='agnews_demia_qwen15')
    ap.add_argument('--checkpoint',default='agnews_lora_qwen15_5ep/adapter')
    ap.add_argument('--train-summary',default='agnews_lora_qwen15_5ep/run_summary.json')
    ap.add_argument('--out',default='agnews_lora_qwen15_5ep/test_evaluation')
    ap.add_argument('--dtype',choices=['auto','bf16','fp16','fp32'],default='auto')
    ap.add_argument('--max-records',type=int,default=0,help='0 evaluates all 2,000 samples; any cap is pilot only')
    ap.add_argument('--bootstrap',type=int,default=1000)
    ap.add_argument('--seed',type=int,default=42)
    ap.add_argument('--log-every',type=int,default=100)
    ap.add_argument('--overwrite',action='store_true')
    return ap.parse_args()

if __name__ == '__main__':
    run(parse_args())
