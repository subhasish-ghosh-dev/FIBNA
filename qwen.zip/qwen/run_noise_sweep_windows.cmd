@echo off
setlocal EnableExtensions
REM Extract this package in the same parent folder that contains AG News and XSum data.
REM The project root is assumed to be the package's parent directory.
cd /d "%~dp0.."
call conda activate gpu_env
if errorlevel 1 (echo ERROR: activate gpu_env in Anaconda Prompt & exit /b 1)
python "%~dp0noise_sweep.py" --stage all --project-root "%CD%" --reuse-baseline --with-utility
if errorlevel 1 (echo ERROR: the sweep stopped, see Python error above. Already completed attack stages can resume. & exit /b 1)
echo Finished: %CD%\fibna_noise_sweep_runs
