#!/usr/bin/env python3
"""Plot only MEASURED FIBNA noise sweep attack results; never impute missing noise levels.

Input is `measured_noise_vs_mia.csv` created by noise_sweep.py --stage collect.
Plotting is CPU-only. Each row comes from an actual MIA report on a freshly
fine-tuned FIBNA checkpoint or a provenance-verified reused baseline.
"""
from __future__ import annotations
import argparse, csv, math
from collections import defaultdict
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

TASKS = [('agnews','AG News — classification'), ('xsum','XSum — summarization')]
ATTACKS = [('EZ-MIA','ez_mia_full'),('ICP-MIA','icp_mia_reference'),('Min-K%++','min_k_pp_full')]
METRICS = [('roc_auc','ROC-AUC','ROC-AUC',0.5),
           ('tpr_at_1pct_fpr_pct','TPR at calibrated 1% FPR (%)','TPR@1% FPR',None),
           ('observed_fpr_pct','Observed test FPR (%)','Observed FPR',1.0)]


def load(path: Path):
    with path.open('r',newline='',encoding='utf-8') as fh:
        items=list(csv.DictReader(fh))
    for r in items:
        for k in ('nu','kappa','roc_auc','tpr_at_1pct_fpr_pct','observed_fpr_pct','coverage_pct'):
            r[k]=float(r[k])
            if not math.isfinite(r[k]): raise ValueError('Non-finite '+k)
        if r['coverage_pct']<95:raise ValueError('Coverage below 95% for '+str(r))
    unique=set()
    for r in items:
        tag=(r['task'],r['attack'],r['nu'])
        if tag in unique:raise ValueError('Duplicate measured point for '+str(tag))
        unique.add(tag)
    return items


def save(fig, folder, stem):
    fig.tight_layout(rect=(0,0.015,1,.9))
    for ext in ('png','pdf','svg'):
        fig.savefig(folder/(stem+'.'+ext),dpi=300 if ext=='png' else None,
                    bbox_inches='tight',facecolor='white')
    plt.close(fig)
    print('Saved:', folder/(stem+'.pdf'))


def draw_metric(data, folder, field, ylabel, slug, reference, baseline_data):
    task_set={r['task'] for r in data}
    active=[(k,v) for k,v in TASKS if k in task_set]
    fig,axes=plt.subplots(len(active),3,figsize=(13.8,4.0*len(active)),squeeze=False,sharex='col')
    for ridx,(task,task_title) in enumerate(active):
        for cidx,(attack,_) in enumerate(ATTACKS):
            ax=axes[ridx,cidx]
            arr=sorted((r for r in data if r['task']==task and r['attack']==attack),key=lambda r:r['kappa'])
            if not arr:
                ax.text(.5,.5,'No measured data',ha='center',va='center',transform=ax.transAxes)
                continue
            x=np.asarray([r['kappa']*1e5 for r in arr])
            y=np.asarray([r[field] for r in arr])
            ax.plot(x,y,marker='o',markersize=5.5,lw=1.9,
                    color='#17665c',label='FIBNA (noise sweep)')
            ci_prefix={'roc_auc':'auc_ci','tpr_at_1pct_fpr_pct':'tpr_ci_pct',
                       'observed_fpr_pct':'fpr_ci_pct'}[field]
            lo_key,hi_key=ci_prefix+'_low',ci_prefix+'_high'
            if all(r.get(lo_key) not in ('',None) and r.get(hi_key) not in ('',None) for r in arr):
                lower=np.asarray([float(r[lo_key]) for r in arr])
                upper=np.asarray([float(r[hi_key]) for r in arr])
                ax.fill_between(x,lower,upper,color='#17665c',alpha=.13,
                                linewidth=0,label='Test bootstrap 95% CI')
            for method,color,ls in [('LoRA','#244875','--'),('DP-LoRA','#aa6434',':')]:
                key=(task,attack,method)
                if key in baseline_data:
                    ax.axhline(baseline_data[key][field],color=color,ls=ls,lw=1.4,
                               label=method+' (fixed reference)')
            if len(arr)==1:
                ax.text(.04,.95,'One evaluated noise level',transform=ax.transAxes,
                        va='top',fontsize=8)
            if reference is not None:
                ax.axhline(reference,color='0.4',lw=1.,ls='--',label='Reference')
            ax.grid(True,axis='y',ls=':',alpha=.55)
            ax.set_title(attack,fontsize=11,fontweight='bold')
            if cidx==0:
                ax.set_ylabel(task_title+'\n'+ylabel,fontsize=10)
            if ridx==len(active)-1:
                ax.set_xlabel(r'Effective FIBNA noise coefficient $\kappa$ ($\times 10^{-5}$)')
            if len(x)>=2:
                ax.set_xlim(max(0,x.min()-.15*(x.max()-x.min())),x.max()+.15*(x.max()-x.min()))
                ax.set_xticks(x)
                ax.set_xticklabels([f'{v:.2f}' for v in x],rotation=45,ha='right')
            elif len(x)==1:
                ax.set_xlim(max(0,x[0]*.7),x[0]*1.3)
                ax.set_xticks(x)
            if field=='roc_auc':
                ax.set_ylim(max(0,min(float(y.min()),.5)-.075),min(1,max(float(y.max()),.5)+.075))
            else:
                ax.set_ylim(bottom=0)
    # One shared legend avoids crowding the 2-by-3 attack panels.
    handles, labels = axes[0,0].get_legend_handles_labels()
    dedup = dict(zip(labels,handles))
    fig.legend(dedup.values(),dedup.keys(),loc='upper center',
               bbox_to_anchor=(.5,.965),ncol=min(4,len(dedup)),fontsize=9,frameon=False)
    fig.suptitle('FIBNA Gaussian-noise sensitivity — measured MIA performance',
                 fontsize=15,fontweight='bold',y=1.01)
    save(fig,folder,slug)


def draw_realized(data,folder):
    fig,ax=plt.subplots(figsize=(8.4,5.0))
    colors={'agnews':'#1d4e89','xsum':'#a84e30'}
    seen=0
    for task,title in TASKS:
        points={}
        for r in data:
            if r['task']==task and r.get('mean_realized_noise_rms') not in ('',None):
                points[float(r['kappa'])]=float(r['mean_realized_noise_rms'])
        if not points:continue
        keys=sorted(points)
        x=np.array(keys)*1e5
        y=np.array([points[k] for k in keys]);seen+=len(y)
        ax.plot(x,y,marker='o',lw=2,label=title,color=colors[task])
    if not seen:
        plt.close(fig)
        return
    ax.grid(True,ls=':',alpha=.6)
    ax.set_xlabel(r'Effective FIBNA coefficient $\kappa$ ($\times 10^{-5}$)')
    ax.set_ylabel('Mean realized LM-head Gaussian noise RMS per injection')
    ax.set_title('Verification of actual injected noise')
    ax.legend(loc='best')
    save(fig,folder,'04_realized_noise_rms')


def draw_utility(data,folder):
    available=any(r.get('utility_accuracy_pct') not in ('',None) or
                  r.get('utility_rougeL_pct') not in ('',None) for r in data)
    if not available:return
    fig,axes=plt.subplots(1,2,figsize=(11.0,4.6))
    for ax,(task,title),field,ylabel in zip(axes,TASKS,
        ('utility_accuracy_pct','utility_rougeL_pct'),('Test accuracy (%)','Test ROUGE-L F1 (%)')):
        d={}
        for r in data:
            if r['task']==task and r.get(field) not in ('',None):
                d[r['kappa']]=float(r[field])
        if d:
            keys=sorted(d)
            xx=np.array(keys)*1e5
            yy=np.array([d[k] for k in keys])
            ax.plot(xx,yy,marker='o',lw=2)
        else:
            ax.text(.5,.5,'Utility evaluation not available',ha='center',va='center',transform=ax.transAxes)
        ax.set_title(title);ax.set_xlabel(r'$\kappa$ ($\times 10^{-5}$)');ax.set_ylabel(ylabel)
        ax.grid(True,ls=':',alpha=.5)
    fig.suptitle('Held-out task utility versus FIBNA noise level',fontsize=13,fontweight='bold')
    save(fig,folder,'05_utility_vs_noise')


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--csv',type=Path,required=True)
    ap.add_argument('--out',type=Path,default=Path('noise_sensitivity_figures'))
    ap.add_argument('--reference-csv',type=Path,
                    default=Path(__file__).resolve().parent/'reference_baselines_from_manuscript.csv')
    a=ap.parse_args()
    data=load(a.csv)
    if not data:
        raise RuntimeError('No measured values; run training and attack evaluation first')
    levels=defaultdict(set)
    for r in data:levels[r['task']].add(r['nu'])
    for task,points in levels.items():
        if len(points)<2:print('WARNING:',task,'has only one noise level, so no noise-response trend can be inferred.')
    baseline_data={}
    if a.reference_csv.is_file():
        with a.reference_csv.open(newline='',encoding='utf-8') as fh:
            for r in csv.DictReader(fh):
                baseline_data[(r['task'],r['attack'],r['method'])]={
                    k:float(r[k]) for k in ('roc_auc','tpr_at_1pct_fpr_pct','observed_fpr_pct')}
        print('Reference lines are from the supplied manuscript table, not new sweep measurements.')
    a.out.mkdir(parents=True,exist_ok=True)
    for field,ylabel,slug,reference in METRICS:
        draw_metric(data,a.out,field,ylabel,{'roc_auc':'01_mia_roc_auc_vs_noise',
            'tpr_at_1pct_fpr_pct':'02_mia_tpr_vs_noise',
            'observed_fpr_pct':'03_mia_observed_fpr_vs_noise'}[field],reference,baseline_data)
    draw_realized(data,a.out)
    draw_utility(data,a.out)

if __name__=='__main__':main()
