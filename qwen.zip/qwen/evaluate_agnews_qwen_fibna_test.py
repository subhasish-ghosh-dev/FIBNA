#!/usr/bin/env python3
"""Held-out AG News classification evaluation of FIBNA adapter + LM-head delta."""
import argparse, json, hashlib, time
from pathlib import Path
import numpy as np
import pandas as pd
from agnews_qwen_common import AGNewsCodec,LABELS,sha_file
from train_agnews_qwen_fibna import check_data,score_labels,auto_dtype
from load_agnews_qwen_fibna import load_fibna_model


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--stage',choices=('audit','evaluate'),default='audit')
    p.add_argument('--data',default='agnews_demia_qwen15')
    p.add_argument('--checkpoint',default='agnews_fibna_qwen15_5ep')
    p.add_argument('--out',default='agnews_fibna_qwen15_5ep/test_evaluation')
    p.add_argument('--dtype',choices=('bf16','fp16','fp32'),default='bf16')
    p.add_argument('--bootstrap',type=int,default=1000)
    a=p.parse_args()
    root=Path(a.data);_,train,val=check_data(root)
    test=pd.read_csv(root/'utility_test.csv',keep_default_na=False)
    summary_path=Path(a.checkpoint)/'run_summary.json'
    if not summary_path.exists():raise FileNotFoundError(summary_path)
    summary=json.loads(summary_path.read_text(encoding='utf8'))
    if summary['target_train_csv_sha256']!=sha_file(root/'target_train.csv') or summary['split_manifest_sha256']!=sha_file(root/'split_manifest.json'):
        raise RuntimeError('FIBNA checkpoint trained on another dataset')
    if summary.get('is_pilot') or summary['epochs']!=5:raise RuntimeError('Not the five-epoch final model')
    if not (Path(a.checkpoint)/'lm_head_delta.safetensors').is_file():
        raise FileNotFoundError('Missing FIBNA head delta; classification would be invalid')
    if len(test)!=2000 or not set(test.text_hash).isdisjoint(set(train.text_hash)|set(val.text_hash)):
        raise RuntimeError('Utility test dataset membership invalid')
    if a.stage=='audit':
        print('PASS: 2000 held-out utility-test examples; FIBNA adapter and head delta present')
        return
    import torch
    from transformers import AutoTokenizer
    from sklearn.metrics import accuracy_score,f1_score,classification_report,confusion_matrix
    if not torch.cuda.is_available():raise RuntimeError('CUDA required')
    tok=AutoTokenizer.from_pretrained(summary['model'],use_fast=True)
    if tok.pad_token is None:tok.pad_token=tok.eos_token
    tok.padding_side='right'
    codec=AGNewsCodec(tok,summary['max_length'])
    model=load_fibna_model(a.checkpoint,base_model=summary['model'],dtype=a.dtype,device='cuda:0')
    device=torch.device('cuda:0')
    target=[];prediction=[]
    start=time.perf_counter()
    for i,row in enumerate(test.itertuples(index=False),1):
        target.append(int(row.label_id))
        prediction.append(int(score_labels(model,codec,row.text,torch,a.dtype,device)))
        if i%100==0:print(f'Test {i}/{len(test)}',flush=True)
    torch.cuda.synchronize(device)
    duration=time.perf_counter()-start
    y=np.asarray(target);pred=np.asarray(prediction)
    result={'model':summary['model'],'method':'FIBNA','split':'utility_test','n':len(y),
            'accuracy':float(accuracy_score(y,pred)),
            'macro_f1':float(f1_score(y,pred,labels=list(LABELS),average='macro',zero_division=0)),
            'wall_seconds':round(duration,3),
            'checkpoint_has_lm_head_delta':True}
    if a.bootstrap:
        rng=np.random.default_rng(42)
        vals=[]
        for _ in range(a.bootstrap):
            idx=rng.choice(len(y),len(y),replace=True)
            vals.append([accuracy_score(y[idx],pred[idx]),f1_score(y[idx],pred[idx],labels=list(LABELS),average='macro',zero_division=0)])
        bounds=np.quantile(vals,[.025,.975],axis=0)
        result['accuracy_ci95']=[float(bounds[0,0]),float(bounds[1,0])]
        result['macro_f1_ci95']=[float(bounds[0,1]),float(bounds[1,1])]
    out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
    (out/'test_metrics.json').write_text(json.dumps(result,indent=2),encoding='utf8')
    pd.DataFrame({'sample_id':test.sample_id,'true_label':y,'predicted_label':pred}).to_csv(out/'test_predictions.csv',index=False)
    report=classification_report(y,pred,labels=list(LABELS),target_names=[LABELS[i] for i in LABELS],output_dict=True,zero_division=0)
    pd.DataFrame(report).transpose().to_csv(out/'per_class_metrics.csv')
    cm=confusion_matrix(y,pred,labels=list(LABELS))
    pd.DataFrame(cm,index=list(LABELS.values()),columns=list(LABELS.values())).to_csv(out/'confusion_matrix.csv')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(figsize=(6,5))
    im=ax.imshow(cm,cmap='Greys')
    for i in range(4):
        for j in range(4):ax.text(j,i,f'{cm[i,j]}',ha='center',va='center',fontsize=9)
    ax.set_xticks(range(4),list(LABELS.values()),rotation=35,ha='right')
    ax.set_yticks(range(4),list(LABELS.values()))
    ax.set_xlabel('Predicted');ax.set_ylabel('True')
    fig.tight_layout();fig.savefig(out/'confusion_matrix.png',dpi=240);plt.close(fig)
    tex='\\begin{tabular}{lrrr}\n\\hline\nMethod & Test samples & Accuracy (\\%) & Macro-F1 (\\%) \\\\\n\\hline\n'
    tex+=f'FIBNA & {len(y)} & {result["accuracy"]*100:.2f} & {result["macro_f1"]*100:.2f} \\\\\n\\hline\n\\end{{tabular}}\n'
    (out/'test_results_table.tex').write_text(tex,encoding='utf8')
    print(f'FIBNA Test n={len(y)} accuracy={result["accuracy"]*100:.2f}% macro-F1={result["macro_f1"]*100:.2f}%',flush=True)
    print('Results:',out.resolve(),flush=True)

if __name__=='__main__':main()
